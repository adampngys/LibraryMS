﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SA47_Team01ACAProject
{
    public partial class LibLandingPage : Form
    {
        SA47_Team01aCADatabaseEntities context;
        public LibLandingPage()
        {
            InitializeComponent();
        }

        private void LibLandingPage_Load(object sender, EventArgs e)
        {
            context = new SA47_Team01aCADatabaseEntities();
            var filtered = context.IssueTransactions.Where(x => x.Remarks == "Extension Requested").ToList();
            dataGridView1.DataSource = filtered;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            BooksOnLoan f = new BooksOnLoan();
            f.MdiParent = this.ParentForm;
            f.WindowState = FormWindowState.Maximized;
            f.Show();
        }

        //refresh list
        private void button3_Click(object sender, EventArgs e)
        {
            var filteragain = context.IssueTransactions.Where(x => x.Remarks == "Extension Requested").ToList();
            dataGridView1.DataSource = filteragain;
        }

        //deny extension
        private void button2_Click(object sender, EventArgs e)
        {
            int selected = Convert.ToInt16(dataGridView1.CurrentRow.Cells[0].Value);
            IssueTransaction t = context.IssueTransactions.Where(x => x.TransactionID == selected).First();
            t.Remarks = "Extension Rejected";
            context.SaveChanges();
        }

        //approve extension
        private void button1_Click(object sender, EventArgs e)
        {
            int selected = Convert.ToInt16(dataGridView1.CurrentRow.Cells[0].Value);
            IssueTransaction t = context.IssueTransactions.Where(x => x.TransactionID == selected).First();
            DateTime newdate = t.DateDue.AddDays(7);
            t.DateDue = newdate;
            t.Remarks = "Extension Approved";
            context.SaveChanges();
        }

        private void memberMaintenanceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MemberForm f = new MemberForm();
            f.MdiParent = this.ParentForm;
            f.WindowState = FormWindowState.Maximized;
            f.Show();
        }

        private void bookMaintenanceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LibBookMaintenanceForm f = new LibBookMaintenanceForm();
            f.MdiParent = this.ParentForm;
            f.WindowState = FormWindowState.Maximized;
            f.Show();
        }

        private void issueBookToolStripMenuItem_Click(object sender, EventArgs e)
        {
            IssueBook f = new IssueBook();
            f.MdiParent = this.ParentForm;
            f.WindowState = FormWindowState.Maximized;
            f.Show();
        }

        private void returnBookToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Return_Book f = new Return_Book();
            f.MdiParent = this.ParentForm;
            f.WindowState = FormWindowState.Maximized;
            f.Show();
        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
