﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SA47_Team01ACAProject
{
    public partial class PopupMember : Form
    {


        public string MemID { get; private set; }
        public string MemName { get; private set; }

        public PopupMember()
        {
            InitializeComponent();
        }


       

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedCells.Count > 0)
            {
                int selectedrowindex = dataGridView1.SelectedCells[0].RowIndex;

                DataGridViewRow selectedRow = dataGridView1.Rows[selectedrowindex];

                this.MemID = Convert.ToString(selectedRow.Cells["MemberID"].Value);
                this.MemName = Convert.ToString(selectedRow.Cells["MemberName"].Value);
                this.Close();

            }
        }

        private void PopupMember_Load(object sender, EventArgs e)
        {
            dataGridView1.FirstDisplayedCell.Selected = false;
            dataGridView1.ClearSelection();
            this.dataGridView1.SelectionChanged += dataGridView1_SelectionChanged;
        }

        private void Cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

