﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SA47_Team01ACAProject
{
    public partial class BookMaintenanceFormADO : Form
    {
        SqlConnection cn;
        SqlCommand cm;
        SqlDataAdapter da;
        SqlCommandBuilder cmb;
        DataSet ds;
        int first = 0;
        int index = 0;
        int last = 0;
        int check = 0;
        int current = 0;

        public BookMaintenanceFormADO()
        {
            InitializeComponent();
        }

        //form load
        private void BookMaintenanceFormADO_Load(object sender, EventArgs e)
        {
            string conS = "data source = (local); integrated security = sspi;" +
                "initial catalog = SA47_Team01aCADatabase";
            cn = new SqlConnection(conS);

            cm = new SqlCommand();
            cm.Connection = cn;
            cm.CommandText = "select * from books";

            da = new SqlDataAdapter(cm);
            cmb = new SqlCommandBuilder(da);
            ds = new DataSet();

            cn.Open();
            da.Fill(ds, "Books");
            da.TableMappings.Add("Table", "Books");
            cn.Close();

            first = 0; //First row in data table (always at index 0)
            label1.Text = Convert.ToInt32(ds.Tables["Books"].Rows[0]["BookID"]).ToString();
            last = ds.Tables[0].Rows.Count - 1;
            label2.Text = Convert.ToInt16(ds.Tables["Books"].Rows[last]["BookID"]).ToString();
        }

        //display method
        private void display()
        {
            IDText.Text = ds.Tables["Books"].Rows[index]["BookID"].ToString();
            TitleText.Text = ds.Tables["Books"].Rows[index]["BookTitle"].ToString();
            AuthorBox.Text = ds.Tables["Books"].Rows[index]["Author"].ToString();
            PublisherBox.Text = ds.Tables["Books"].Rows[index]["Publisher"].ToString();
            CategoryBox.Text = ds.Tables["Books"].Rows[index]["BookCategory"].ToString();
            GenreBox.Text = ds.Tables["Books"].Rows[index]["Genre"].ToString();
            ISBNText.Text = ds.Tables["Books"].Rows[index]["ISBN"].ToString();
            StockNumeric.Text = ds.Tables["Books"].Rows[index]["TotalStock"].ToString();
            LoanNumeric.Text = ds.Tables["Books"].Rows[index]["NumberLoaned"].ToString();
        }

        //insert new book by DataRow
        private void InsertButton_Click(object sender, EventArgs e)
        {
            if (NoNull() == DialogResult.OK)
            {
                DataRow dr = ds.Tables["Books"].NewRow();
                dr["BookTitle"] = TitleText.Text;
                dr["Author"] = AuthorBox.Text;
                dr["Publisher"] = PublisherBox.Text;
                dr["BookCategory"] = CategoryBox.Text;
                dr["Genre"] = GenreBox.Text;
                dr["ISBN"] = ISBNText.Text;
                dr["TotalStock"] = StockNumeric.Text;
                dr["NumberLoaned"] = LoanNumeric.Text;

                ds.Tables["Books"].Rows.Add(dr);
                da.Update(ds, "Books");

                MessageBox.Show("Book added!");
            }
            else
            {
                MessageBox.Show("Some information is missing!");
            }
        }

        //insert new book by SQL Parameters
        private void button1_Click(object sender, EventArgs e)
        {
            if (NoNull() == DialogResult.OK)
            {
                SqlCommand cmInsert = new SqlCommand();
                cmInsert.Connection = cn;
                cmInsert.CommandText = "INSERT INTO Books (BookTitle, Author, Publisher, BookCategory, Genre, ISBN, TotalStock, NumberLoaned) VALUES (@BT, @AT, @PB, @BC, @GR, @ISBN, @TS, @NL)";
                SqlParameter pBT = new SqlParameter("@BT", SqlDbType.NVarChar, 70);
                pBT.Value = TitleText.Text;
                SqlParameter pAT = new SqlParameter("@AT", SqlDbType.NVarChar, 50);
                pAT.Value = AuthorBox.Text;
                SqlParameter pPB = new SqlParameter("@PB", SqlDbType.NVarChar, 50);
                pPB.Value = PublisherBox.Text;
                SqlParameter pBC = new SqlParameter("@BC", SqlDbType.NVarChar, 15);
                pBC.Value = CategoryBox.Text;
                SqlParameter pGR = new SqlParameter("@GR", SqlDbType.NVarChar, 20);
                pGR.Value = GenreBox.Text;
                SqlParameter pISBN = new SqlParameter("@ISBN", SqlDbType.NVarChar, 15);
                pISBN.Value = ISBNText.Text;
                SqlParameter pTS = new SqlParameter("@TS", SqlDbType.SmallInt, 5);
                pTS.Value = StockNumeric.Text;
                SqlParameter pNL = new SqlParameter("@NL", SqlDbType.SmallInt, 5);
                pNL.Value = LoanNumeric.Text;
                SqlParameter[] pArr = new SqlParameter[]
                {
                pBT, pAT, pPB, pBC, pGR, pISBN, pTS, pNL
                };
                cmInsert.Parameters.AddRange(pArr);

                da = new SqlDataAdapter(cmInsert);
                cmb = new SqlCommandBuilder(da);
                ds = new DataSet();
                da.Fill(ds, "Books");
                da.TableMappings.Add("Table", "Books");
                da.Update(ds);

                MessageBox.Show("Book added!");
            }
            else
            {
                MessageBox.Show("Some information is missing!");
            }
        }

        //update record by DataRow
        private void UpdateButton_Click(object sender, EventArgs e)
        {
            if (NoNull() == DialogResult.OK)
            {
                //note the diff with "insert by datarow" in the DataRow instantiation
                DataRow dr = ds.Tables["Books"].Rows[index];
                dr["BookTitle"] = TitleText.Text;
                dr["Author"] = AuthorBox.Text;
                dr["Publisher"] = PublisherBox.Text;
                dr["BookCategory"] = CategoryBox.Text;
                dr["Genre"] = GenreBox.Text;
                dr["ISBN"] = ISBNText.Text;
                dr["TotalStock"] = StockNumeric.Text;
                dr["NumberLoaned"] = LoanNumeric.Text;

                da.Update(ds, "Books");

                MessageBox.Show("Book added!");
            }
            else
            {
                MessageBox.Show("Some information is missing!");
            }
        }

        //update record by SQL
        private void button4_Click(object sender, EventArgs e)
        {
            if (NoNull() == DialogResult.OK)
            {
                SqlCommand cmUpdate = new SqlCommand();
                cmUpdate.Connection = cn;
                cmUpdate.CommandText = "update Books set BookTitle = @BT, Author = @AT, Publisher = @PB, BookCategory = @BC, Genre = @GR, ISBN = @ISBN, TotalStock = @TS, NumberLoaned = @NL where BookID = @BID";
                SqlParameter pBID = new SqlParameter("@BID", SqlDbType.SmallInt, 5);
                pBID.Value = IDText.Text;
                SqlParameter pBT = new SqlParameter("@BT", SqlDbType.NVarChar, 70);
                pBT.Value = TitleText.Text;
                SqlParameter pAT = new SqlParameter("@AT", SqlDbType.NVarChar, 50);
                pAT.Value = AuthorBox.Text;
                SqlParameter pPB = new SqlParameter("@PB", SqlDbType.NVarChar, 50);
                pPB.Value = PublisherBox.Text;
                SqlParameter pBC = new SqlParameter("@BC", SqlDbType.NVarChar, 15);
                pBC.Value = CategoryBox.Text;
                SqlParameter pGR = new SqlParameter("@GR", SqlDbType.NVarChar, 20);
                pGR.Value = GenreBox.Text;
                SqlParameter pISBN = new SqlParameter("@ISBN", SqlDbType.NVarChar, 15);
                pISBN.Value = ISBNText.Text;
                SqlParameter pTS = new SqlParameter("@TS", SqlDbType.SmallInt, 5);
                pTS.Value = StockNumeric.Text;
                SqlParameter pNL = new SqlParameter("@NL", SqlDbType.SmallInt, 5);
                pNL.Value = LoanNumeric.Text;
                SqlParameter[] pArr = new SqlParameter[]
                {
                pBID, pBT, pAT, pPB, pBC, pGR, pISBN, pTS, pNL
                };
                cmUpdate.Parameters.AddRange(pArr);

                da = new SqlDataAdapter(cmUpdate);
                cmb = new SqlCommandBuilder(da);
                ds = new DataSet();
                da.Fill(ds, "Books");
                da.TableMappings.Add("Table", "Books");
                da.Update(ds);

                MessageBox.Show("Book added!");
            }
            else
            {
                MessageBox.Show("Some information is missing!");
            }
        }

        //delete record by DataRow
        private void DeleteButton_Click(object sender, EventArgs e)
        {
            cm = new SqlCommand();
            cm.Connection = cn;
            cm.CommandText = "select * from Books";

            da = new SqlDataAdapter(cm);
            cmb = new SqlCommandBuilder(da);
            ds = new DataSet();

            da.Fill(ds, "Books");
            da.TableMappings.Add("Table", "Books");

            ds.Tables["Books"].Rows[index].Delete();
            da.Update(ds);
        }

        //delete record by SQL Parameters
        private void button3_Click(object sender, EventArgs e)
        {
            cm = new SqlCommand();
            cm.Connection = cn;
            cm.CommandText = "delete from Books where BookID = @BID";
            SqlParameter pBID = new SqlParameter("@BID", SqlDbType.SmallInt, 5);
            pBID.Value = Convert.ToInt32(IDText.Text);
            cm.Parameters.Add(pBID);

            da = new SqlDataAdapter(cm);
            cmb = new SqlCommandBuilder(da);
            ds = new DataSet();

            da.Fill(ds, "Books");
            da.TableMappings.Add("Table", "Books");

            da.Update(ds);
        }

        //go to first BookID
        private void FirstButton_Click(object sender, EventArgs e)
        {
            index = first;
            display();
        }

        //go back by 1 record
        private void PreviousButton_Click(object sender, EventArgs e)
        {
            int previndex = 0;

            if (IDText.Text == "")
            {
                index = 0;
                display();
            }
            else if (index == 0)
            {
                MessageBox.Show("You are at the first record.");
            }
            else
            {
                for (int i = index; i >= 0; i--)
                {
                    check = Convert.ToInt32(ds.Tables["Books"].Rows[i]["BookID"]);
                    current = Convert.ToInt32(ds.Tables["Books"].Rows[index]["BookID"]);

                    if (check < current)
                    {
                        previndex = i;
                        break;
                    }
                }
                index = previndex;
                display();
            }
        }

        //go forward by 1 record
        private void NextButton_Click(object sender, EventArgs e)
        {
            int nextindex = 0;

            if (IDText.Text == "")
            {
                index = 0;
                display();
            }
            else
            {
                if (index == last)
                {
                    MessageBox.Show("You are at the last record.");
                }
                else
                {
                    for (int i = index; i <= last; i++)
                    {
                        check = Convert.ToInt32(ds.Tables["Books"].Rows[i]["BookID"]);
                        current = Convert.ToInt32(ds.Tables["Books"].Rows[index]["BookID"]);
                        if (check > current)
                        {
                            nextindex = i;
                            break;
                        }
                    }
                    index = nextindex;
                    display();
                }
            }
        }

        //go to last record
        private void LastButton_Click(object sender, EventArgs e)
        {
            index = last;
            display();
        }

        //clears all textboxes
        private void ResetButton_Click(object sender, EventArgs e)
        {
            IDText.Clear();
            TitleText.Clear();
            AuthorBox.ResetText();
            PublisherBox.ResetText();
            CategoryBox.ResetText();
            GenreBox.ResetText();
            ISBNText.Clear();
            StockNumeric.Value = 0;
            LoanNumeric.Value = 0;
        }

        //back or close button
        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //no null method
        private DialogResult NoNull()
        {
            if (string.IsNullOrWhiteSpace(TitleText.Text) || string.IsNullOrWhiteSpace(AuthorBox.Text) ||
                string.IsNullOrWhiteSpace(PublisherBox.Text) || string.IsNullOrWhiteSpace(CategoryBox.Text) ||
                string.IsNullOrWhiteSpace(GenreBox.Text) || string.IsNullOrWhiteSpace(ISBNText.Text) ||
                string.IsNullOrWhiteSpace(StockNumeric.Text) || string.IsNullOrWhiteSpace(LoanNumeric.Text))
            {
                return DialogResult.Cancel;
            }
            else
            {
                return DialogResult.OK;
            }
        }

        //find record button
        private void FindButton_Click(object sender, EventArgs e)
        {
            try
            {
                int findthis = Convert.ToInt32(IDFindText.Text);
                bool notfound = false;

                for (int i = 0; i < ds.Tables["Books"].Rows.Count - 1; i++)
                {
                    if (Convert.ToInt32(ds.Tables["Books"].Rows[i]["BookID"]) == findthis)
                    {
                        index = i;
                        display();
                        break;
                    }
                    notfound = true;
                }

                if(notfound == true)
                {
                    MessageBox.Show("Book not found!");
                }
            }
            catch(Exception)
            {
                MessageBox.Show("Please enter a valid BookID.");
            }
        }

        //find record textbox
        private void IDFindText_TextChanged(object sender, EventArgs e)
        {
            try
            {
                int findthis = Convert.ToInt32(IDFindText.Text);

                if (IDFindText.Text == "")
                {
                    MessageBox.Show("Please input a valid BookID.");
                }
                else
                {
                    for (int i = 0; i < ds.Tables["Books"].Rows.Count; i++)
                    {
                        if (Convert.ToInt32(ds.Tables["Books"].Rows[i]["BookID"]) == findthis)
                        {
                            index = i;
                            display();
                            break;
                        }
                        else
                        {
                            IDText.Clear();
                            TitleText.Clear();
                            AuthorBox.ResetText();
                            PublisherBox.ResetText();
                            CategoryBox.ResetText();
                            GenreBox.ResetText();
                            ISBNText.Clear();
                            StockNumeric.Value = 0;
                            LoanNumeric.Value = 0;
                        }
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Please enter a valid BookID.");
            }
        }
    }
}
