﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using System.Windows.Forms;

namespace SA47_Team01ACAProject
{
    public partial class IssueBook2 : Form
    {
        SA47_Team01aCADatabaseEntities context = new SA47_Team01aCADatabaseEntities();
        int iMemid = 0;
        int iBookid = 0;
        public IssueBook2()
        {
            InitializeComponent();
            toolStripStatusLabel1.Text = "";
        }

        private void IssueBook2_Load(object sender, EventArgs e)
        {
            IssueDate.Text = DateTime.Now.Date.ToShortDateString();
            DueDate.Text = IssueDate.Value.AddDays(30).ToShortDateString();
            ReturnDate.Text = DueDate.Value.ToString();
            int month = Convert.ToInt32(DateTime.Now.Month);
            if ((month == 6) || (month == 12))
            {
                SpecialPeriod.Checked = true;
            }

            else
            {
                NormalPeriod.Checked = true;
            }
        }

        //Checks MemId for valid character input
        private void MemId_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Please enter numeric values only.");
            }
        }

        //Checks BookId for valid character input
        private void BookId_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Please enter numeric values only.");
            }
        }

        //Check MemId input for valid MemberID
        private void MemId_TextChanged(object sender, EventArgs e)
        {
            if (MemId.Text == "")
            {
                //MessageBox.Show("Please enter a BookID in the textbox to begin find.");
                toolStripStatusLabel1.Text = "Please enter a Member ID in the textbox to begin find.";
            }
            else
            {
                int findme = Convert.ToInt32(MemId.Text);
                if (context.Members.Where(x => x.MemberID == findme).FirstOrDefault() != null)
                {
                    iMemid = findme;
                    MemName.Text = context.Members.Where(x => x.MemberID == findme).First().MemberName.ToString();
                    BooksBorrowed.Text = context.IssueTransactions.Where(y => y.MemberID == findme && y.LoanStatus == "Out").Count().ToString();
                    toolStripStatusLabel1.Text = "";
                }
                else
                {
                    toolStripStatusLabel1.Text = "MemberID not found.";
                    MemName.ResetText();
                    MemName.Text = "";
                    BooksBorrowed.Text = "";
                }
            }
        }

        //Check BookId input for valid BookID
        private void BookId_TextChanged(object sender, EventArgs e)
        {
            if (BookId.Text == "")
            {
                //MessageBox.Show("Please enter a BookID in the textbox to begin find.");
                toolStripStatusLabel1.Text = "Please enter a Book ID in the textbox to begin find.";
            }
            else
            {
                int findme = Convert.ToInt32(BookId.Text);
                if (context.Books.Where(x => x.BookID == findme).FirstOrDefault() != null)
                {
                    iBookid = findme;
                    BookTitle.Text = context.Books.Where(x => x.BookID == findme).First().BookTitle.ToString();
                    toolStripStatusLabel1.Text = "";
                }
                else
                {
                    toolStripStatusLabel1.Text = "BookID not found.";
                    BookTitle.ResetText();
                    BookTitle.Text = "";
                }
            }
        }

        //Pop-up to search member
        private void SearchMember_Click(object sender, EventArgs e)
        {
            IssueBook2a a = new IssueBook2a();
            a.ShowDialog();
            a.Dispose();
            MemId.Text = a.thememid.ToString();
            MemName.Text = a.themember.ToString();
        }

        //Pop-up to search book
        private void SearchBook_Click(object sender, EventArgs e)
        {
            IssueBook2b b = new IssueBook2b();
            b.ShowDialog();
            b.Dispose();
            BookId.Text = b.thebookid.ToString();
            BookTitle.Text = b.thebook.ToString();
        }


        bool cont;
        private void CheckMember()
        {
            var CM = context.Members.Where(x => x.MemberID == iMemid).FirstOrDefault();
            if (CM == null)
            {
                MessageBox.Show("Member Not Found");
                cont = false;
            }
            else
            {
                cont = true;
            }
        }

        bool cont1;
        private void CheckBook()
        {
            var CB = context.Books.Where(x => x.BookID == iBookid).FirstOrDefault();
            if (CB == null)
            {
                MessageBox.Show("Book Not Found");
                cont1 = false;
            }
            else
            {
                cont1 = true;
            }
        }

        private void IssueBookBtn_Click(object sender, EventArgs e)
        {
            CheckBook();
            CheckMember();
            if (cont == true && cont1 == true)
            {
                //remember to use "using System.Transactions;"
                using (TransactionScope ts = new TransactionScope())
                {
                    IssueTransaction it = new IssueTransaction();

                    it.MemberID = (short)iMemid;
                    Member m = context.Members.Where(x => x.MemberID == iMemid).First();
                    BooksBorrowed.Text = m.IssueTransactions.Where(x => x.LoanStatus == "Out").Count().ToString();

                    it.BookID = (short)iBookid;
                    Book b = context.Books.Where(x => x.BookID == iBookid).First();
                    if (b.NumberLoaned >= b.TotalStock)
                    {
                        MessageBox.Show("Out of Stock. Please Select another book.");
                    }
                    else
                    {
                        it.DateIssue = IssueDate.Value.Date;
                        it.DateDue = DueDate.Value.Date;
                        it.DateActualReturn = ReturnDate.Value.Date;
                        it.LoanStatus = LoanStatus.Text;
                        it.Remarks = Remarks.Text;

                        if (NormalPeriod.Checked)
                        {
                            int value;
                            if (Int32.TryParse(BooksBorrowed.Text, out value))
                            {
                                if (value >= 5)
                                {
                                    MessageBox.Show("Member has already reached the maximum borrow limit. Cannot Issue Book!");
                                }

                                else
                                {
                                    b.NumberLoaned = Convert.ToInt16(b.NumberLoaned + 1);
                                    context.IssueTransactions.Add(it);
                                    context.SaveChanges();
                                    Transid.Text = it.TransactionID.ToString();

                                    MessageBox.Show("Book Issued Successfully");
                                    //MessageBox.Show("Test");
                                    ts.Complete();
                                    this.Close();
                                }
                            }
                        }

                        if (SpecialPeriod.Checked)
                        {
                            int value;
                            if (Int32.TryParse(BooksBorrowed.Text, out value))
                            {
                                if (value >= 10)
                                {
                                    MessageBox.Show("Member has already reached the maximum borrow limit. Cannot Issue Book!");
                                }

                                else
                                {
                                    b.NumberLoaned = Convert.ToInt16(b.NumberLoaned + 1);
                                    context.IssueTransactions.Add(it);
                                    context.SaveChanges();
                                    Transid.Text = it.TransactionID.ToString();

                                    MessageBox.Show("Book Issued Successfully!");
                                    //MessageBox.Show("Test");
                                    ts.Complete();
                                    this.Close();
                                }
                            }
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Sorry, we are unable to continue. Incorrect credentials provided.");
            }

        }
    }
}
