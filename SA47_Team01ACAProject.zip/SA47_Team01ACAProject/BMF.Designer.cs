﻿namespace SA47_Team01ACAProject
{
    partial class BMF
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BooksPanel = new System.Windows.Forms.Panel();
            this.LoanNumeric = new System.Windows.Forms.NumericUpDown();
            this.StockNumeric = new System.Windows.Forms.NumericUpDown();
            this.GenreBox = new System.Windows.Forms.ComboBox();
            this.CategoryBox = new System.Windows.Forms.ComboBox();
            this.PublisherBox = new System.Windows.Forms.ComboBox();
            this.AuthorBox = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.FindLabel = new System.Windows.Forms.Label();
            this.IDFindText = new System.Windows.Forms.TextBox();
            this.FindButton = new System.Windows.Forms.Button();
            this.LastButton = new System.Windows.Forms.Button();
            this.NextButton = new System.Windows.Forms.Button();
            this.FirstButton = new System.Windows.Forms.Button();
            this.PreviousButton = new System.Windows.Forms.Button();
            this.InsertButton = new System.Windows.Forms.Button();
            this.ResetButton = new System.Windows.Forms.Button();
            this.IDText = new System.Windows.Forms.TextBox();
            this.IDLabel = new System.Windows.Forms.Label();
            this.LoanLabel = new System.Windows.Forms.Label();
            this.DeleteButton = new System.Windows.Forms.Button();
            this.UpdateButton = new System.Windows.Forms.Button();
            this.ISBNText = new System.Windows.Forms.TextBox();
            this.StockLabel = new System.Windows.Forms.Label();
            this.ISBNLabel = new System.Windows.Forms.Label();
            this.GenreLabel = new System.Windows.Forms.Label();
            this.AuthorLabel = new System.Windows.Forms.Label();
            this.PublisherLabel = new System.Windows.Forms.Label();
            this.CategoryLabel = new System.Windows.Forms.Label();
            this.TitleText = new System.Windows.Forms.TextBox();
            this.TitleLabel = new System.Windows.Forms.Label();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.BooksPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LoanNumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.StockNumeric)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // BooksPanel
            // 
            this.BooksPanel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.BooksPanel.Controls.Add(this.LoanNumeric);
            this.BooksPanel.Controls.Add(this.StockNumeric);
            this.BooksPanel.Controls.Add(this.GenreBox);
            this.BooksPanel.Controls.Add(this.CategoryBox);
            this.BooksPanel.Controls.Add(this.PublisherBox);
            this.BooksPanel.Controls.Add(this.AuthorBox);
            this.BooksPanel.Controls.Add(this.groupBox1);
            this.BooksPanel.Controls.Add(this.LastButton);
            this.BooksPanel.Controls.Add(this.NextButton);
            this.BooksPanel.Controls.Add(this.FirstButton);
            this.BooksPanel.Controls.Add(this.PreviousButton);
            this.BooksPanel.Controls.Add(this.InsertButton);
            this.BooksPanel.Controls.Add(this.ResetButton);
            this.BooksPanel.Controls.Add(this.IDText);
            this.BooksPanel.Controls.Add(this.IDLabel);
            this.BooksPanel.Controls.Add(this.LoanLabel);
            this.BooksPanel.Controls.Add(this.DeleteButton);
            this.BooksPanel.Controls.Add(this.UpdateButton);
            this.BooksPanel.Controls.Add(this.ISBNText);
            this.BooksPanel.Controls.Add(this.StockLabel);
            this.BooksPanel.Controls.Add(this.ISBNLabel);
            this.BooksPanel.Controls.Add(this.GenreLabel);
            this.BooksPanel.Controls.Add(this.AuthorLabel);
            this.BooksPanel.Controls.Add(this.PublisherLabel);
            this.BooksPanel.Controls.Add(this.CategoryLabel);
            this.BooksPanel.Controls.Add(this.TitleText);
            this.BooksPanel.Controls.Add(this.TitleLabel);
            this.BooksPanel.Location = new System.Drawing.Point(57, 15);
            this.BooksPanel.Margin = new System.Windows.Forms.Padding(6);
            this.BooksPanel.Name = "BooksPanel";
            this.BooksPanel.Size = new System.Drawing.Size(1128, 614);
            this.BooksPanel.TabIndex = 90;
            // 
            // LoanNumeric
            // 
            this.LoanNumeric.Location = new System.Drawing.Point(506, 358);
            this.LoanNumeric.Margin = new System.Windows.Forms.Padding(6);
            this.LoanNumeric.Name = "LoanNumeric";
            this.LoanNumeric.Size = new System.Drawing.Size(108, 31);
            this.LoanNumeric.TabIndex = 8;
            this.LoanNumeric.ValueChanged += new System.EventHandler(this.LoanNumeric_ValueChanged);
            this.LoanNumeric.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.LoanNumeric_KeyPress);
            // 
            // StockNumeric
            // 
            this.StockNumeric.Location = new System.Drawing.Point(506, 315);
            this.StockNumeric.Margin = new System.Windows.Forms.Padding(6);
            this.StockNumeric.Name = "StockNumeric";
            this.StockNumeric.Size = new System.Drawing.Size(108, 31);
            this.StockNumeric.TabIndex = 7;
            this.StockNumeric.ValueChanged += new System.EventHandler(this.StockNumeric_ValueChanged);
            this.StockNumeric.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.StockNumeric_KeyPress);
            // 
            // GenreBox
            // 
            this.GenreBox.FormattingEnabled = true;
            this.GenreBox.Location = new System.Drawing.Point(506, 227);
            this.GenreBox.Margin = new System.Windows.Forms.Padding(6);
            this.GenreBox.Name = "GenreBox";
            this.GenreBox.Size = new System.Drawing.Size(238, 33);
            this.GenreBox.TabIndex = 5;
            this.GenreBox.Text = " ";
            // 
            // CategoryBox
            // 
            this.CategoryBox.FormattingEnabled = true;
            this.CategoryBox.Location = new System.Drawing.Point(506, 182);
            this.CategoryBox.Margin = new System.Windows.Forms.Padding(6);
            this.CategoryBox.Name = "CategoryBox";
            this.CategoryBox.Size = new System.Drawing.Size(238, 33);
            this.CategoryBox.TabIndex = 4;
            this.CategoryBox.Text = " ";
            // 
            // PublisherBox
            // 
            this.PublisherBox.FormattingEnabled = true;
            this.PublisherBox.Location = new System.Drawing.Point(506, 137);
            this.PublisherBox.Margin = new System.Windows.Forms.Padding(6);
            this.PublisherBox.Name = "PublisherBox";
            this.PublisherBox.Size = new System.Drawing.Size(238, 33);
            this.PublisherBox.TabIndex = 3;
            this.PublisherBox.Text = " ";
            // 
            // AuthorBox
            // 
            this.AuthorBox.FormattingEnabled = true;
            this.AuthorBox.Location = new System.Drawing.Point(506, 92);
            this.AuthorBox.Margin = new System.Windows.Forms.Padding(6);
            this.AuthorBox.Name = "AuthorBox";
            this.AuthorBox.Size = new System.Drawing.Size(238, 33);
            this.AuthorBox.TabIndex = 2;
            this.AuthorBox.Text = " ";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.FindLabel);
            this.groupBox1.Controls.Add(this.IDFindText);
            this.groupBox1.Controls.Add(this.FindButton);
            this.groupBox1.Location = new System.Drawing.Point(201, 457);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(6);
            this.groupBox1.Size = new System.Drawing.Size(596, 103);
            this.groupBox1.TabIndex = 41;
            this.groupBox1.TabStop = false;
            // 
            // FindLabel
            // 
            this.FindLabel.AutoSize = true;
            this.FindLabel.Location = new System.Drawing.Point(33, 48);
            this.FindLabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.FindLabel.Name = "FindLabel";
            this.FindLabel.Size = new System.Drawing.Size(164, 25);
            this.FindLabel.TabIndex = 43;
            this.FindLabel.Text = "Find by Book ID";
            // 
            // IDFindText
            // 
            this.IDFindText.Location = new System.Drawing.Point(219, 45);
            this.IDFindText.Margin = new System.Windows.Forms.Padding(6);
            this.IDFindText.Name = "IDFindText";
            this.IDFindText.Size = new System.Drawing.Size(146, 31);
            this.IDFindText.TabIndex = 19;
            // 
            // FindButton
            // 
            this.FindButton.Location = new System.Drawing.Point(420, 38);
            this.FindButton.Margin = new System.Windows.Forms.Padding(6);
            this.FindButton.Name = "FindButton";
            this.FindButton.Size = new System.Drawing.Size(150, 44);
            this.FindButton.TabIndex = 20;
            this.FindButton.Text = "Find";
            this.FindButton.UseVisualStyleBackColor = true;
            this.FindButton.Click += new System.EventHandler(this.FindButton_Click);
            // 
            // LastButton
            // 
            this.LastButton.Location = new System.Drawing.Point(830, 457);
            this.LastButton.Margin = new System.Windows.Forms.Padding(6);
            this.LastButton.Name = "LastButton";
            this.LastButton.Size = new System.Drawing.Size(58, 44);
            this.LastButton.TabIndex = 18;
            this.LastButton.Text = ">>";
            this.LastButton.UseVisualStyleBackColor = true;
            this.LastButton.Click += new System.EventHandler(this.LastButton_Click);
            // 
            // NextButton
            // 
            this.NextButton.Location = new System.Drawing.Point(830, 401);
            this.NextButton.Margin = new System.Windows.Forms.Padding(6);
            this.NextButton.Name = "NextButton";
            this.NextButton.Size = new System.Drawing.Size(42, 44);
            this.NextButton.TabIndex = 14;
            this.NextButton.Text = ">";
            this.NextButton.UseVisualStyleBackColor = true;
            this.NextButton.Click += new System.EventHandler(this.NextButton_Click);
            // 
            // FirstButton
            // 
            this.FirstButton.Location = new System.Drawing.Point(106, 457);
            this.FirstButton.Margin = new System.Windows.Forms.Padding(6);
            this.FirstButton.Name = "FirstButton";
            this.FirstButton.Size = new System.Drawing.Size(60, 44);
            this.FirstButton.TabIndex = 15;
            this.FirstButton.Text = "<<";
            this.FirstButton.UseVisualStyleBackColor = true;
            this.FirstButton.Click += new System.EventHandler(this.FirstButton_Click);
            // 
            // PreviousButton
            // 
            this.PreviousButton.Location = new System.Drawing.Point(124, 401);
            this.PreviousButton.Margin = new System.Windows.Forms.Padding(6);
            this.PreviousButton.Name = "PreviousButton";
            this.PreviousButton.Size = new System.Drawing.Size(42, 44);
            this.PreviousButton.TabIndex = 9;
            this.PreviousButton.Text = "<";
            this.PreviousButton.UseVisualStyleBackColor = true;
            this.PreviousButton.Click += new System.EventHandler(this.PreviousButton_Click);
            // 
            // InsertButton
            // 
            this.InsertButton.Location = new System.Drawing.Point(344, 401);
            this.InsertButton.Margin = new System.Windows.Forms.Padding(6);
            this.InsertButton.Name = "InsertButton";
            this.InsertButton.Size = new System.Drawing.Size(150, 44);
            this.InsertButton.TabIndex = 11;
            this.InsertButton.Text = "Insert";
            this.InsertButton.UseVisualStyleBackColor = true;
            this.InsertButton.Click += new System.EventHandler(this.InsertButton_Click);
            // 
            // ResetButton
            // 
            this.ResetButton.Location = new System.Drawing.Point(178, 401);
            this.ResetButton.Margin = new System.Windows.Forms.Padding(6);
            this.ResetButton.Name = "ResetButton";
            this.ResetButton.Size = new System.Drawing.Size(150, 44);
            this.ResetButton.TabIndex = 10;
            this.ResetButton.Text = "&Reset";
            this.ResetButton.UseVisualStyleBackColor = true;
            this.ResetButton.Click += new System.EventHandler(this.ResetButton_Click);
            // 
            // IDText
            // 
            this.IDText.Enabled = false;
            this.IDText.Location = new System.Drawing.Point(506, 6);
            this.IDText.Margin = new System.Windows.Forms.Padding(6);
            this.IDText.Name = "IDText";
            this.IDText.Size = new System.Drawing.Size(104, 31);
            this.IDText.TabIndex = 0;
            // 
            // IDLabel
            // 
            this.IDLabel.AutoSize = true;
            this.IDLabel.Location = new System.Drawing.Point(356, 6);
            this.IDLabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.IDLabel.Name = "IDLabel";
            this.IDLabel.Size = new System.Drawing.Size(87, 25);
            this.IDLabel.TabIndex = 33;
            this.IDLabel.Text = "Book ID";
            // 
            // LoanLabel
            // 
            this.LoanLabel.AutoSize = true;
            this.LoanLabel.Location = new System.Drawing.Point(282, 358);
            this.LoanLabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.LoanLabel.Name = "LoanLabel";
            this.LoanLabel.Size = new System.Drawing.Size(165, 25);
            this.LoanLabel.TabIndex = 31;
            this.LoanLabel.Text = "Number Loaned";
            // 
            // DeleteButton
            // 
            this.DeleteButton.Location = new System.Drawing.Point(668, 401);
            this.DeleteButton.Margin = new System.Windows.Forms.Padding(6);
            this.DeleteButton.Name = "DeleteButton";
            this.DeleteButton.Size = new System.Drawing.Size(150, 44);
            this.DeleteButton.TabIndex = 13;
            this.DeleteButton.Text = "Delete";
            this.DeleteButton.UseVisualStyleBackColor = true;
            this.DeleteButton.Click += new System.EventHandler(this.DeleteButton_Click);
            // 
            // UpdateButton
            // 
            this.UpdateButton.Location = new System.Drawing.Point(506, 401);
            this.UpdateButton.Margin = new System.Windows.Forms.Padding(6);
            this.UpdateButton.Name = "UpdateButton";
            this.UpdateButton.Size = new System.Drawing.Size(150, 44);
            this.UpdateButton.TabIndex = 12;
            this.UpdateButton.Text = "Update";
            this.UpdateButton.UseVisualStyleBackColor = true;
            this.UpdateButton.Click += new System.EventHandler(this.UpdateButton_Click);
            // 
            // ISBNText
            // 
            this.ISBNText.Location = new System.Drawing.Point(506, 272);
            this.ISBNText.Margin = new System.Windows.Forms.Padding(6);
            this.ISBNText.MaxLength = 13;
            this.ISBNText.Name = "ISBNText";
            this.ISBNText.Size = new System.Drawing.Size(196, 31);
            this.ISBNText.TabIndex = 6;
            this.ISBNText.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ISBNText_KeyPress);
            // 
            // StockLabel
            // 
            this.StockLabel.AutoSize = true;
            this.StockLabel.Location = new System.Drawing.Point(324, 315);
            this.StockLabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.StockLabel.Name = "StockLabel";
            this.StockLabel.Size = new System.Drawing.Size(120, 25);
            this.StockLabel.TabIndex = 44;
            this.StockLabel.Text = "Total Stock";
            // 
            // ISBNLabel
            // 
            this.ISBNLabel.AutoSize = true;
            this.ISBNLabel.Location = new System.Drawing.Point(384, 275);
            this.ISBNLabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.ISBNLabel.Name = "ISBNLabel";
            this.ISBNLabel.Size = new System.Drawing.Size(60, 25);
            this.ISBNLabel.TabIndex = 55;
            this.ISBNLabel.Text = "ISBN";
            // 
            // GenreLabel
            // 
            this.GenreLabel.AutoSize = true;
            this.GenreLabel.Location = new System.Drawing.Point(376, 227);
            this.GenreLabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.GenreLabel.Name = "GenreLabel";
            this.GenreLabel.Size = new System.Drawing.Size(71, 25);
            this.GenreLabel.TabIndex = 66;
            this.GenreLabel.Text = "Genre";
            // 
            // AuthorLabel
            // 
            this.AuthorLabel.AutoSize = true;
            this.AuthorLabel.Location = new System.Drawing.Point(372, 92);
            this.AuthorLabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.AuthorLabel.Name = "AuthorLabel";
            this.AuthorLabel.Size = new System.Drawing.Size(75, 25);
            this.AuthorLabel.TabIndex = 54;
            this.AuthorLabel.Text = "Author";
            // 
            // PublisherLabel
            // 
            this.PublisherLabel.AutoSize = true;
            this.PublisherLabel.Location = new System.Drawing.Point(348, 137);
            this.PublisherLabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.PublisherLabel.Name = "PublisherLabel";
            this.PublisherLabel.Size = new System.Drawing.Size(102, 25);
            this.PublisherLabel.TabIndex = 77;
            this.PublisherLabel.Text = "Publisher";
            // 
            // CategoryLabel
            // 
            this.CategoryLabel.AutoSize = true;
            this.CategoryLabel.Location = new System.Drawing.Point(294, 182);
            this.CategoryLabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.CategoryLabel.Name = "CategoryLabel";
            this.CategoryLabel.Size = new System.Drawing.Size(154, 25);
            this.CategoryLabel.TabIndex = 88;
            this.CategoryLabel.Text = "Book Category";
            // 
            // TitleText
            // 
            this.TitleText.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TitleText.Location = new System.Drawing.Point(506, 49);
            this.TitleText.Margin = new System.Windows.Forms.Padding(6);
            this.TitleText.Name = "TitleText";
            this.TitleText.Size = new System.Drawing.Size(602, 31);
            this.TitleText.TabIndex = 1;
            // 
            // TitleLabel
            // 
            this.TitleLabel.AutoSize = true;
            this.TitleLabel.Location = new System.Drawing.Point(344, 49);
            this.TitleLabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.TitleLabel.Name = "TitleLabel";
            this.TitleLabel.Size = new System.Drawing.Size(102, 25);
            this.TitleLabel.TabIndex = 55;
            this.TitleLabel.Text = "BookTitle";
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 667);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1253, 37);
            this.statusStrip1.TabIndex = 91;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(238, 32);
            this.toolStripStatusLabel1.Text = "toolStripStatusLabel1";
            // 
            // BMF
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1253, 704);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.BooksPanel);
            this.Name = "BMF";
            this.Text = "BMF";
            this.BooksPanel.ResumeLayout(false);
            this.BooksPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LoanNumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.StockNumeric)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel BooksPanel;
        protected System.Windows.Forms.NumericUpDown LoanNumeric;
        protected System.Windows.Forms.NumericUpDown StockNumeric;
        protected System.Windows.Forms.ComboBox GenreBox;
        protected System.Windows.Forms.ComboBox CategoryBox;
        protected System.Windows.Forms.ComboBox PublisherBox;
        protected System.Windows.Forms.ComboBox AuthorBox;
        private System.Windows.Forms.GroupBox groupBox1;
        protected System.Windows.Forms.Label FindLabel;
        protected System.Windows.Forms.TextBox IDFindText;
        protected System.Windows.Forms.Button FindButton;
        protected System.Windows.Forms.Button LastButton;
        protected System.Windows.Forms.Button NextButton;
        protected System.Windows.Forms.Button FirstButton;
        protected System.Windows.Forms.Button PreviousButton;
        protected System.Windows.Forms.Button InsertButton;
        protected System.Windows.Forms.Button ResetButton;
        protected System.Windows.Forms.TextBox IDText;
        private System.Windows.Forms.Label IDLabel;
        private System.Windows.Forms.Label LoanLabel;
        protected System.Windows.Forms.Button DeleteButton;
        protected System.Windows.Forms.Button UpdateButton;
        protected System.Windows.Forms.TextBox ISBNText;
        private System.Windows.Forms.Label StockLabel;
        private System.Windows.Forms.Label ISBNLabel;
        private System.Windows.Forms.Label GenreLabel;
        private System.Windows.Forms.Label AuthorLabel;
        private System.Windows.Forms.Label PublisherLabel;
        private System.Windows.Forms.Label CategoryLabel;
        protected System.Windows.Forms.TextBox TitleText;
        private System.Windows.Forms.Label TitleLabel;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
    }
}