﻿namespace SA47_Team01ACAProject
{
    partial class IssueBook2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Transid = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.BooksBorrowed = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.NormalPeriod = new System.Windows.Forms.RadioButton();
            this.SpecialPeriod = new System.Windows.Forms.RadioButton();
            this.LoanStatus = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.Remarks = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.ReturnDate = new System.Windows.Forms.DateTimePicker();
            this.label9 = new System.Windows.Forms.Label();
            this.SearchBook = new System.Windows.Forms.Button();
            this.SearchMember = new System.Windows.Forms.Button();
            this.IssueBookBtn = new System.Windows.Forms.Button();
            this.DueDate = new System.Windows.Forms.DateTimePicker();
            this.IssueDate = new System.Windows.Forms.DateTimePicker();
            this.BookTitle = new System.Windows.Forms.TextBox();
            this.BookId = new System.Windows.Forms.TextBox();
            this.MemName = new System.Windows.Forms.TextBox();
            this.MemId = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.groupBox1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Transid
            // 
            this.Transid.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Transid.Location = new System.Drawing.Point(366, 515);
            this.Transid.Margin = new System.Windows.Forms.Padding(4);
            this.Transid.Name = "Transid";
            this.Transid.ReadOnly = true;
            this.Transid.Size = new System.Drawing.Size(182, 38);
            this.Transid.TabIndex = 123;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(82, 518);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(194, 32);
            this.label8.TabIndex = 122;
            this.label8.Text = "Transaction Id";
            // 
            // BooksBorrowed
            // 
            this.BooksBorrowed.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BooksBorrowed.Location = new System.Drawing.Point(864, 518);
            this.BooksBorrowed.Margin = new System.Windows.Forms.Padding(4);
            this.BooksBorrowed.Name = "BooksBorrowed";
            this.BooksBorrowed.ReadOnly = true;
            this.BooksBorrowed.Size = new System.Drawing.Size(180, 38);
            this.BooksBorrowed.TabIndex = 120;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(615, 521);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(222, 32);
            this.label12.TabIndex = 119;
            this.label12.Text = "Books Borrowed";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(82, 253);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(169, 32);
            this.label11.TabIndex = 118;
            this.label11.Text = "Loan Period";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.NormalPeriod);
            this.groupBox1.Controls.Add(this.SpecialPeriod);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(368, 227);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(509, 85);
            this.groupBox1.TabIndex = 117;
            this.groupBox1.TabStop = false;
            // 
            // NormalPeriod
            // 
            this.NormalPeriod.AutoSize = true;
            this.NormalPeriod.Location = new System.Drawing.Point(26, 36);
            this.NormalPeriod.Margin = new System.Windows.Forms.Padding(4);
            this.NormalPeriod.Name = "NormalPeriod";
            this.NormalPeriod.Size = new System.Drawing.Size(201, 33);
            this.NormalPeriod.TabIndex = 1;
            this.NormalPeriod.TabStop = true;
            this.NormalPeriod.Text = "Normal Period";
            this.NormalPeriod.UseVisualStyleBackColor = true;
            // 
            // SpecialPeriod
            // 
            this.SpecialPeriod.AutoSize = true;
            this.SpecialPeriod.Location = new System.Drawing.Point(277, 36);
            this.SpecialPeriod.Margin = new System.Windows.Forms.Padding(4);
            this.SpecialPeriod.Name = "SpecialPeriod";
            this.SpecialPeriod.Size = new System.Drawing.Size(203, 33);
            this.SpecialPeriod.TabIndex = 0;
            this.SpecialPeriod.TabStop = true;
            this.SpecialPeriod.Text = "Special Period";
            this.SpecialPeriod.UseVisualStyleBackColor = true;
            // 
            // LoanStatus
            // 
            this.LoanStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.LoanStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LoanStatus.FormattingEnabled = true;
            this.LoanStatus.Items.AddRange(new object[] {
            "In",
            "Out"});
            this.LoanStatus.Location = new System.Drawing.Point(864, 392);
            this.LoanStatus.Margin = new System.Windows.Forms.Padding(4);
            this.LoanStatus.Name = "LoanStatus";
            this.LoanStatus.Size = new System.Drawing.Size(180, 39);
            this.LoanStatus.TabIndex = 116;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(615, 395);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(167, 32);
            this.label7.TabIndex = 115;
            this.label7.Text = "Loan Status";
            // 
            // Remarks
            // 
            this.Remarks.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Remarks.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Remarks.FormattingEnabled = true;
            this.Remarks.Items.AddRange(new object[] {
            "-",
            "Overdue",
            "Extension Requested",
            "Extension Approved",
            "Extension Rejected"});
            this.Remarks.Location = new System.Drawing.Point(864, 457);
            this.Remarks.Margin = new System.Windows.Forms.Padding(4);
            this.Remarks.Name = "Remarks";
            this.Remarks.Size = new System.Drawing.Size(180, 39);
            this.Remarks.TabIndex = 114;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(615, 460);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(127, 32);
            this.label10.TabIndex = 113;
            this.label10.Text = "Remarks";
            // 
            // ReturnDate
            // 
            this.ReturnDate.Enabled = false;
            this.ReturnDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ReturnDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.ReturnDate.Location = new System.Drawing.Point(368, 454);
            this.ReturnDate.Margin = new System.Windows.Forms.Padding(4);
            this.ReturnDate.Name = "ReturnDate";
            this.ReturnDate.Size = new System.Drawing.Size(180, 38);
            this.ReturnDate.TabIndex = 112;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(82, 457);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(254, 32);
            this.label9.TabIndex = 111;
            this.label9.Text = "Actual Return Date";
            // 
            // SearchBook
            // 
            this.SearchBook.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchBook.Location = new System.Drawing.Point(524, 124);
            this.SearchBook.Margin = new System.Windows.Forms.Padding(4);
            this.SearchBook.Name = "SearchBook";
            this.SearchBook.Size = new System.Drawing.Size(52, 46);
            this.SearchBook.TabIndex = 110;
            this.SearchBook.Text = "...";
            this.SearchBook.UseVisualStyleBackColor = true;
            this.SearchBook.Click += new System.EventHandler(this.SearchBook_Click);
            // 
            // SearchMember
            // 
            this.SearchMember.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchMember.Location = new System.Drawing.Point(524, 24);
            this.SearchMember.Margin = new System.Windows.Forms.Padding(4);
            this.SearchMember.Name = "SearchMember";
            this.SearchMember.Size = new System.Drawing.Size(52, 46);
            this.SearchMember.TabIndex = 109;
            this.SearchMember.Text = "...";
            this.SearchMember.UseVisualStyleBackColor = true;
            this.SearchMember.Click += new System.EventHandler(this.SearchMember_Click);
            // 
            // IssueBookBtn
            // 
            this.IssueBookBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.IssueBookBtn.Location = new System.Drawing.Point(864, 595);
            this.IssueBookBtn.Margin = new System.Windows.Forms.Padding(4);
            this.IssueBookBtn.Name = "IssueBookBtn";
            this.IssueBookBtn.Size = new System.Drawing.Size(180, 44);
            this.IssueBookBtn.TabIndex = 108;
            this.IssueBookBtn.Text = "Issue Book";
            this.IssueBookBtn.UseVisualStyleBackColor = true;
            this.IssueBookBtn.Click += new System.EventHandler(this.IssueBookBtn_Click);
            // 
            // DueDate
            // 
            this.DueDate.Enabled = false;
            this.DueDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DueDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.DueDate.Location = new System.Drawing.Point(368, 389);
            this.DueDate.Margin = new System.Windows.Forms.Padding(4);
            this.DueDate.Name = "DueDate";
            this.DueDate.Size = new System.Drawing.Size(180, 38);
            this.DueDate.TabIndex = 107;
            // 
            // IssueDate
            // 
            this.IssueDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IssueDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.IssueDate.Location = new System.Drawing.Point(368, 329);
            this.IssueDate.Margin = new System.Windows.Forms.Padding(4);
            this.IssueDate.MinDate = new System.DateTime(2018, 9, 26, 0, 0, 0, 0);
            this.IssueDate.Name = "IssueDate";
            this.IssueDate.Size = new System.Drawing.Size(180, 38);
            this.IssueDate.TabIndex = 106;
            this.IssueDate.Value = new System.DateTime(2018, 9, 26, 6, 42, 27, 0);
            // 
            // BookTitle
            // 
            this.BookTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BookTitle.Location = new System.Drawing.Point(368, 178);
            this.BookTitle.Margin = new System.Windows.Forms.Padding(4);
            this.BookTitle.Name = "BookTitle";
            this.BookTitle.ReadOnly = true;
            this.BookTitle.Size = new System.Drawing.Size(696, 38);
            this.BookTitle.TabIndex = 105;
            // 
            // BookId
            // 
            this.BookId.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BookId.Location = new System.Drawing.Point(368, 128);
            this.BookId.Margin = new System.Windows.Forms.Padding(4);
            this.BookId.Name = "BookId";
            this.BookId.Size = new System.Drawing.Size(148, 38);
            this.BookId.TabIndex = 104;
            this.BookId.TextChanged += new System.EventHandler(this.BookId_TextChanged);
            this.BookId.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.BookId_KeyPress);
            // 
            // MemName
            // 
            this.MemName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MemName.Location = new System.Drawing.Point(368, 75);
            this.MemName.Margin = new System.Windows.Forms.Padding(4);
            this.MemName.Name = "MemName";
            this.MemName.ReadOnly = true;
            this.MemName.Size = new System.Drawing.Size(332, 38);
            this.MemName.TabIndex = 103;
            // 
            // MemId
            // 
            this.MemId.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MemId.Location = new System.Drawing.Point(368, 28);
            this.MemId.Margin = new System.Windows.Forms.Padding(4);
            this.MemId.Name = "MemId";
            this.MemId.Size = new System.Drawing.Size(148, 38);
            this.MemId.TabIndex = 102;
            this.MemId.TextChanged += new System.EventHandler(this.MemId_TextChanged);
            this.MemId.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MemId_KeyPress);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(82, 392);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(134, 32);
            this.label6.TabIndex = 101;
            this.label6.Text = "Due Date";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(82, 329);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(180, 32);
            this.label5.TabIndex = 100;
            this.label5.Text = "Date of Issue";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(82, 178);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(142, 32);
            this.label4.TabIndex = 99;
            this.label4.Text = "Book Title";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(82, 131);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(114, 32);
            this.label3.TabIndex = 98;
            this.label3.Text = "Book ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(82, 81);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(200, 32);
            this.label2.TabIndex = 97;
            this.label2.Text = "Member Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(82, 31);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(148, 32);
            this.label1.TabIndex = 96;
            this.label1.Text = "Member Id";
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 715);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1142, 37);
            this.statusStrip1.TabIndex = 124;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(238, 32);
            this.toolStripStatusLabel1.Text = "toolStripStatusLabel1";
            // 
            // IssueBook2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1142, 752);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.Transid);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.BooksBorrowed);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.LoanStatus);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.Remarks);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.ReturnDate);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.SearchBook);
            this.Controls.Add(this.SearchMember);
            this.Controls.Add(this.IssueBookBtn);
            this.Controls.Add(this.DueDate);
            this.Controls.Add(this.IssueDate);
            this.Controls.Add(this.BookTitle);
            this.Controls.Add(this.BookId);
            this.Controls.Add(this.MemName);
            this.Controls.Add(this.MemId);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "IssueBook2";
            this.Text = "IssueBook2";
            this.Load += new System.EventHandler(this.IssueBook2_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Transid;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox BooksBorrowed;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton NormalPeriod;
        private System.Windows.Forms.RadioButton SpecialPeriod;
        private System.Windows.Forms.ComboBox LoanStatus;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox Remarks;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DateTimePicker ReturnDate;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button SearchBook;
        private System.Windows.Forms.Button SearchMember;
        private System.Windows.Forms.Button IssueBookBtn;
        private System.Windows.Forms.DateTimePicker DueDate;
        private System.Windows.Forms.DateTimePicker IssueDate;
        private System.Windows.Forms.TextBox BookTitle;
        private System.Windows.Forms.TextBox BookId;
        public System.Windows.Forms.TextBox MemName;
        public System.Windows.Forms.TextBox MemId;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
    }
}