﻿namespace SA47_Team01ACAProject
{
    partial class BookSearchForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BookSearchForm));
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.SearchISDN = new System.Windows.Forms.ComboBox();
            this.SearchBookID = new System.Windows.Forms.ComboBox();
            this.SearchPublisher = new System.Windows.Forms.ComboBox();
            this.SearchAuthor = new System.Windows.Forms.ComboBox();
            this.SearchGenre = new System.Windows.Forms.ComboBox();
            this.SearchCategory = new System.Windows.Forms.ComboBox();
            this.SearchForLoanQty = new System.Windows.Forms.Button();
            this.SearchForTotal = new System.Windows.Forms.Button();
            this.SearchForPublisher = new System.Windows.Forms.Button();
            this.SearchForAuthor = new System.Windows.Forms.Button();
            this.SearchForISDN = new System.Windows.Forms.Button();
            this.SearchForGenre = new System.Windows.Forms.Button();
            this.SearchForCategory = new System.Windows.Forms.Button();
            this.SearchForBookID = new System.Windows.Forms.Button();
            this.TitleofBook = new System.Windows.Forms.Label();
            this.SearchBook = new System.Windows.Forms.ComboBox();
            this.SearchLoanedQty = new System.Windows.Forms.TextBox();
            this.SearchForBook = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.IDofBook = new System.Windows.Forms.Label();
            this.SearchTotalStock = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.ISDNofBook = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.SearchMltGenre = new System.Windows.Forms.ComboBox();
            this.SearchMltCategory = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.SearchMltAuthor = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.SearchMltCatGenAut = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.SearchMltReset = new System.Windows.Forms.Button();
            this.SearchMltLoanedQty = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.SearchMltTotalStock = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.SelectButton = new System.Windows.Forms.Button();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.statusStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.SearchISDN);
            this.groupBox2.Controls.Add(this.SearchBookID);
            this.groupBox2.Controls.Add(this.SearchPublisher);
            this.groupBox2.Controls.Add(this.SearchAuthor);
            this.groupBox2.Controls.Add(this.SearchGenre);
            this.groupBox2.Controls.Add(this.SearchCategory);
            this.groupBox2.Controls.Add(this.SearchForLoanQty);
            this.groupBox2.Controls.Add(this.SearchForTotal);
            this.groupBox2.Controls.Add(this.SearchForPublisher);
            this.groupBox2.Controls.Add(this.SearchForAuthor);
            this.groupBox2.Controls.Add(this.SearchForISDN);
            this.groupBox2.Controls.Add(this.SearchForGenre);
            this.groupBox2.Controls.Add(this.SearchForCategory);
            this.groupBox2.Controls.Add(this.SearchForBookID);
            this.groupBox2.Controls.Add(this.TitleofBook);
            this.groupBox2.Controls.Add(this.SearchBook);
            this.groupBox2.Controls.Add(this.SearchLoanedQty);
            this.groupBox2.Controls.Add(this.SearchForBook);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.IDofBook);
            this.groupBox2.Controls.Add(this.SearchTotalStock);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.ISDNofBook);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(25, 29);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox2.Size = new System.Drawing.Size(333, 377);
            this.groupBox2.TabIndex = 30;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Single Search Criteria";
            // 
            // SearchISDN
            // 
            this.SearchISDN.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.SearchISDN.FormattingEnabled = true;
            this.SearchISDN.Location = new System.Drawing.Point(110, 193);
            this.SearchISDN.Margin = new System.Windows.Forms.Padding(2);
            this.SearchISDN.MaxLength = 13;
            this.SearchISDN.Name = "SearchISDN";
            this.SearchISDN.Size = new System.Drawing.Size(143, 25);
            this.SearchISDN.TabIndex = 9;
            this.SearchISDN.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.SearchISDN_KeyPress);
            // 
            // SearchBookID
            // 
            this.SearchBookID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.SearchBookID.FormattingEnabled = true;
            this.SearchBookID.Location = new System.Drawing.Point(108, 40);
            this.SearchBookID.Margin = new System.Windows.Forms.Padding(2);
            this.SearchBookID.Name = "SearchBookID";
            this.SearchBookID.Size = new System.Drawing.Size(68, 25);
            this.SearchBookID.TabIndex = 0;
            // 
            // SearchPublisher
            // 
            this.SearchPublisher.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.SearchPublisher.FormattingEnabled = true;
            this.SearchPublisher.Location = new System.Drawing.Point(108, 269);
            this.SearchPublisher.Margin = new System.Windows.Forms.Padding(2);
            this.SearchPublisher.Name = "SearchPublisher";
            this.SearchPublisher.Size = new System.Drawing.Size(144, 25);
            this.SearchPublisher.TabIndex = 13;
            // 
            // SearchAuthor
            // 
            this.SearchAuthor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.SearchAuthor.FormattingEnabled = true;
            this.SearchAuthor.Location = new System.Drawing.Point(110, 227);
            this.SearchAuthor.Margin = new System.Windows.Forms.Padding(2);
            this.SearchAuthor.Name = "SearchAuthor";
            this.SearchAuthor.Size = new System.Drawing.Size(144, 25);
            this.SearchAuthor.TabIndex = 11;
            // 
            // SearchGenre
            // 
            this.SearchGenre.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.SearchGenre.FormattingEnabled = true;
            this.SearchGenre.Location = new System.Drawing.Point(110, 152);
            this.SearchGenre.Margin = new System.Windows.Forms.Padding(2);
            this.SearchGenre.Name = "SearchGenre";
            this.SearchGenre.Size = new System.Drawing.Size(144, 25);
            this.SearchGenre.TabIndex = 7;
            // 
            // SearchCategory
            // 
            this.SearchCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.SearchCategory.FormattingEnabled = true;
            this.SearchCategory.Location = new System.Drawing.Point(110, 118);
            this.SearchCategory.Margin = new System.Windows.Forms.Padding(2);
            this.SearchCategory.Name = "SearchCategory";
            this.SearchCategory.Size = new System.Drawing.Size(144, 25);
            this.SearchCategory.TabIndex = 5;
            // 
            // SearchForLoanQty
            // 
            this.SearchForLoanQty.Location = new System.Drawing.Point(164, 328);
            this.SearchForLoanQty.Margin = new System.Windows.Forms.Padding(2);
            this.SearchForLoanQty.Name = "SearchForLoanQty";
            this.SearchForLoanQty.Size = new System.Drawing.Size(25, 22);
            this.SearchForLoanQty.TabIndex = 18;
            this.SearchForLoanQty.Text = "...";
            this.SearchForLoanQty.UseVisualStyleBackColor = true;
            this.SearchForLoanQty.Click += new System.EventHandler(this.SearchForLoanQty_Click);
            // 
            // SearchForTotal
            // 
            this.SearchForTotal.Location = new System.Drawing.Point(164, 303);
            this.SearchForTotal.Margin = new System.Windows.Forms.Padding(2);
            this.SearchForTotal.Name = "SearchForTotal";
            this.SearchForTotal.Size = new System.Drawing.Size(25, 22);
            this.SearchForTotal.TabIndex = 16;
            this.SearchForTotal.Text = "...";
            this.SearchForTotal.UseVisualStyleBackColor = true;
            this.SearchForTotal.Click += new System.EventHandler(this.SearchForTotal_Click);
            // 
            // SearchForPublisher
            // 
            this.SearchForPublisher.Location = new System.Drawing.Point(258, 269);
            this.SearchForPublisher.Margin = new System.Windows.Forms.Padding(2);
            this.SearchForPublisher.Name = "SearchForPublisher";
            this.SearchForPublisher.Size = new System.Drawing.Size(25, 22);
            this.SearchForPublisher.TabIndex = 14;
            this.SearchForPublisher.Text = "...";
            this.SearchForPublisher.UseVisualStyleBackColor = true;
            this.SearchForPublisher.Click += new System.EventHandler(this.SearchForPublisher_Click);
            // 
            // SearchForAuthor
            // 
            this.SearchForAuthor.Location = new System.Drawing.Point(258, 229);
            this.SearchForAuthor.Margin = new System.Windows.Forms.Padding(2);
            this.SearchForAuthor.Name = "SearchForAuthor";
            this.SearchForAuthor.Size = new System.Drawing.Size(25, 22);
            this.SearchForAuthor.TabIndex = 12;
            this.SearchForAuthor.Text = "...";
            this.SearchForAuthor.UseVisualStyleBackColor = true;
            this.SearchForAuthor.Click += new System.EventHandler(this.SearchForAuthor_Click);
            // 
            // SearchForISDN
            // 
            this.SearchForISDN.Location = new System.Drawing.Point(258, 194);
            this.SearchForISDN.Margin = new System.Windows.Forms.Padding(2);
            this.SearchForISDN.Name = "SearchForISDN";
            this.SearchForISDN.Size = new System.Drawing.Size(25, 22);
            this.SearchForISDN.TabIndex = 10;
            this.SearchForISDN.Text = "...";
            this.SearchForISDN.UseVisualStyleBackColor = true;
            this.SearchForISDN.Click += new System.EventHandler(this.SearchForISDN_Click);
            // 
            // SearchForGenre
            // 
            this.SearchForGenre.Location = new System.Drawing.Point(258, 152);
            this.SearchForGenre.Margin = new System.Windows.Forms.Padding(2);
            this.SearchForGenre.Name = "SearchForGenre";
            this.SearchForGenre.Size = new System.Drawing.Size(25, 22);
            this.SearchForGenre.TabIndex = 8;
            this.SearchForGenre.Text = "...";
            this.SearchForGenre.UseVisualStyleBackColor = true;
            this.SearchForGenre.Click += new System.EventHandler(this.SearchForGenre_Click);
            // 
            // SearchForCategory
            // 
            this.SearchForCategory.Location = new System.Drawing.Point(267, 116);
            this.SearchForCategory.Margin = new System.Windows.Forms.Padding(2);
            this.SearchForCategory.Name = "SearchForCategory";
            this.SearchForCategory.Size = new System.Drawing.Size(25, 22);
            this.SearchForCategory.TabIndex = 6;
            this.SearchForCategory.Text = "...";
            this.SearchForCategory.UseVisualStyleBackColor = true;
            this.SearchForCategory.Click += new System.EventHandler(this.SearchForCategory_Click);
            // 
            // SearchForBookID
            // 
            this.SearchForBookID.Location = new System.Drawing.Point(180, 43);
            this.SearchForBookID.Margin = new System.Windows.Forms.Padding(2);
            this.SearchForBookID.Name = "SearchForBookID";
            this.SearchForBookID.Size = new System.Drawing.Size(25, 22);
            this.SearchForBookID.TabIndex = 1;
            this.SearchForBookID.Text = "...";
            this.SearchForBookID.UseVisualStyleBackColor = true;
            this.SearchForBookID.Click += new System.EventHandler(this.SearchForBookID_Click);
            // 
            // TitleofBook
            // 
            this.TitleofBook.AutoSize = true;
            this.TitleofBook.Location = new System.Drawing.Point(5, 83);
            this.TitleofBook.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.TitleofBook.Name = "TitleofBook";
            this.TitleofBook.Size = new System.Drawing.Size(71, 17);
            this.TitleofBook.TabIndex = 0;
            this.TitleofBook.Text = "Book Title";
            // 
            // SearchBook
            // 
            this.SearchBook.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.SearchBook.FormattingEnabled = true;
            this.SearchBook.ItemHeight = 17;
            this.SearchBook.Location = new System.Drawing.Point(108, 80);
            this.SearchBook.Margin = new System.Windows.Forms.Padding(2);
            this.SearchBook.Name = "SearchBook";
            this.SearchBook.Size = new System.Drawing.Size(192, 25);
            this.SearchBook.TabIndex = 2;
            // 
            // SearchLoanedQty
            // 
            this.SearchLoanedQty.Location = new System.Drawing.Point(110, 329);
            this.SearchLoanedQty.Margin = new System.Windows.Forms.Padding(2);
            this.SearchLoanedQty.Name = "SearchLoanedQty";
            this.SearchLoanedQty.Size = new System.Drawing.Size(50, 23);
            this.SearchLoanedQty.TabIndex = 17;
            this.SearchLoanedQty.Text = "0";
            this.SearchLoanedQty.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.SearchLoanedQty_KeyPress);
            // 
            // SearchForBook
            // 
            this.SearchForBook.Location = new System.Drawing.Point(303, 77);
            this.SearchForBook.Margin = new System.Windows.Forms.Padding(2);
            this.SearchForBook.Name = "SearchForBook";
            this.SearchForBook.Size = new System.Drawing.Size(25, 22);
            this.SearchForBook.TabIndex = 3;
            this.SearchForBook.Text = "...";
            this.SearchForBook.UseVisualStyleBackColor = true;
            this.SearchForBook.Click += new System.EventHandler(this.SearchForBook_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(5, 335);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(82, 17);
            this.label6.TabIndex = 19;
            this.label6.Text = "Loaned Qty";
            // 
            // IDofBook
            // 
            this.IDofBook.AutoSize = true;
            this.IDofBook.Location = new System.Drawing.Point(7, 50);
            this.IDofBook.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.IDofBook.Name = "IDofBook";
            this.IDofBook.Size = new System.Drawing.Size(57, 17);
            this.IDofBook.TabIndex = 5;
            this.IDofBook.Text = "Book ID";
            // 
            // SearchTotalStock
            // 
            this.SearchTotalStock.Location = new System.Drawing.Point(110, 303);
            this.SearchTotalStock.Margin = new System.Windows.Forms.Padding(2);
            this.SearchTotalStock.MaxLength = 5;
            this.SearchTotalStock.Name = "SearchTotalStock";
            this.SearchTotalStock.Size = new System.Drawing.Size(50, 23);
            this.SearchTotalStock.TabIndex = 15;
            this.SearchTotalStock.Text = "0";
            this.SearchTotalStock.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.SearchTotalStock_KeyPress);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(7, 306);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(79, 17);
            this.label5.TabIndex = 17;
            this.label5.Text = "Total Stock";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(5, 159);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 17);
            this.label4.TabIndex = 15;
            this.label4.Text = "Genre";
            // 
            // ISDNofBook
            // 
            this.ISDNofBook.AutoSize = true;
            this.ISDNofBook.Location = new System.Drawing.Point(7, 196);
            this.ISDNofBook.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ISDNofBook.Name = "ISDNofBook";
            this.ISDNofBook.Size = new System.Drawing.Size(40, 17);
            this.ISDNofBook.TabIndex = 7;
            this.ISDNofBook.Text = "ISDN";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(5, 121);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(101, 17);
            this.label3.TabIndex = 13;
            this.label3.Text = "Book Category";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 236);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 17);
            this.label1.TabIndex = 9;
            this.label1.Text = "Author";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(5, 272);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 17);
            this.label2.TabIndex = 11;
            this.label2.Text = "Publisher";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6,
            this.Column7,
            this.Column8,
            this.Column9,
            this.Column10,
            this.Column11});
            this.dataGridView1.Location = new System.Drawing.Point(19, 411);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(693, 146);
            this.dataGridView1.TabIndex = 31;
            // 
            // Column1
            // 
            this.Column1.DataPropertyName = "BookID";
            this.Column1.HeaderText = "Book ID";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // Column2
            // 
            this.Column2.DataPropertyName = "BookTitle";
            this.Column2.HeaderText = "Book Title";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            // 
            // Column3
            // 
            this.Column3.DataPropertyName = "Author";
            this.Column3.HeaderText = "Author";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            // 
            // Column4
            // 
            this.Column4.DataPropertyName = "Publisher";
            this.Column4.HeaderText = "Publisher";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            // 
            // Column5
            // 
            this.Column5.DataPropertyName = "BookCategory";
            this.Column5.HeaderText = "Category";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            // 
            // Column6
            // 
            this.Column6.DataPropertyName = "Genre";
            this.Column6.HeaderText = "Genre";
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            // 
            // Column7
            // 
            this.Column7.DataPropertyName = "ISBN";
            this.Column7.HeaderText = "ISBN";
            this.Column7.Name = "Column7";
            this.Column7.ReadOnly = true;
            // 
            // Column8
            // 
            this.Column8.DataPropertyName = "TotalStock";
            this.Column8.HeaderText = "Total Stock";
            this.Column8.Name = "Column8";
            this.Column8.ReadOnly = true;
            // 
            // Column9
            // 
            this.Column9.DataPropertyName = "NumberLoaned";
            this.Column9.HeaderText = "Loan Qty";
            this.Column9.Name = "Column9";
            this.Column9.ReadOnly = true;
            // 
            // Column10
            // 
            this.Column10.DataPropertyName = "Author1";
            this.Column10.HeaderText = "Authors";
            this.Column10.Name = "Column10";
            this.Column10.ReadOnly = true;
            this.Column10.Visible = false;
            // 
            // Column11
            // 
            this.Column11.DataPropertyName = "Publisher1";
            this.Column11.HeaderText = "Publishers";
            this.Column11.Name = "Column11";
            this.Column11.ReadOnly = true;
            this.Column11.Visible = false;
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 656);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Padding = new System.Windows.Forms.Padding(1, 0, 10, 0);
            this.statusStrip1.Size = new System.Drawing.Size(748, 22);
            this.statusStrip1.TabIndex = 32;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(118, 17);
            this.toolStripStatusLabel1.Text = "toolStripStatusLabel1";
            // 
            // SearchMltGenre
            // 
            this.SearchMltGenre.BackColor = System.Drawing.SystemColors.Window;
            this.SearchMltGenre.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.SearchMltGenre.FormattingEnabled = true;
            this.SearchMltGenre.Location = new System.Drawing.Point(144, 93);
            this.SearchMltGenre.Margin = new System.Windows.Forms.Padding(2);
            this.SearchMltGenre.Name = "SearchMltGenre";
            this.SearchMltGenre.Size = new System.Drawing.Size(144, 25);
            this.SearchMltGenre.TabIndex = 20;
            // 
            // SearchMltCategory
            // 
            this.SearchMltCategory.AllowDrop = true;
            this.SearchMltCategory.BackColor = System.Drawing.SystemColors.Window;
            this.SearchMltCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.SearchMltCategory.ForeColor = System.Drawing.SystemColors.WindowText;
            this.SearchMltCategory.FormattingEnabled = true;
            this.SearchMltCategory.Location = new System.Drawing.Point(144, 58);
            this.SearchMltCategory.Margin = new System.Windows.Forms.Padding(2);
            this.SearchMltCategory.Name = "SearchMltCategory";
            this.SearchMltCategory.Size = new System.Drawing.Size(144, 25);
            this.SearchMltCategory.TabIndex = 19;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(39, 97);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(48, 17);
            this.label7.TabIndex = 34;
            this.label7.Text = "Genre";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(39, 58);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(101, 17);
            this.label8.TabIndex = 33;
            this.label8.Text = "Book Category";
            // 
            // SearchMltAuthor
            // 
            this.SearchMltAuthor.BackColor = System.Drawing.SystemColors.Window;
            this.SearchMltAuthor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.SearchMltAuthor.FormattingEnabled = true;
            this.SearchMltAuthor.Location = new System.Drawing.Point(144, 135);
            this.SearchMltAuthor.Margin = new System.Windows.Forms.Padding(2);
            this.SearchMltAuthor.Name = "SearchMltAuthor";
            this.SearchMltAuthor.Size = new System.Drawing.Size(144, 25);
            this.SearchMltAuthor.TabIndex = 21;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(40, 141);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(50, 17);
            this.label9.TabIndex = 35;
            this.label9.Text = "Author";
            // 
            // SearchMltCatGenAut
            // 
            this.SearchMltCatGenAut.Location = new System.Drawing.Point(148, 272);
            this.SearchMltCatGenAut.Margin = new System.Windows.Forms.Padding(2);
            this.SearchMltCatGenAut.Name = "SearchMltCatGenAut";
            this.SearchMltCatGenAut.Size = new System.Drawing.Size(111, 33);
            this.SearchMltCatGenAut.TabIndex = 25;
            this.SearchMltCatGenAut.Text = "Search";
            this.SearchMltCatGenAut.UseVisualStyleBackColor = true;
            this.SearchMltCatGenAut.Click += new System.EventHandler(this.SearchMltCatGenAut_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.SearchMltReset);
            this.groupBox1.Controls.Add(this.SearchMltCatGenAut);
            this.groupBox1.Controls.Add(this.SearchMltAuthor);
            this.groupBox1.Controls.Add(this.SearchMltLoanedQty);
            this.groupBox1.Controls.Add(this.SearchMltGenre);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.SearchMltTotalStock);
            this.groupBox1.Controls.Add(this.SearchMltCategory);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(376, 29);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox1.Size = new System.Drawing.Size(326, 377);
            this.groupBox1.TabIndex = 40;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Multiple Search Criteria";
            // 
            // SearchMltReset
            // 
            this.SearchMltReset.Location = new System.Drawing.Point(72, 272);
            this.SearchMltReset.Margin = new System.Windows.Forms.Padding(2);
            this.SearchMltReset.Name = "SearchMltReset";
            this.SearchMltReset.Size = new System.Drawing.Size(72, 33);
            this.SearchMltReset.TabIndex = 24;
            this.SearchMltReset.Text = "Reset";
            this.SearchMltReset.UseVisualStyleBackColor = true;
            this.SearchMltReset.Click += new System.EventHandler(this.SearchMltReset_Click);
            // 
            // SearchMltLoanedQty
            // 
            this.SearchMltLoanedQty.Location = new System.Drawing.Point(144, 212);
            this.SearchMltLoanedQty.Margin = new System.Windows.Forms.Padding(2);
            this.SearchMltLoanedQty.Name = "SearchMltLoanedQty";
            this.SearchMltLoanedQty.Size = new System.Drawing.Size(50, 23);
            this.SearchMltLoanedQty.TabIndex = 23;
            this.SearchMltLoanedQty.Text = "0";
            this.SearchMltLoanedQty.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.SearchMltLoanedQty_KeyPress);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(39, 214);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(82, 17);
            this.label10.TabIndex = 37;
            this.label10.Text = "Loaned Qty";
            // 
            // SearchMltTotalStock
            // 
            this.SearchMltTotalStock.Location = new System.Drawing.Point(144, 185);
            this.SearchMltTotalStock.Margin = new System.Windows.Forms.Padding(2);
            this.SearchMltTotalStock.Name = "SearchMltTotalStock";
            this.SearchMltTotalStock.Size = new System.Drawing.Size(50, 23);
            this.SearchMltTotalStock.TabIndex = 22;
            this.SearchMltTotalStock.Text = "0";
            this.SearchMltTotalStock.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.SearchMltTotalStock_KeyPress);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(40, 185);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(79, 17);
            this.label11.TabIndex = 35;
            this.label11.Text = "Total Stock";
            // 
            // SelectButton
            // 
            this.SelectButton.Location = new System.Drawing.Point(328, 586);
            this.SelectButton.Name = "SelectButton";
            this.SelectButton.Size = new System.Drawing.Size(75, 23);
            this.SelectButton.TabIndex = 41;
            this.SelectButton.Text = "Select Data";
            this.SelectButton.UseVisualStyleBackColor = true;
            this.SelectButton.Click += new System.EventHandler(this.SelectButton_Click);
            // 
            // BookSearchForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Pink;
            this.ClientSize = new System.Drawing.Size(748, 678);
            this.Controls.Add(this.SelectButton);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.groupBox2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "BookSearchForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Book Search Form";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button SearchForLoanQty;
        private System.Windows.Forms.Button SearchForTotal;
        private System.Windows.Forms.Button SearchForPublisher;
        private System.Windows.Forms.Button SearchForAuthor;
        private System.Windows.Forms.Button SearchForISDN;
        private System.Windows.Forms.Button SearchForGenre;
        private System.Windows.Forms.Button SearchForCategory;
        private System.Windows.Forms.Button SearchForBookID;
        private System.Windows.Forms.Label TitleofBook;
        private System.Windows.Forms.ComboBox SearchBook;
        private System.Windows.Forms.TextBox SearchLoanedQty;
        private System.Windows.Forms.Button SearchForBook;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label IDofBook;
        private System.Windows.Forms.TextBox SearchTotalStock;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label ISDNofBook;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.ComboBox SearchCategory;
        private System.Windows.Forms.ComboBox SearchGenre;
        private System.Windows.Forms.ComboBox SearchAuthor;
        private System.Windows.Forms.ComboBox SearchPublisher;
        private System.Windows.Forms.ComboBox SearchBookID;
        private System.Windows.Forms.ComboBox SearchISDN;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ComboBox SearchMltGenre;
        private System.Windows.Forms.ComboBox SearchMltCategory;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox SearchMltAuthor;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button SearchMltCatGenAut;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox SearchMltLoanedQty;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox SearchMltTotalStock;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button SearchMltReset;
        private System.Windows.Forms.Button SelectButton;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
    }
}

