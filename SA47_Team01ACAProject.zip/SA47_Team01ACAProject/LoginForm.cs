﻿using SA47_Team01ACAProject;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SA47_Team01ACAProject
{
    public partial class LoginForm : Form
    {
        SA47_Team01aCADatabaseEntities context = new SA47_Team01aCADatabaseEntities();
        public LoginForm()
        {
            InitializeComponent();
        }

        private void Login_Click(object sender, EventArgs e)
        {        
            List<UserMaster> cred = new List<UserMaster>();

            cred = context.UserMasters.ToList();
            int index = 0;
            bool check = false;
            int test = 0;
            for(int i = 0; i < cred.Count; i++)
            {
                if (UsernameTB.Text == cred[i].LoginName && PasswordTB.Text == cred[i].Password)
                {
                    check = true;
                    index = i;
                    test = cred[i].EmployeeID;
                    break;
                }
            }

            if (check == true)
            {
                if (context.Employees.Where(x => x.EmployeeID == test).First().Designation.ToString() == "Chief Librarian")
                {
                    CLibLandingPage f = new CLibLandingPage();
                    f.MdiParent = this.ParentForm;
                    f.WindowState = FormWindowState.Maximized;
                    f.Show();
                }

                else if (context.Employees.Where(x => x.EmployeeID == test).First().Designation.ToString() == "Librarian")
                {
                    LibLandingPage f = new LibLandingPage();
                    f.MdiParent = this.ParentForm;
                    f.WindowState = FormWindowState.Maximized;
                    f.Show();
                }
                else
                {
                    MessageBox.Show("Something is wrong!");
                }
            }
            else
            {
                MessageBox.Show("Wrong credentials!");
            }
        }
    }
}