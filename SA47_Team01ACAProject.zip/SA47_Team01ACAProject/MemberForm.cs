﻿using SA47_Team01ACAProject;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SA47_Team01ACAProject
{
    public partial class MemberForm : Form
    {
        SA47_Team01aCADatabaseEntities context = new SA47_Team01aCADatabaseEntities();
        int first = 0;
        int index = 0;
        int last = 0;
        int current = 0;

        public MemberForm()
        {
            InitializeComponent();
            
        }

        private void MemberForm_Load(object sender, EventArgs e)
        {
            first = context.Members.OrderBy(x => x.MemberID).Select(y => y.MemberID).FirstOrDefault();
            last = context.Members.OrderByDescending(x => x.MemberID).Select(y => y.MemberID).FirstOrDefault();
        }

        private void DatatoForm ()
        {
            MemberIDTB.Text = context.Members.Where(x => x.MemberID == index).First().MemberID.ToString();
            MemberNameTB.Text = context.Members.Where(x => x.MemberID == index).First().MemberName.ToString();
            MemberDoBDTP.Value = context.Members.Where(x => x.MemberID == index).First().DateofBirth;
            MemberAddressTB.Text = context.Members.Where(x => x.MemberID == index).First().Address.ToString();
            MemberPostalCodeTB.Text = context.Members.Where(x => x.MemberID == index).First().PostalCode.ToString();
            MemberContactNoTB.Text = context.Members.Where(x => x.MemberID == index).First().ContactNumber.ToString();
            MemberGenderCB.Text = context.Members.Where(x => x.MemberID == index).First().Gender.ToString();
            MemberEmailTB.Text = context.Members.Where(x => x.MemberID == index).First().EmailAddress.ToString();
            NoofBBTB.Text = context.Members.Where(x => x.MemberID == index).First().IssueTransactions.Where(x => x.LoanStatus == "Out").Count().ToString();
        }

        private void DatatoDatabase(Member m)
        {
            m.MemberName = MemberNameTB.Text.Trim();
            m.DateofBirth = MemberDoBDTP.Value;
            m.Address = MemberAddressTB.Text.Trim();
            m.PostalCode = MemberPostalCodeTB.Text.Trim();
            m.ContactNumber = MemberContactNoTB.Text.Trim();
            m.Gender = MemberGenderCB.Text.Trim();
            m.EmailAddress = MemberEmailTB.Text.Trim();
        }

        private DialogResult NoNull()
        {
            if (string.IsNullOrWhiteSpace(MemberNameTB.Text) || string.IsNullOrWhiteSpace(MemberDoBDTP.Text) ||
                string.IsNullOrWhiteSpace(MemberAddressTB.Text) || string.IsNullOrWhiteSpace(MemberPostalCodeTB.Text) ||
                string.IsNullOrWhiteSpace(MemberContactNoTB.Text) || string.IsNullOrWhiteSpace(MemberGenderCB.Text) ||
                string.IsNullOrWhiteSpace(MemberEmailTB.Text))
            {
                return DialogResult.Cancel;
            }
            else
            {
                return DialogResult.OK;
            }
        }
        
        
        private void UpdateButton_Click(object sender, EventArgs e)
        {
            Member m = context.Members.Where(x => x.MemberID.ToString() == MemberIDTB.Text.Trim()).First();
            DatatoDatabase(m);

            if (NoNull() == DialogResult.OK)
            {
                context.SaveChanges();
                MessageBox.Show("Update Successful");
            }
            else
            {
                MessageBox.Show("Some information are missing");
            }
        }

        private void AddButton_Click(object sender, EventArgs e)
        {
            Member m = new Member();
            DatatoDatabase(m);
            if (NoNull() == DialogResult.OK)
            {
                context.Members.Add(m);
                context.SaveChanges();
                MemberIDTB.Text = m.MemberID.ToString();
                MessageBox.Show("New member record created for: " + MemberNameTB.Text);
            }
            else
            {
                MessageBox.Show("Some informations are missing");
            }
        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {
            if (NoNull() == DialogResult.OK)
            {
                Member m = context.Members.Where(x => x.MemberID.ToString() == MemberIDTB.Text.Trim()).First();
                context.Members.Remove(m);
                DialogResult dialogResult = MessageBox.Show(
                    "Delete permanently?", "Attention",
                    MessageBoxButtons.YesNo);
                if(dialogResult == DialogResult.Yes)
                {
                    context.SaveChanges();
                    MessageBox.Show("Member record deleted");
                }
                else
                {
                    MessageBox.Show("Member record not deleted");
                }
            }
            else
            {
                MessageBox.Show("Some informations are missing");
            }

        }

        private void PrevButton_Click(object sender, EventArgs e)
        {
            if (MemberIDTB.Text != "")
            {
                current = Convert.ToInt16(MemberIDTB.Text);
                if (current == first)
                {
                    MessageBox.Show("This is the first record");
                }
                else
                {
                    index = context.Members.OrderByDescending(x => x.MemberID).Where(z => z.MemberID < current).FirstOrDefault().MemberID;
                    DatatoForm();
                }
            }
            else
            {
                MessageBox.Show("No record to show");
            }

        }

        private void NextButton_Click(object sender, EventArgs e)
        {
            if (MemberIDTB.Text != "")
            {
                current = Convert.ToInt16(MemberIDTB.Text);
                if (current == last)
                {
                    MessageBox.Show("This is the last record");
                }
                else
                {
                    index = context.Members.OrderBy(x => x.MemberID).Where(z => z.MemberID > current).First().MemberID;
                    DatatoForm();
                }
            }
            else
            {
                MessageBox.Show("No record to show");
            }
            
        }

        private void FindButton_Click(object sender, EventArgs e)
        {
            if (FindTB.Text == "")
            {
                MessageBox.Show("Please input Member ID into Find Text Box!");
            }
            else
            {
                int FindMemberID = Convert.ToInt16(FindTB.Text);

                var FindResult = context.Members.Where(x => x.MemberID == FindMemberID).FirstOrDefault();

                if (FindResult != null)
                {
                    index = context.Members.Where(x => x.MemberID == FindMemberID).First().MemberID;
                    DatatoForm();
                }
                else
                {
                    MessageBox.Show("Member not found");
                }
            }
        }

        private void FirstButton_Click(object sender, EventArgs e)
        {
            index = first;
            DatatoForm();
        }

        private void LastButton_Click(object sender, EventArgs e)
        {
            index = last;
            DatatoForm();
        }

        private void ResetButton_Click(object sender, EventArgs e)
        {
            MemberIDTB.Clear();
            MemberNameTB.Clear();
            MemberDoBDTP.Value = MemberDoBDTP.MaxDate;
            MemberAddressTB.Clear();
            MemberPostalCodeTB.Clear();
            MemberContactNoTB.Clear();
            MemberGenderCB.ResetText();
            MemberEmailTB.Clear();
            NoofBBTB.Clear();
            index = 0;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void MemberPostalCodeTB_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Can only accept numeric value.");
            }
        }

        private void MemberContactNoTB_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Can only accept numeric value.");
            }
        }
    }
}
