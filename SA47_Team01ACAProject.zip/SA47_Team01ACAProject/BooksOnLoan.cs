﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;

namespace SA47_Team01ACAProject
{
    public partial class BooksOnLoan : Form
    {
        SA47_Team01aCADatabaseEntities context;
        public BooksOnLoan()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            context = new SA47_Team01aCADatabaseEntities();
            var filtered = context.IssueTransactions.Where(x => x.LoanStatus == "out").ToList();
            dataGridView1.DataSource = filtered;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int selected = Convert.ToInt16(dataGridView1.CurrentRow.Cells[2].Value);
            //Book selectedbook = context.Books.Where(x => x.BookID == selected).First();
            var selectedbook = context.Books.Where(x => x.BookID == selected).ToList();
            dataGridView2.DataSource = selectedbook;            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
