﻿using SA47_Team01ACAProject;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SA47_Team01ACAProject_CrystalReports
{
    public partial class AuthorByBookCategory : Form
    {
        public AuthorByBookCategory()
        {
            InitializeComponent();
        }

        private void crystalReportViewer1_Load(object sender, EventArgs e)
        {
            SA47_Team01aCADatabaseEntities context = new SA47_Team01aCADatabaseEntities();
            AuthorByBookCategoryCR cr = new AuthorByBookCategoryCR();

            cr.SetDataSource(context.Books);
            crystalReportViewer1.ReportSource = cr;
        }
    }
}
