﻿namespace SA47_Team01ACAProject
{
    partial class IssueBookADO
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.Transid = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.BooksBorrowed = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.NormalPeriod = new System.Windows.Forms.RadioButton();
            this.SpecialPeriod = new System.Windows.Forms.RadioButton();
            this.LoanStatus = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.Remarks = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.ReturnDate = new System.Windows.Forms.DateTimePicker();
            this.label9 = new System.Windows.Forms.Label();
            this.SearchBook = new System.Windows.Forms.Button();
            this.SearchMember = new System.Windows.Forms.Button();
            this.IssueBookBtn = new System.Windows.Forms.Button();
            this.DueDate = new System.Windows.Forms.DateTimePicker();
            this.IssueDate = new System.Windows.Forms.DateTimePicker();
            this.BookTitle = new System.Windows.Forms.TextBox();
            this.BookId = new System.Windows.Forms.TextBox();
            this.MemName = new System.Windows.Forms.TextBox();
            this.MemId = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.Transid);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.BooksBorrowed);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Controls.Add(this.LoanStatus);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.Remarks);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.ReturnDate);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.SearchBook);
            this.panel1.Controls.Add(this.SearchMember);
            this.panel1.Controls.Add(this.IssueBookBtn);
            this.panel1.Controls.Add(this.DueDate);
            this.panel1.Controls.Add(this.IssueDate);
            this.panel1.Controls.Add(this.BookTitle);
            this.panel1.Controls.Add(this.BookId);
            this.panel1.Controls.Add(this.MemName);
            this.panel1.Controls.Add(this.MemId);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(57, 15);
            this.panel1.Margin = new System.Windows.Forms.Padding(6);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1062, 657);
            this.panel1.TabIndex = 98;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(18, 540);
            this.button2.Margin = new System.Windows.Forms.Padding(6);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(223, 44);
            this.button2.TabIndex = 95;
            this.button2.Text = "Back";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // Transid
            // 
            this.Transid.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Transid.Location = new System.Drawing.Point(297, 435);
            this.Transid.Margin = new System.Windows.Forms.Padding(4);
            this.Transid.Name = "Transid";
            this.Transid.ReadOnly = true;
            this.Transid.Size = new System.Drawing.Size(182, 38);
            this.Transid.TabIndex = 94;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label8.Location = new System.Drawing.Point(7, 441);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(148, 26);
            this.label8.TabIndex = 93;
            this.label8.Text = "Transaction Id";
            // 
            // BooksBorrowed
            // 
            this.BooksBorrowed.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BooksBorrowed.Location = new System.Drawing.Point(720, 393);
            this.BooksBorrowed.Margin = new System.Windows.Forms.Padding(4);
            this.BooksBorrowed.Name = "BooksBorrowed";
            this.BooksBorrowed.ReadOnly = true;
            this.BooksBorrowed.Size = new System.Drawing.Size(180, 38);
            this.BooksBorrowed.TabIndex = 89;
            this.BooksBorrowed.Visible = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label12.Location = new System.Drawing.Point(529, 401);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(172, 26);
            this.label12.TabIndex = 88;
            this.label12.Text = "Books Borrowed";
            this.label12.Visible = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label11.Location = new System.Drawing.Point(13, 239);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(129, 26);
            this.label11.TabIndex = 85;
            this.label11.Text = "Loan Period";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.NormalPeriod);
            this.groupBox1.Controls.Add(this.SpecialPeriod);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(299, 204);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(440, 85);
            this.groupBox1.TabIndex = 84;
            this.groupBox1.TabStop = false;
            // 
            // NormalPeriod
            // 
            this.NormalPeriod.AutoSize = true;
            this.NormalPeriod.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.NormalPeriod.Location = new System.Drawing.Point(8, 33);
            this.NormalPeriod.Margin = new System.Windows.Forms.Padding(4);
            this.NormalPeriod.Name = "NormalPeriod";
            this.NormalPeriod.Size = new System.Drawing.Size(183, 30);
            this.NormalPeriod.TabIndex = 1;
            this.NormalPeriod.TabStop = true;
            this.NormalPeriod.Text = "Normal Period";
            this.NormalPeriod.UseVisualStyleBackColor = true;
            // 
            // SpecialPeriod
            // 
            this.SpecialPeriod.AutoSize = true;
            this.SpecialPeriod.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.SpecialPeriod.Location = new System.Drawing.Point(244, 33);
            this.SpecialPeriod.Margin = new System.Windows.Forms.Padding(4);
            this.SpecialPeriod.Name = "SpecialPeriod";
            this.SpecialPeriod.Size = new System.Drawing.Size(184, 30);
            this.SpecialPeriod.TabIndex = 0;
            this.SpecialPeriod.TabStop = true;
            this.SpecialPeriod.Text = "Special Period";
            this.SpecialPeriod.UseVisualStyleBackColor = true;
            // 
            // LoanStatus
            // 
            this.LoanStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.LoanStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LoanStatus.FormattingEnabled = true;
            this.LoanStatus.Items.AddRange(new object[] {
            "In",
            "Out"});
            this.LoanStatus.Location = new System.Drawing.Point(720, 295);
            this.LoanStatus.Margin = new System.Windows.Forms.Padding(4);
            this.LoanStatus.Name = "LoanStatus";
            this.LoanStatus.Size = new System.Drawing.Size(180, 39);
            this.LoanStatus.TabIndex = 83;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label7.Location = new System.Drawing.Point(529, 303);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(128, 26);
            this.label7.TabIndex = 82;
            this.label7.Text = "Loan Status";
            // 
            // Remarks
            // 
            this.Remarks.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Remarks.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Remarks.FormattingEnabled = true;
            this.Remarks.Items.AddRange(new object[] {
            "-",
            "Overdue",
            "Extension Requested",
            "Extension Approved",
            "Extension Rejected"});
            this.Remarks.Location = new System.Drawing.Point(720, 344);
            this.Remarks.Margin = new System.Windows.Forms.Padding(4);
            this.Remarks.Name = "Remarks";
            this.Remarks.Size = new System.Drawing.Size(180, 39);
            this.Remarks.TabIndex = 81;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label10.Location = new System.Drawing.Point(529, 352);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(100, 26);
            this.label10.TabIndex = 80;
            this.label10.Text = "Remarks";
            // 
            // ReturnDate
            // 
            this.ReturnDate.Enabled = false;
            this.ReturnDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ReturnDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.ReturnDate.Location = new System.Drawing.Point(299, 389);
            this.ReturnDate.Margin = new System.Windows.Forms.Padding(4);
            this.ReturnDate.Name = "ReturnDate";
            this.ReturnDate.Size = new System.Drawing.Size(180, 38);
            this.ReturnDate.TabIndex = 79;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label9.Location = new System.Drawing.Point(9, 395);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(196, 26);
            this.label9.TabIndex = 78;
            this.label9.Text = "Actual Return Date";
            // 
            // SearchBook
            // 
            this.SearchBook.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchBook.Location = new System.Drawing.Point(476, 101);
            this.SearchBook.Margin = new System.Windows.Forms.Padding(4);
            this.SearchBook.Name = "SearchBook";
            this.SearchBook.Size = new System.Drawing.Size(52, 46);
            this.SearchBook.TabIndex = 76;
            this.SearchBook.Text = "...";
            this.SearchBook.UseVisualStyleBackColor = true;
            // 
            // SearchMember
            // 
            this.SearchMember.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchMember.Location = new System.Drawing.Point(476, 5);
            this.SearchMember.Margin = new System.Windows.Forms.Padding(4);
            this.SearchMember.Name = "SearchMember";
            this.SearchMember.Size = new System.Drawing.Size(52, 46);
            this.SearchMember.TabIndex = 75;
            this.SearchMember.Text = "...";
            this.SearchMember.UseVisualStyleBackColor = true;
            // 
            // IssueBookBtn
            // 
            this.IssueBookBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.IssueBookBtn.Location = new System.Drawing.Point(818, 540);
            this.IssueBookBtn.Margin = new System.Windows.Forms.Padding(4);
            this.IssueBookBtn.Name = "IssueBookBtn";
            this.IssueBookBtn.Size = new System.Drawing.Size(220, 44);
            this.IssueBookBtn.TabIndex = 74;
            this.IssueBookBtn.Text = "Issue Book";
            this.IssueBookBtn.UseVisualStyleBackColor = true;
            // 
            // DueDate
            // 
            this.DueDate.Enabled = false;
            this.DueDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DueDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.DueDate.Location = new System.Drawing.Point(299, 343);
            this.DueDate.Margin = new System.Windows.Forms.Padding(4);
            this.DueDate.Name = "DueDate";
            this.DueDate.Size = new System.Drawing.Size(180, 38);
            this.DueDate.TabIndex = 73;
            // 
            // IssueDate
            // 
            this.IssueDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IssueDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.IssueDate.Location = new System.Drawing.Point(299, 297);
            this.IssueDate.Margin = new System.Windows.Forms.Padding(4);
            this.IssueDate.MinDate = new System.DateTime(2018, 9, 26, 0, 0, 0, 0);
            this.IssueDate.Name = "IssueDate";
            this.IssueDate.Size = new System.Drawing.Size(180, 35);
            this.IssueDate.TabIndex = 72;
            this.IssueDate.Value = new System.DateTime(2018, 9, 26, 6, 42, 27, 0);
            // 
            // BookTitle
            // 
            this.BookTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BookTitle.Location = new System.Drawing.Point(302, 155);
            this.BookTitle.Margin = new System.Windows.Forms.Padding(4);
            this.BookTitle.Name = "BookTitle";
            this.BookTitle.ReadOnly = true;
            this.BookTitle.Size = new System.Drawing.Size(696, 38);
            this.BookTitle.TabIndex = 68;
            // 
            // BookId
            // 
            this.BookId.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BookId.Location = new System.Drawing.Point(302, 105);
            this.BookId.Margin = new System.Windows.Forms.Padding(4);
            this.BookId.Name = "BookId";
            this.BookId.Size = new System.Drawing.Size(148, 38);
            this.BookId.TabIndex = 67;
            // 
            // MemName
            // 
            this.MemName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MemName.Location = new System.Drawing.Point(302, 59);
            this.MemName.Margin = new System.Windows.Forms.Padding(4);
            this.MemName.Name = "MemName";
            this.MemName.ReadOnly = true;
            this.MemName.Size = new System.Drawing.Size(332, 38);
            this.MemName.TabIndex = 66;
            // 
            // MemId
            // 
            this.MemId.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MemId.Location = new System.Drawing.Point(302, 9);
            this.MemId.Margin = new System.Windows.Forms.Padding(4);
            this.MemId.Name = "MemId";
            this.MemId.Size = new System.Drawing.Size(148, 38);
            this.MemId.TabIndex = 65;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label6.Location = new System.Drawing.Point(9, 349);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(104, 26);
            this.label6.TabIndex = 63;
            this.label6.Text = "Due Date";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label5.Location = new System.Drawing.Point(9, 303);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(140, 26);
            this.label5.TabIndex = 62;
            this.label5.Text = "Date of Issue";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label4.Location = new System.Drawing.Point(12, 161);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(108, 26);
            this.label4.TabIndex = 61;
            this.label4.Text = "Book Title";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label3.Location = new System.Drawing.Point(12, 111);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(90, 26);
            this.label3.TabIndex = 60;
            this.label3.Text = "Book ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label2.Location = new System.Drawing.Point(12, 65);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(157, 26);
            this.label2.TabIndex = 59;
            this.label2.Text = "Member Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label1.Location = new System.Drawing.Point(12, 15);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(116, 26);
            this.label1.TabIndex = 58;
            this.label1.Text = "Member Id";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(956, 614);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(82, 25);
            this.label13.TabIndex = 90;
            this.label13.Text = "label13";
            this.label13.Visible = false;
            // 
            // IssueBookADO
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1203, 760);
            this.Controls.Add(this.panel1);
            this.Name = "IssueBookADO";
            this.Text = "IssueBookADO";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox Transid;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox BooksBorrowed;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton NormalPeriod;
        private System.Windows.Forms.RadioButton SpecialPeriod;
        private System.Windows.Forms.ComboBox LoanStatus;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox Remarks;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DateTimePicker ReturnDate;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button SearchBook;
        private System.Windows.Forms.Button SearchMember;
        private System.Windows.Forms.Button IssueBookBtn;
        private System.Windows.Forms.DateTimePicker DueDate;
        private System.Windows.Forms.DateTimePicker IssueDate;
        private System.Windows.Forms.TextBox BookTitle;
        private System.Windows.Forms.TextBox BookId;
        public System.Windows.Forms.TextBox MemName;
        public System.Windows.Forms.TextBox MemId;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}