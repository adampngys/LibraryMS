﻿using System;
using System.Windows.Forms;

namespace SA47_Team01ACAProject
{
    public partial class ParentForm : Form
    {
        public ParentForm()
        {
            InitializeComponent();            
        }

        private void ParentForm_Load(object sender, EventArgs e)
        {
            LoginForm f = new LoginForm();
            f.MdiParent = this;
            f.WindowState = FormWindowState.Maximized;
            f.Show();
        }
    }
}
