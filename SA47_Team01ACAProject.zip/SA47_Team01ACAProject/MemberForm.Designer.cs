﻿namespace SA47_Team01ACAProject
{
    partial class MemberForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MemberForm));
            this.MemberIDLabel = new System.Windows.Forms.Label();
            this.MemberNameLabel = new System.Windows.Forms.Label();
            this.MemberDOBLabel = new System.Windows.Forms.Label();
            this.MemberAddressLabel = new System.Windows.Forms.Label();
            this.MemberPostalCodeLabel = new System.Windows.Forms.Label();
            this.MemberContactNoLabel = new System.Windows.Forms.Label();
            this.MemberGenderLabel = new System.Windows.Forms.Label();
            this.MemberEmailLabel = new System.Windows.Forms.Label();
            this.MemberIDTB = new System.Windows.Forms.TextBox();
            this.MemberNameTB = new System.Windows.Forms.TextBox();
            this.MemberAddressTB = new System.Windows.Forms.TextBox();
            this.MemberPostalCodeTB = new System.Windows.Forms.TextBox();
            this.MemberContactNoTB = new System.Windows.Forms.TextBox();
            this.MemberEmailTB = new System.Windows.Forms.TextBox();
            this.MemberDoBDTP = new System.Windows.Forms.DateTimePicker();
            this.ResetButton = new System.Windows.Forms.Button();
            this.UpdateButton = new System.Windows.Forms.Button();
            this.AddButton = new System.Windows.Forms.Button();
            this.DeleteButton = new System.Windows.Forms.Button();
            this.MemberGenderCB = new System.Windows.Forms.ComboBox();
            this.NoofBBTB = new System.Windows.Forms.TextBox();
            this.NoofBBLabel = new System.Windows.Forms.Label();
            this.PrevButton = new System.Windows.Forms.Button();
            this.NextButton = new System.Windows.Forms.Button();
            this.LastButton = new System.Windows.Forms.Button();
            this.FirstButton = new System.Windows.Forms.Button();
            this.FindTB = new System.Windows.Forms.TextBox();
            this.FindButton = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.FindMemberIDLabel = new System.Windows.Forms.Label();
            this.NameTip = new System.Windows.Forms.ToolTip(this.components);
            this.button2 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // MemberIDLabel
            // 
            this.MemberIDLabel.AutoSize = true;
            this.MemberIDLabel.Location = new System.Drawing.Point(34, 22);
            this.MemberIDLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.MemberIDLabel.Name = "MemberIDLabel";
            this.MemberIDLabel.Size = new System.Drawing.Size(59, 13);
            this.MemberIDLabel.TabIndex = 20;
            this.MemberIDLabel.Text = "Member ID";
            // 
            // MemberNameLabel
            // 
            this.MemberNameLabel.AutoSize = true;
            this.MemberNameLabel.Location = new System.Drawing.Point(34, 46);
            this.MemberNameLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.MemberNameLabel.Name = "MemberNameLabel";
            this.MemberNameLabel.Size = new System.Drawing.Size(76, 13);
            this.MemberNameLabel.TabIndex = 21;
            this.MemberNameLabel.Text = "Member Name";
            // 
            // MemberDOBLabel
            // 
            this.MemberDOBLabel.AutoSize = true;
            this.MemberDOBLabel.Location = new System.Drawing.Point(34, 70);
            this.MemberDOBLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.MemberDOBLabel.Name = "MemberDOBLabel";
            this.MemberDOBLabel.Size = new System.Drawing.Size(66, 13);
            this.MemberDOBLabel.TabIndex = 22;
            this.MemberDOBLabel.Text = "Date of Birth";
            // 
            // MemberAddressLabel
            // 
            this.MemberAddressLabel.AutoSize = true;
            this.MemberAddressLabel.Location = new System.Drawing.Point(34, 94);
            this.MemberAddressLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.MemberAddressLabel.Name = "MemberAddressLabel";
            this.MemberAddressLabel.Size = new System.Drawing.Size(45, 13);
            this.MemberAddressLabel.TabIndex = 23;
            this.MemberAddressLabel.Text = "Address";
            // 
            // MemberPostalCodeLabel
            // 
            this.MemberPostalCodeLabel.AutoSize = true;
            this.MemberPostalCodeLabel.Location = new System.Drawing.Point(34, 171);
            this.MemberPostalCodeLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.MemberPostalCodeLabel.Name = "MemberPostalCodeLabel";
            this.MemberPostalCodeLabel.Size = new System.Drawing.Size(64, 13);
            this.MemberPostalCodeLabel.TabIndex = 24;
            this.MemberPostalCodeLabel.Text = "Postal Code";
            // 
            // MemberContactNoLabel
            // 
            this.MemberContactNoLabel.AutoSize = true;
            this.MemberContactNoLabel.Location = new System.Drawing.Point(34, 195);
            this.MemberContactNoLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.MemberContactNoLabel.Name = "MemberContactNoLabel";
            this.MemberContactNoLabel.Size = new System.Drawing.Size(84, 13);
            this.MemberContactNoLabel.TabIndex = 25;
            this.MemberContactNoLabel.Text = "Contact Number";
            // 
            // MemberGenderLabel
            // 
            this.MemberGenderLabel.AutoSize = true;
            this.MemberGenderLabel.Location = new System.Drawing.Point(34, 219);
            this.MemberGenderLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.MemberGenderLabel.Name = "MemberGenderLabel";
            this.MemberGenderLabel.Size = new System.Drawing.Size(42, 13);
            this.MemberGenderLabel.TabIndex = 26;
            this.MemberGenderLabel.Text = "Gender";
            // 
            // MemberEmailLabel
            // 
            this.MemberEmailLabel.AutoSize = true;
            this.MemberEmailLabel.Location = new System.Drawing.Point(34, 244);
            this.MemberEmailLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.MemberEmailLabel.Name = "MemberEmailLabel";
            this.MemberEmailLabel.Size = new System.Drawing.Size(73, 13);
            this.MemberEmailLabel.TabIndex = 27;
            this.MemberEmailLabel.Text = "Email Address";
            // 
            // MemberIDTB
            // 
            this.MemberIDTB.Enabled = false;
            this.MemberIDTB.Location = new System.Drawing.Point(141, 22);
            this.MemberIDTB.Margin = new System.Windows.Forms.Padding(2);
            this.MemberIDTB.Name = "MemberIDTB";
            this.MemberIDTB.Size = new System.Drawing.Size(68, 20);
            this.MemberIDTB.TabIndex = 0;
            // 
            // MemberNameTB
            // 
            this.MemberNameTB.Location = new System.Drawing.Point(141, 46);
            this.MemberNameTB.Margin = new System.Windows.Forms.Padding(2);
            this.MemberNameTB.Name = "MemberNameTB";
            this.MemberNameTB.Size = new System.Drawing.Size(152, 20);
            this.MemberNameTB.TabIndex = 1;
            this.NameTip.SetToolTip(this.MemberNameTB, "Enter full name in title case");
            // 
            // MemberAddressTB
            // 
            this.MemberAddressTB.Location = new System.Drawing.Point(141, 94);
            this.MemberAddressTB.Margin = new System.Windows.Forms.Padding(2);
            this.MemberAddressTB.Multiline = true;
            this.MemberAddressTB.Name = "MemberAddressTB";
            this.MemberAddressTB.Size = new System.Drawing.Size(126, 73);
            this.MemberAddressTB.TabIndex = 3;
            // 
            // MemberPostalCodeTB
            // 
            this.MemberPostalCodeTB.Location = new System.Drawing.Point(141, 171);
            this.MemberPostalCodeTB.Margin = new System.Windows.Forms.Padding(2);
            this.MemberPostalCodeTB.MaxLength = 6;
            this.MemberPostalCodeTB.Name = "MemberPostalCodeTB";
            this.MemberPostalCodeTB.Size = new System.Drawing.Size(68, 20);
            this.MemberPostalCodeTB.TabIndex = 4;
            this.MemberPostalCodeTB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MemberPostalCodeTB_KeyPress);
            // 
            // MemberContactNoTB
            // 
            this.MemberContactNoTB.Location = new System.Drawing.Point(141, 195);
            this.MemberContactNoTB.Margin = new System.Windows.Forms.Padding(2);
            this.MemberContactNoTB.MaxLength = 7;
            this.MemberContactNoTB.Name = "MemberContactNoTB";
            this.MemberContactNoTB.Size = new System.Drawing.Size(108, 20);
            this.MemberContactNoTB.TabIndex = 5;
            this.MemberContactNoTB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MemberContactNoTB_KeyPress);
            // 
            // MemberEmailTB
            // 
            this.MemberEmailTB.Location = new System.Drawing.Point(141, 244);
            this.MemberEmailTB.Margin = new System.Windows.Forms.Padding(2);
            this.MemberEmailTB.Name = "MemberEmailTB";
            this.MemberEmailTB.Size = new System.Drawing.Size(152, 20);
            this.MemberEmailTB.TabIndex = 7;
            // 
            // MemberDoBDTP
            // 
            this.MemberDoBDTP.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.MemberDoBDTP.Location = new System.Drawing.Point(141, 70);
            this.MemberDoBDTP.Margin = new System.Windows.Forms.Padding(2);
            this.MemberDoBDTP.MaxDate = new System.DateTime(2011, 9, 29, 0, 0, 0, 0);
            this.MemberDoBDTP.MinDate = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
            this.MemberDoBDTP.Name = "MemberDoBDTP";
            this.MemberDoBDTP.Size = new System.Drawing.Size(92, 20);
            this.MemberDoBDTP.TabIndex = 2;
            this.MemberDoBDTP.Value = new System.DateTime(2011, 9, 29, 0, 0, 0, 0);
            // 
            // ResetButton
            // 
            this.ResetButton.Location = new System.Drawing.Point(89, 280);
            this.ResetButton.Margin = new System.Windows.Forms.Padding(2);
            this.ResetButton.Name = "ResetButton";
            this.ResetButton.Size = new System.Drawing.Size(56, 35);
            this.ResetButton.TabIndex = 9;
            this.ResetButton.Text = "Reset";
            this.ResetButton.UseVisualStyleBackColor = true;
            this.ResetButton.Click += new System.EventHandler(this.ResetButton_Click);
            // 
            // UpdateButton
            // 
            this.UpdateButton.Location = new System.Drawing.Point(168, 280);
            this.UpdateButton.Margin = new System.Windows.Forms.Padding(2);
            this.UpdateButton.Name = "UpdateButton";
            this.UpdateButton.Size = new System.Drawing.Size(56, 35);
            this.UpdateButton.TabIndex = 10;
            this.UpdateButton.Text = "Update";
            this.UpdateButton.UseVisualStyleBackColor = true;
            this.UpdateButton.Click += new System.EventHandler(this.UpdateButton_Click);
            // 
            // AddButton
            // 
            this.AddButton.Location = new System.Drawing.Point(248, 280);
            this.AddButton.Margin = new System.Windows.Forms.Padding(2);
            this.AddButton.Name = "AddButton";
            this.AddButton.Size = new System.Drawing.Size(56, 35);
            this.AddButton.TabIndex = 11;
            this.AddButton.Text = "Add";
            this.AddButton.UseVisualStyleBackColor = true;
            this.AddButton.Click += new System.EventHandler(this.AddButton_Click);
            // 
            // DeleteButton
            // 
            this.DeleteButton.Location = new System.Drawing.Point(327, 280);
            this.DeleteButton.Margin = new System.Windows.Forms.Padding(2);
            this.DeleteButton.Name = "DeleteButton";
            this.DeleteButton.Size = new System.Drawing.Size(56, 35);
            this.DeleteButton.TabIndex = 12;
            this.DeleteButton.Text = "Delete";
            this.DeleteButton.UseVisualStyleBackColor = true;
            this.DeleteButton.Click += new System.EventHandler(this.DeleteButton_Click);
            // 
            // MemberGenderCB
            // 
            this.MemberGenderCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.MemberGenderCB.FormattingEnabled = true;
            this.MemberGenderCB.Items.AddRange(new object[] {
            "F",
            "M"});
            this.MemberGenderCB.Location = new System.Drawing.Point(141, 219);
            this.MemberGenderCB.Margin = new System.Windows.Forms.Padding(2);
            this.MemberGenderCB.Name = "MemberGenderCB";
            this.MemberGenderCB.Size = new System.Drawing.Size(92, 21);
            this.MemberGenderCB.TabIndex = 6;
            // 
            // NoofBBTB
            // 
            this.NoofBBTB.Enabled = false;
            this.NoofBBTB.Location = new System.Drawing.Point(460, 22);
            this.NoofBBTB.Margin = new System.Windows.Forms.Padding(2);
            this.NoofBBTB.Name = "NoofBBTB";
            this.NoofBBTB.Size = new System.Drawing.Size(39, 20);
            this.NoofBBTB.TabIndex = 18;
            // 
            // NoofBBLabel
            // 
            this.NoofBBLabel.AutoSize = true;
            this.NoofBBLabel.Location = new System.Drawing.Point(309, 22);
            this.NoofBBLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.NoofBBLabel.Name = "NoofBBLabel";
            this.NoofBBLabel.Size = new System.Drawing.Size(137, 13);
            this.NoofBBLabel.TabIndex = 19;
            this.NoofBBLabel.Text = "Number of Books Borrowed";
            // 
            // PrevButton
            // 
            this.PrevButton.Location = new System.Drawing.Point(36, 280);
            this.PrevButton.Margin = new System.Windows.Forms.Padding(2);
            this.PrevButton.Name = "PrevButton";
            this.PrevButton.Size = new System.Drawing.Size(29, 35);
            this.PrevButton.TabIndex = 8;
            this.PrevButton.Text = "<";
            this.PrevButton.UseVisualStyleBackColor = true;
            this.PrevButton.Click += new System.EventHandler(this.PrevButton_Click);
            // 
            // NextButton
            // 
            this.NextButton.Location = new System.Drawing.Point(407, 280);
            this.NextButton.Margin = new System.Windows.Forms.Padding(2);
            this.NextButton.Name = "NextButton";
            this.NextButton.Size = new System.Drawing.Size(29, 35);
            this.NextButton.TabIndex = 13;
            this.NextButton.Text = ">";
            this.NextButton.UseVisualStyleBackColor = true;
            this.NextButton.Click += new System.EventHandler(this.NextButton_Click);
            // 
            // LastButton
            // 
            this.LastButton.Location = new System.Drawing.Point(466, 345);
            this.LastButton.Margin = new System.Windows.Forms.Padding(2);
            this.LastButton.Name = "LastButton";
            this.LastButton.Size = new System.Drawing.Size(29, 35);
            this.LastButton.TabIndex = 15;
            this.LastButton.Text = ">>";
            this.LastButton.UseVisualStyleBackColor = true;
            this.LastButton.Click += new System.EventHandler(this.LastButton_Click);
            // 
            // FirstButton
            // 
            this.FirstButton.Location = new System.Drawing.Point(95, 345);
            this.FirstButton.Margin = new System.Windows.Forms.Padding(2);
            this.FirstButton.Name = "FirstButton";
            this.FirstButton.Size = new System.Drawing.Size(29, 35);
            this.FirstButton.TabIndex = 14;
            this.FirstButton.Text = "<<";
            this.FirstButton.UseVisualStyleBackColor = true;
            this.FirstButton.Click += new System.EventHandler(this.FirstButton_Click);
            // 
            // FindTB
            // 
            this.FindTB.Location = new System.Drawing.Point(109, 17);
            this.FindTB.Margin = new System.Windows.Forms.Padding(2);
            this.FindTB.Name = "FindTB";
            this.FindTB.Size = new System.Drawing.Size(98, 20);
            this.FindTB.TabIndex = 16;
            // 
            // FindButton
            // 
            this.FindButton.Location = new System.Drawing.Point(229, 15);
            this.FindButton.Margin = new System.Windows.Forms.Padding(2);
            this.FindButton.Name = "FindButton";
            this.FindButton.Size = new System.Drawing.Size(56, 20);
            this.FindButton.TabIndex = 17;
            this.FindButton.Text = "Find";
            this.FindButton.UseVisualStyleBackColor = true;
            this.FindButton.Click += new System.EventHandler(this.FindButton_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.FindMemberIDLabel);
            this.groupBox1.Controls.Add(this.FindButton);
            this.groupBox1.Controls.Add(this.FindTB);
            this.groupBox1.Location = new System.Drawing.Point(141, 334);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox1.Size = new System.Drawing.Size(320, 50);
            this.groupBox1.TabIndex = 30;
            this.groupBox1.TabStop = false;
            // 
            // FindMemberIDLabel
            // 
            this.FindMemberIDLabel.AutoSize = true;
            this.FindMemberIDLabel.Location = new System.Drawing.Point(11, 19);
            this.FindMemberIDLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.FindMemberIDLabel.Name = "FindMemberIDLabel";
            this.FindMemberIDLabel.Size = new System.Drawing.Size(87, 13);
            this.FindMemberIDLabel.TabIndex = 28;
            this.FindMemberIDLabel.Text = "Enter Member ID";
            // 
            // NameTip
            // 
            this.NameTip.AutoPopDelay = 5000;
            this.NameTip.InitialDelay = 50;
            this.NameTip.ReshowDelay = 100;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(4, 357);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 31;
            this.button2.Text = "Back";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // panel1
            // 
            this.panel1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Controls.Add(this.FirstButton);
            this.panel1.Controls.Add(this.LastButton);
            this.panel1.Controls.Add(this.NextButton);
            this.panel1.Controls.Add(this.PrevButton);
            this.panel1.Controls.Add(this.NoofBBTB);
            this.panel1.Controls.Add(this.NoofBBLabel);
            this.panel1.Controls.Add(this.MemberGenderCB);
            this.panel1.Controls.Add(this.DeleteButton);
            this.panel1.Controls.Add(this.AddButton);
            this.panel1.Controls.Add(this.UpdateButton);
            this.panel1.Controls.Add(this.ResetButton);
            this.panel1.Controls.Add(this.MemberDoBDTP);
            this.panel1.Controls.Add(this.MemberEmailTB);
            this.panel1.Controls.Add(this.MemberContactNoTB);
            this.panel1.Controls.Add(this.MemberPostalCodeTB);
            this.panel1.Controls.Add(this.MemberAddressTB);
            this.panel1.Controls.Add(this.MemberNameTB);
            this.panel1.Controls.Add(this.MemberIDTB);
            this.panel1.Controls.Add(this.MemberEmailLabel);
            this.panel1.Controls.Add(this.MemberGenderLabel);
            this.panel1.Controls.Add(this.MemberContactNoLabel);
            this.panel1.Controls.Add(this.MemberPostalCodeLabel);
            this.panel1.Controls.Add(this.MemberAddressLabel);
            this.panel1.Controls.Add(this.MemberDOBLabel);
            this.panel1.Controls.Add(this.MemberNameLabel);
            this.panel1.Controls.Add(this.MemberIDLabel);
            this.panel1.Location = new System.Drawing.Point(127, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(551, 410);
            this.panel1.TabIndex = 32;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(109, 115);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 92;
            this.pictureBox1.TabStop = false;
            // 
            // MemberForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.Pink;
            this.ClientSize = new System.Drawing.Size(712, 447);
            this.ControlBox = false;
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "MemberForm";
            this.Text = "Creation and Maintenance of Member Info";
            this.Load += new System.EventHandler(this.MemberForm_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label MemberIDLabel;
        private System.Windows.Forms.Label MemberNameLabel;
        private System.Windows.Forms.Label MemberDOBLabel;
        private System.Windows.Forms.Label MemberAddressLabel;
        private System.Windows.Forms.Label MemberPostalCodeLabel;
        private System.Windows.Forms.Label MemberContactNoLabel;
        private System.Windows.Forms.Label MemberGenderLabel;
        private System.Windows.Forms.Label MemberEmailLabel;
        private System.Windows.Forms.TextBox MemberIDTB;
        private System.Windows.Forms.TextBox MemberNameTB;
        private System.Windows.Forms.TextBox MemberAddressTB;
        private System.Windows.Forms.TextBox MemberPostalCodeTB;
        private System.Windows.Forms.TextBox MemberContactNoTB;
        private System.Windows.Forms.TextBox MemberEmailTB;
        private System.Windows.Forms.DateTimePicker MemberDoBDTP;
        private System.Windows.Forms.Button ResetButton;
        private System.Windows.Forms.Button UpdateButton;
        private System.Windows.Forms.Button AddButton;
        private System.Windows.Forms.Button DeleteButton;
        private System.Windows.Forms.ComboBox MemberGenderCB;
        private System.Windows.Forms.TextBox NoofBBTB;
        private System.Windows.Forms.Label NoofBBLabel;
        private System.Windows.Forms.Button PrevButton;
        private System.Windows.Forms.Button NextButton;
        private System.Windows.Forms.Button LastButton;
        private System.Windows.Forms.Button FirstButton;
        private System.Windows.Forms.TextBox FindTB;
        private System.Windows.Forms.Button FindButton;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label FindMemberIDLabel;
        private System.Windows.Forms.ToolTip NameTip;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

