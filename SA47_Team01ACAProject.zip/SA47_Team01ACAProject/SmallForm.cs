﻿using System;
using System.Windows.Forms;

namespace SA47_Team01ACAProject
{
    public partial class SmallForm : Form
    {
        string[] Data = new string[4];
        public SmallForm()
        {
            InitializeComponent();
        }

        public string[] getData
        {
            get
            {
                return Data;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Data[0] = textBox1.Text;
            Data[1] = textBox2.Text;
            Data[2] = textBox3.Text;
            Data[3] = textBox4.Text;
            this.Close();
        }
    }
}
