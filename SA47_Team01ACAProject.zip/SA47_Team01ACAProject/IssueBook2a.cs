﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SA47_Team01ACAProject
{
    public partial class IssueBook2a : Form
    {
        SA47_Team01aCADatabaseEntities context = new SA47_Team01aCADatabaseEntities();
        private string selectedmember;
        private int selectedmemid = 0;
        public string themember
        {
            get
            {
                return selectedmember;
            }
        }

        public int thememid
        {
            get
            {
                return selectedmemid;
            }
        }
        public IssueBook2a()
        {
            InitializeComponent();
            dataGridView1.DataSource = context.Members.ToList();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            selectedmember = Convert.ToString(dataGridView1.CurrentRow.Cells[1].Value);
            selectedmemid = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);
            this.Close();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }


    }
}
