﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SA47_Team01ACAProject
{
    public partial class PopUpBook : Form
    {

        public string BookId { get; private set; }
        public string BookTitle { get; private set; }
        public PopUpBook()
        {
            InitializeComponent();
        }

        private void Cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            
         if(dataGridView1.SelectedCells.Count>0)
            {
                int selectedrowindex = dataGridView1.SelectedCells[0].RowIndex;

                DataGridViewRow selectedRow = dataGridView1.Rows[selectedrowindex];

                this.BookId = Convert.ToString(selectedRow.Cells["BookId"].Value);
                this.BookTitle = Convert.ToString(selectedRow.Cells["BookTitle"].Value);
                //this.Close();
            }


        }
        private void PopUpBook_Load(object sender, EventArgs e)
        {
            dataGridView1.FirstDisplayedCell.Selected = false;
            dataGridView1.ClearSelection();
            this.dataGridView1.SelectionChanged += dataGridView1_SelectionChanged;
        }
    }
}

