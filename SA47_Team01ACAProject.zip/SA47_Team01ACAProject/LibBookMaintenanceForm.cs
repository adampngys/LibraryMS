﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SA47_Team01ACAProject
{
    public partial class LibBookMaintenanceForm : Form
    {
        int index = 0;
        SA47_Team01aCADatabaseEntities context = new SA47_Team01aCADatabaseEntities();
        public LibBookMaintenanceForm()
        {
            InitializeComponent();
        }


        //Methods

        private void DatatoForm(int index)
        {
            IDText.Text = context.Books.AsEnumerable().ElementAt(index).BookID.ToString();
            TitleText.Text = context.Books.AsEnumerable().ElementAt(index).BookTitle.ToString();
            AuthorBox.Text = context.Books.AsEnumerable().ElementAt(index).Author.ToString();
            PublisherBox.Text = context.Books.AsEnumerable().ElementAt(index).Publisher.ToString();
            CategoryBox.Text = context.Books.AsEnumerable().ElementAt(index).BookCategory.ToString();
            GenreBox.Text = context.Books.AsEnumerable().ElementAt(index).Genre.ToString();
            ISBNText.Text = context.Books.AsEnumerable().ElementAt(index).ISBN.ToString();
            StockNumeric.Text = context.Books.AsEnumerable().ElementAt(index).TotalStock.ToString();
            LoanNumeric.Text = context.Books.AsEnumerable().ElementAt(index).NumberLoaned.ToString();
        }
        private void DatatoDatabase(Book b)
        {
            b.BookTitle = TitleText.Text.Trim();
            b.Author = AuthorBox.Text.Trim();
            b.Publisher = PublisherBox.Text.Trim();
            b.BookCategory = CategoryBox.Text.Trim();
            b.Genre = GenreBox.Text.Trim();
            b.ISBN = ISBNText.Text.Trim();
            b.TotalStock = Convert.ToInt16(StockNumeric.Text.Trim());
            b.NumberLoaned = Convert.ToInt16(LoanNumeric.Text.Trim());
        }
        private DialogResult NoNull()
        {
            if (string.IsNullOrWhiteSpace(TitleText.Text) || string.IsNullOrWhiteSpace(AuthorBox.Text) ||
                string.IsNullOrWhiteSpace(PublisherBox.Text) || string.IsNullOrWhiteSpace(CategoryBox.Text) ||
                string.IsNullOrWhiteSpace(GenreBox.Text) || string.IsNullOrWhiteSpace(ISBNText.Text) ||
                string.IsNullOrWhiteSpace(StockNumeric.Text) || string.IsNullOrWhiteSpace(LoanNumeric.Text))
            {
                return DialogResult.Cancel;
            }
            else
            {
                return DialogResult.OK;
            }
        }

        private void Clear()
        {
            IDText.Clear();
            TitleText.Clear();
            AuthorBox.ResetText();
            PublisherBox.ResetText();
            CategoryBox.ResetText();
            GenreBox.ResetText();
            ISBNText.Clear();
            StockNumeric.Value = 0;
            LoanNumeric.Value = 0;
            index = 0;
        }




        //Toolbox Code

        private void BrowseButton_Click(object sender, EventArgs e)
        {
            BookSearchForm search = new BookSearchForm();
            DialogResult r = search.ShowDialog();
            if (r == DialogResult.OK)
            {
                IDText.Text = search.GetData[0];
                TitleText.Text = search.GetData[1];
                AuthorBox.Text = search.GetData[5];
                PublisherBox.Text = search.GetData[6];
                CategoryBox.Text = search.GetData[3];
                GenreBox.Text = search.GetData[4];
                ISBNText.Text = search.GetData[2];
                StockNumeric.Text = search.GetData[7];
                LoanNumeric.Text = search.GetData[8];
            }
            for (int i = 0; i < context.Books.Count(); i++)
            {
                if (IDText.Text.Trim() == context.Books.AsEnumerable().ElementAt(i).BookID.ToString())
                {
                    index = i;
                    break;
                }
            }
        }

        private void UpdateButton_Click(object sender, EventArgs e)
        {
            Book b = context.Books.Where(x => x.BookID.ToString() == IDText.Text.Trim()).First();
            DatatoDatabase(b);

            if (NoNull() == DialogResult.OK)
            {
                context.SaveChanges();
                MessageBox.Show("Update Successful");
            }
            else
            {
                MessageBox.Show("Some informations are missing");
            }
        }

        private void ResetButton_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void AuthorBox_MouseClick(object sender, MouseEventArgs e)
        {
            AuthorBox.DataSource = context.Books.Select(x => x.Author).Distinct().ToList();
        }

        private void PublisherBox_MouseClick(object sender, MouseEventArgs e)
        {
            PublisherBox.DataSource = context.Books.Select(x => x.Publisher).Distinct().ToList();
        }

        private void CategoryBox_MouseClick(object sender, MouseEventArgs e)
        {
            CategoryBox.DataSource = context.Books.Select(x => x.BookCategory).Distinct().ToList();
        }

        private void GenreBox_MouseClick(object sender, MouseEventArgs e)
        {
            GenreBox.DataSource = context.Books.Select(x => x.Genre).Distinct().ToList();
        }

        private void ISBNText_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Can only accept numeric value.");
            }
        }

        private void StockNumeric_ValueChanged(object sender, EventArgs e)
        {
            if (StockNumeric.Value < LoanNumeric.Value)
            {
                MessageBox.Show("Number of stock can't be lower than number of loaned!");
                StockNumeric.Value = LoanNumeric.Value;
            }
        }

        private void StockNumeric_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Can only accept numeric value.");
            }
        }

        private void LoanNumeric_ValueChanged(object sender, EventArgs e)
        {
            if (StockNumeric.Value < LoanNumeric.Value)
            {
                MessageBox.Show("Number of stock can't be lower than number of loaned!");
                LoanNumeric.Value = StockNumeric.Value;
            }
        }

        private void LoanNumeric_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Can only accept numeric value.");
            }
        }

        private void NextButton_Click(object sender, EventArgs e)
        {
            NoNull();
            if (NoNull() == DialogResult.OK)
            {
                if (index < (context.Books.Count() - 1))
                {
                    index++;
                    DatatoForm(index);
                }
                else
                {
                    MessageBox.Show("You are at the end of the record!");
                }
            }
            else
            {
                MessageBox.Show("No Record to show");
            }
        }

        private void PreviousButton_Click(object sender, EventArgs e)
        {
            NoNull();
            if (NoNull() == DialogResult.OK)
            {
                if (index > 0)
                {
                    index--;
                    DatatoForm(index);
                }
                else
                {
                    MessageBox.Show("You are at the start of the record!");
                }
            }
            else
            {
                MessageBox.Show("No Record to show");
            }
        }

        private void LastButton_Click(object sender, EventArgs e)
        {
            index = context.Books.Count() - 1;
            DatatoForm(index);
        }

        private void FirstButton_Click(object sender, EventArgs e)
        {
            index = 0;
            DatatoForm(index);
        }

        private void FindButton_Click(object sender, EventArgs e)
        {
            Boolean check = false;
            for (int i = 0; i < context.Books.Count(); i++)
            {
                if (IDFindText.Text.Trim() == context.Books.AsEnumerable().ElementAt(i).BookID.ToString())
                {
                    DatatoForm(i);
                    index = i;
                    check = true;
                    break;
                }
                else
                {
                    check = false;
                }
            }
            if (check == false)
            {
                MessageBox.Show("Record not found");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
