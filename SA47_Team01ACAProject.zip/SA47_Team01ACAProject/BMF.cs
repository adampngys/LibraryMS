﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using System.Transactions;


namespace SA47_Team01ACAProject
{
    public partial class BMF : Form
    {
        SA47_Team01aCADatabaseEntities context;
        int first = 0;
        int index = 0;
        int last = 0;
        int current = 0;
        public BMF()
        {
            InitializeComponent();
            context = new SA47_Team01aCADatabaseEntities();
            List<Book> orderedlist = context.Books.OrderBy(x => x.BookID).ToList();
            first = Convert.ToInt16(orderedlist.FirstOrDefault().BookID);
            List<Book> reverselist = context.Books.OrderByDescending(x => x.BookID).ToList();
            last = Convert.ToInt16(reverselist.FirstOrDefault().BookID);
        }

        //METHODS
        private void DatatoForm(int index)
        {
            IDText.Text = context.Books.Where(x => x.BookID == index).FirstOrDefault().BookID.ToString();
            TitleText.Text = context.Books.Where(x => x.BookID == index).FirstOrDefault().BookTitle.ToString();
            AuthorBox.Text = context.Books.Where(x => x.BookID == index).FirstOrDefault().Author.ToString();
            PublisherBox.Text = context.Books.Where(x => x.BookID == index).FirstOrDefault().Publisher.ToString();
            CategoryBox.Text = context.Books.Where(x => x.BookID == index).FirstOrDefault().BookCategory.ToString();
            GenreBox.Text = context.Books.Where(x => x.BookID == index).FirstOrDefault().Genre.ToString();
            ISBNText.Text = context.Books.Where(x => x.BookID == index).FirstOrDefault().ISBN.ToString();
            StockNumeric.Text = context.Books.Where(x => x.BookID == index).FirstOrDefault().TotalStock.ToString();
            LoanNumeric.Text = context.Books.Where(x => x.BookID == index).FirstOrDefault().NumberLoaned.ToString();
            toolStripStatusLabel1.Text = "Record: " + index;
        }
        private void DatatoDatabase(Book b)
        {
            b.BookTitle = TitleText.Text.Trim();
            b.Author = AuthorBox.Text.Trim();
            b.Publisher = PublisherBox.Text.Trim();
            b.BookCategory = CategoryBox.Text.Trim();
            b.Genre = GenreBox.Text.Trim();
            b.ISBN = ISBNText.Text.Trim();
            b.TotalStock = Convert.ToInt16(StockNumeric.Text.Trim());
            b.NumberLoaned = Convert.ToInt16(LoanNumeric.Text.Trim());
        }
        private DialogResult NoNull()
        {
            if (string.IsNullOrWhiteSpace(TitleText.Text) || string.IsNullOrWhiteSpace(AuthorBox.Text) ||
                string.IsNullOrWhiteSpace(PublisherBox.Text) || string.IsNullOrWhiteSpace(CategoryBox.Text) ||
                string.IsNullOrWhiteSpace(GenreBox.Text) || string.IsNullOrWhiteSpace(ISBNText.Text) ||
                string.IsNullOrWhiteSpace(StockNumeric.Text) || string.IsNullOrWhiteSpace(LoanNumeric.Text))
            {
                return DialogResult.Cancel;
            }
            else
            {
                return DialogResult.OK;
            }
        }

        //NAVIGATION

        //go to first record
        private void FirstButton_Click(object sender, EventArgs e)
        {
            index = first;
            DatatoForm(index);
        }
        //go to last record
        private void LastButton_Click(object sender, EventArgs e)
        {
            index = last;
            DatatoForm(index);
        }
        //go to next record
        private void NextButton_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(IDText.Text))
            {
                index = first;
                DatatoForm(index);
            }
            else
            {
                current = Convert.ToInt32(IDText.Text);
                if (current == last)
                {
                    toolStripStatusLabel1.Text = "You are at the last record.";
                }
                else
                {
                    index = Convert.ToInt16(context.Books.OrderBy(x => x.BookID).Where(y => y.BookID > current).FirstOrDefault().BookID);
                    DatatoForm(index);
                }
            }                
        }
        //go to previous record
        private void PreviousButton_Click(object sender, EventArgs e)
        {            
            if(string.IsNullOrEmpty(IDText.Text))
            {
                index = first;
                DatatoForm(index);
            }
            else
            {
                current = Convert.ToInt32(IDText.Text);
                if (current == first)
                {
                    toolStripStatusLabel1.Text = "You are at the first record.";
                }
                else
                {
                    index = Convert.ToInt16(context.Books.OrderByDescending(x => x.BookID).Where(y => y.BookID < current).FirstOrDefault().BookID);
                    DatatoForm(index);
                }
            }
        }

        //ACTIONS

        //find book by BookID
        private void FindButton_Click(object sender, EventArgs e)
        {
            if (IDFindText.Text == "")
            {
                //MessageBox.Show("Please enter a BookID in the textbox to begin find.");
                toolStripStatusLabel1.Text = "Please enter a BookID in the textbox to begin find.";
            }
            else
            {
                int findme = Convert.ToInt32(IDFindText.Text);
                if (context.Books.Where(x => x.BookID == findme).FirstOrDefault() != null)
                {
                    index = findme;
                    DatatoForm(index);
                }
                else
                {
                    toolStripStatusLabel1.Text = "BookID not found.";
                }
            }
        }

        //clears all textboxes
        private void ResetButton_Click(object sender, EventArgs e)
        {
            IDText.Clear();
            TitleText.Clear();
            AuthorBox.ResetText();
            PublisherBox.ResetText();
            CategoryBox.ResetText();
            GenreBox.ResetText();
            ISBNText.Clear();
            StockNumeric.Value = 0;
            LoanNumeric.Value = 0;
            index = 0;
        }

        //insert new Book
        private void InsertButton_Click(object sender, EventArgs e)
        {
            Book a = new Book();
            DatatoDatabase(a);            
            a.NumberLoaned = 0; //set default loan number

            if (NoNull() == DialogResult.OK)
            {
                using (TransactionScope ts = new TransactionScope())
                {
                    context.Books.Add(a);
                    context.SaveChanges();
                    ts.Complete();
                }                   
                IDText.Text = a.BookID.ToString();
                MessageBox.Show("Successfully added " + TitleText.Text + Environment.NewLine
                        + TitleText.Text + " Book ID is " + a.BookID);                
            }
            else
            {
                MessageBox.Show("Some information is missing.");
            }
        }
        
        //update Book       
        private void UpdateButton_Click(object sender, EventArgs e)
        {
            if (NoNull() == DialogResult.OK)
            {
                Book b = context.Books.Where(x => x.BookID.ToString() == IDText.Text.Trim()).First();
                DatatoDatabase(b);
                context.SaveChanges();
                MessageBox.Show("Update Successful");
            }
            else
            {
                MessageBox.Show("Some information is missing.");
            }
        }

        //delete Book
        private void DeleteButton_Click(object sender, EventArgs e)
        {
            if (NoNull() == DialogResult.OK)
            {
                current = Convert.ToInt32(IDText.Text);
                Book c = context.Books.Where(x => x.BookID == current).First();
                context.Books.Remove(c);
                DialogResult dialogResult = MessageBox.Show("Delete this book permanently?", "ATTENTION", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    context.SaveChanges();
                    MessageBox.Show("Book has been deleted.");
                }
                else
                {
                    MessageBox.Show("No changes were made.");
                }
            }
            else
            {
                MessageBox.Show("Some information is missing.");
            }
        }
        
        //VALIDATION CHECKS
        //ISBN, TotalStock and NumberLoaned textboxes can only accept numbers
        private void ISBNText_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Please enter numeric values only.");
            }
        }
        private void StockNumeric_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Please enter numeric values only.");
            }
        }
        private void LoanNumeric_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Please enter numeric values only.");
            }
        }

        //TotalStock > NumberLoaned
        private void StockNumeric_ValueChanged(object sender, EventArgs e)
        {
            if (StockNumeric.Value < LoanNumeric.Value)
            {
                MessageBox.Show("Total stock can't be lower than number of loaned!");
                StockNumeric.Value = LoanNumeric.Value;
            }
        }

        //NumberLoaned cannot be > TotalStock
        private void LoanNumeric_ValueChanged(object sender, EventArgs e)
        {
            if (StockNumeric.Value < LoanNumeric.Value)
            {
                MessageBox.Show("Total stock can't be lower than number of loaned!");
                LoanNumeric.Value = StockNumeric.Value;
            }
        }
    }
}
