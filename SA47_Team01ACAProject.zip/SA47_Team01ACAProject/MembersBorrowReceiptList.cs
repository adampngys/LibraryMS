﻿using SA47_Team01ACAProject;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SA47_Team01ACAProject_CrystalReports
{
    public partial class MembersBorrowReceiptList : Form
    {
        public MembersBorrowReceiptList()
        {
            InitializeComponent();
        }

        private void crystalReportViewer1_Load(object sender, EventArgs e)
        {
            SA47_Team01ACAProject_Dataset ds = new SA47_Team01ACAProject_Dataset();
            SA47_Team01ACAProject.SA47_Team01ACAProject_DatasetTableAdapters.MembersTableAdapter ta = new SA47_Team01ACAProject.SA47_Team01ACAProject_DatasetTableAdapters.MembersTableAdapter();
            SA47_Team01ACAProject.SA47_Team01ACAProject_DatasetTableAdapters.IssueTransactionTableAdapter ta2 = new SA47_Team01ACAProject.SA47_Team01ACAProject_DatasetTableAdapters.IssueTransactionTableAdapter();
            SA47_Team01ACAProject.SA47_Team01ACAProject_DatasetTableAdapters.BooksTableAdapter ta3 = new SA47_Team01ACAProject.SA47_Team01ACAProject_DatasetTableAdapters.BooksTableAdapter();
            ta.Fill(ds.Members);
            ta2.Fill(ds.IssueTransaction);
            ta3.Fill(ds.Books);
            MembersBorrowReceiptListCR cr = new MembersBorrowReceiptListCR();
            cr.SetDataSource(ds);
            crystalReportViewer1.ReportSource = cr;
        }
    }
}
