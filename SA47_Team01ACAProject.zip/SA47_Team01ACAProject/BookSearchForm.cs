﻿using SA47_Team01ACAProject;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace SA47_Team01ACAProject
{
    public partial class BookSearchForm : Form
    {
        SA47_Team01aCADatabaseEntities model = new SA47_Team01aCADatabaseEntities();
        string[] Data = new string[9];
        public string[] GetData
        {
            get
            {
                return Data;
            }
        }
        public BookSearchForm()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ToolTip toolTip1 = new ToolTip();
            var bookTitle = from x in model.Books select x.BookTitle;
            SearchBook.DataSource = bookTitle.ToList();
            SearchBook.DataSource = bookTitle.ToList();
            SearchBook.SelectedIndex = -1;
            toolTip1.SetToolTip(this.SearchBook, "If This is Blank, it will list all Books.");
            toolTip1.SetToolTip(this.SearchISDN, "Please 13 Digit ISDN code or Select form List.");

            SearchCategory.DataSource = model.Books.Select(x => x.BookCategory).Distinct().ToList();
            SearchCategory.SelectedIndex = -1;

            SearchGenre.DataSource = model.Books.Select(x => x.Genre).Distinct().ToList();
            SearchGenre.SelectedIndex = -1;

            SearchAuthor.DataSource = model.Books.Select(x => x.Author).Distinct().ToList();
            SearchAuthor.SelectedIndex = -1;


            SearchPublisher.DataSource = model.Books.Select(x => x.Publisher).Distinct().ToList();
            SearchPublisher.SelectedIndex = -1;

            SearchBookID.DataSource = model.Books.Select(x => x.BookID).Distinct().ToList();
            SearchBookID.SelectedIndex = -1;

            SearchISDN.DataSource = model.Books.Select(x => x.ISBN).Distinct().ToList();
            SearchISDN.SelectedIndex = -1;


            SearchMltCategory.DataSource = model.Books.Select(x => x.BookCategory).Distinct().ToList();
            SearchMltCategory.SelectedIndex = -1;

            SearchMltGenre.DataSource = model.Books.Select(x => x.Genre).Distinct().ToList();
            SearchMltGenre.SelectedIndex = -1;

            SearchMltAuthor.DataSource = model.Books.Select(x => x.Author).Distinct().ToList();
            SearchMltAuthor.SelectedIndex = -1; 
        }

        private void SearchForBook_Click(object sender, EventArgs e)
        {
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            if (SearchBook.Text == "")
            {
                var q = from x in model.Books
                        select new
                        {
                            x.BookID,
                            x.BookTitle,
                            x.ISBN,
                            x.BookCategory,
                            x.Genre,
                            x.Author,
                            x.Publisher,
                            x.TotalStock,
                            x.NumberLoaned
                        };
                dataGridView1.DataSource = q.ToList();
                toolStripStatusLabel1.Text = "Total Number of Records : " +
                         Convert.ToString(model.Books.Count());
            }

            else
            {

                for (int i = 0; i < SearchBook.Items.Count; i++)
                {
                    if (SearchBook.Text == SearchBook.GetItemText(SearchBook.Items[i]))
                    {


                        string value = SearchBook.GetItemText(SearchBook.Items[i]);
                        var q = from x in model.Books
                                where x.BookTitle == value
                                select new
                                {
                                    x.BookID,
                                    x.BookTitle,
                                    x.ISBN,
                                    x.BookCategory,
                                    x.Genre,
                                    x.Author,
                                    x.Publisher,
                                    x.TotalStock,
                                    x.NumberLoaned
                                };
                        dataGridView1.DataSource = q.ToList();

                        toolStripStatusLabel1.Text = "Total Number of Records : " +
                             Convert.ToString(model.Books.Where(x => x.BookTitle == value).Count());
                    }
                }

                int index = SearchBook.FindString(SearchBook.Text);
                if (index < 0)
                {
                    MessageBox.Show("Sorry, No Title Found, Please Try Again");
                }
                SearchBook.SelectedIndex = -1;
            }
        }

        private void SearchForCategory_Click(object sender, EventArgs e)
        {
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            if (SearchCategory.SelectedIndex == -1)
            {
                MessageBox.Show("Nothing is Selected, Please Try Again");

            }
             
            for (int i = 0; i < SearchCategory.Items.Count; i++)
            {
                if (SearchCategory.Text == SearchCategory.GetItemText(SearchCategory.Items[i]))
                {


                    string value = SearchCategory.GetItemText(SearchCategory.Items[i]);
                    var q = from x in model.Books
                            where x.BookCategory == value
                            select new
                            {
                                x.BookID,
                                x.BookTitle,
                                x.ISBN,
                                x.BookCategory,
                                x.Genre,
                                x.Author,
                                x.Publisher,
                                x.TotalStock,
                                x.NumberLoaned
                            };
                    dataGridView1.DataSource = q.ToList();

                    toolStripStatusLabel1.Text = "Total Number of Records : " +
                         Convert.ToString(model.Books.Where(x => x.BookCategory == value).Count());
                }
            }
            SearchCategory.SelectedIndex = -1;
            }
           
        private void SearchForGenre_Click(object sender, EventArgs e)
        {
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            if (SearchGenre.SelectedIndex == -1)
            {
                MessageBox.Show("Nothing is Selected, Please Try Again");

            }
            for (int i = 0; i < SearchGenre.Items.Count; i++)
            {
                SearchGenre.Refresh();
                if (SearchGenre.Text == SearchGenre.GetItemText(SearchGenre.Items[i]))
                {
                    string value = SearchGenre.GetItemText(SearchGenre.Items[i]);
                    var q = from x in model.Books
                            where x.Genre == value
                            select new
                            {
                                x.BookID,
                                x.BookTitle,
                                x.ISBN,
                                x.BookCategory,
                                x.Genre,
                                x.Author,
                                x.Publisher,
                                x.TotalStock,
                                x.NumberLoaned
                            };
                    dataGridView1.DataSource = q.ToList();
                    toolStripStatusLabel1.Text = "Total Number of Records : " + 
                        Convert.ToString(model.Books.Where(x => x.Genre == value).Count());
                }
            }
            SearchGenre.SelectedIndex = -1;
        }

        private void SearchForAuthor_Click(object sender, EventArgs e)
        {
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            if (SearchAuthor.SelectedIndex == -1)
            {
                MessageBox.Show("Nothing is Selected, Please Try Again");

            }
            for (int i = 0; i < SearchAuthor.Items.Count; i++)
            {
                SearchAuthor.Refresh();
                if (SearchAuthor.Text == SearchAuthor.GetItemText(SearchAuthor.Items[i]))
                {
                    string value = SearchAuthor.GetItemText(SearchAuthor.Items[i]);
                    var q = from x in model.Books
                            where x.Author == value
                            select new
                            {
                                x.BookID,
                                x.BookTitle,
                                x.ISBN,
                                x.BookCategory,
                                x.Genre,
                                x.Author,
                                x.Publisher,
                                x.TotalStock,
                                x.NumberLoaned
                            };
                    dataGridView1.DataSource = q.ToList();

                    toolStripStatusLabel1.Text = "Total Number of Records : " +
                        Convert.ToString(model.Books.Where(x => x.Author == value).Count());
                }
            }
            SearchAuthor.SelectedIndex = -1;
        }

        private void SearchForPublisher_Click(object sender, EventArgs e)
        {
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            if (SearchPublisher.SelectedIndex == -1)
            {
                MessageBox.Show("Nothing is Selected, Please Try Again");

            }
            for (int i = 0; i < SearchPublisher.Items.Count; i++)
            {
                SearchPublisher.Refresh();
                if (SearchPublisher.Text == SearchPublisher.GetItemText(SearchPublisher.Items[i]))
                {
                    string value = SearchPublisher.GetItemText(SearchPublisher.Items[i]);
                    var q = from x in model.Books
                            where x.Publisher == value
                            select new
                            {
                                x.BookID,
                                x.BookTitle,
                                x.ISBN,
                                x.BookCategory,
                                x.Genre,
                                x.Author,
                                x.Publisher,
                                x.TotalStock,
                                x.NumberLoaned
                            };
                    dataGridView1.DataSource = q.ToList();
                    toolStripStatusLabel1.Text = "Total Number of Records : " +
                        Convert.ToString(model.Books.Where(x => x.Publisher == value).Count());
                }
            }
            SearchPublisher.SelectedIndex = -1;
        }

        private void SearchForBookID_Click(object sender, EventArgs e)
        {
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            if (SearchBookID.SelectedIndex == -1)
            {
                MessageBox.Show("Nothing is Selected, Please Try Again");

            }
            for (int i = 0; i < SearchBookID.Items.Count; i++)
            {
                SearchBookID.Refresh();
                if (SearchBookID.Text == SearchBookID.GetItemText(SearchBookID.Items[i]))
                {
                    int value = Convert.ToInt32(SearchBookID.GetItemText(SearchBookID.Items[i]));

                    var q = from x in model.Books
                            where x.BookID == value
                            select new
                            {
                                x.BookID,
                                x.BookTitle,
                                x.ISBN,
                                x.BookCategory,
                                x.Genre,
                                x.Author,
                                x.Publisher,
                                x.TotalStock,
                                x.NumberLoaned
                            };
                    dataGridView1.DataSource = q.ToList();

                    toolStripStatusLabel1.Text = "Total Number of Records : " +
                            Convert.ToString(model.Books.Where(x => x.BookID == value).Count());
                }
            }
            SearchBookID.SelectedIndex = -1;
        }

        private void SearchForISDN_Click(object sender, EventArgs e)
        {
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            if (SearchISDN.Text == "")     //(SearchISDN.SelectedIndex == -1)
            {
                MessageBox.Show("Nothing is Selected, Please Try Again");

            }

            else { 
            for (int i = 0; i < SearchISDN.Items.Count; i++)
            {
                SearchISDN.Refresh();
                if (SearchISDN.Text == SearchISDN.GetItemText(SearchISDN.Items[i]))
                {
                    string value = SearchISDN.GetItemText(SearchISDN.Items[i]);
                    var q = from x in model.Books
                            where x.ISBN == value
                            select new
                            {
                                x.BookID,
                                x.BookTitle,
                                x.ISBN,
                                x.BookCategory,
                                x.Genre,
                                x.Author,
                                x.Publisher,
                                x.TotalStock,
                                x.NumberLoaned
                            };
                    dataGridView1.DataSource = q.ToList();

                    toolStripStatusLabel1.Text = "Total Number of Records : " +
                           Convert.ToString(model.Books.Where(x => x.ISBN == value).Count());
                }
            }

            int index = SearchISDN.FindString(SearchISDN.Text);
            if (index < 0)
            {
                MessageBox.Show("Sorry, No ISDN Found, Please Try Again");
            }
            SearchISDN.SelectedIndex = -1;
            }
        }

        private void SearchForTotal_Click(object sender, EventArgs e)
        {
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            int value = Convert.ToInt32(SearchTotalStock.Text);

            var q = from x in model.Books
                    where x.TotalStock <= value
                    select new
                    {
                        x.BookID,
                        x.BookTitle,
                        x.ISBN,
                        x.BookCategory,
                        x.Genre,
                        x.Author,
                        x.Publisher,
                     x.TotalStock,
                        x.NumberLoaned
                    };
            dataGridView1.DataSource = q.ToList();
            toolStripStatusLabel1.Text = "Total Number of Records : " + q.Count();
            // Convert.ToString(model.Books.Where(x => x.TotalStock == value).Count());
            SearchTotalStock.Text = "0";

        }

        private void SearchForLoanQty_Click(object sender, EventArgs e)
        {
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            int value = Convert.ToInt32(SearchLoanedQty.Text);

            var q = from x in model.Books
                    where x.NumberLoaned <= value
                    select new
                    {
                        x.BookID,
                        x.BookTitle,
                        x.ISBN,
                        x.BookCategory,
                        x.Genre,
                        x.Author,
                        x.Publisher,
                        x.TotalStock,
                        x.NumberLoaned
                    };
            dataGridView1.DataSource = q.ToList();
            toolStripStatusLabel1.Text = "Total Number of Records : " + q.Count();
            // Convert.ToString(model.Books.Where(x => x.NumberLoaned == value).Count());

            SearchLoanedQty.Text = "0";
        }

        private void SearchMltCatGenAut_Click(object sender, EventArgs e)
        {
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;


            int totalStk = Convert.ToInt32(SearchMltTotalStock.Text);
            int loanQty = Convert.ToInt32(SearchMltLoanedQty.Text);



            //5 criteria
            if (SearchMltCategory.Text != "" && SearchMltGenre.Text != ""
                && SearchMltAuthor.Text != "" && SearchMltTotalStock.Text != ""
                && SearchMltLoanedQty.Text != "")
            {
                dataGridView1.DataSource = model.Books.Where
                (x => x.BookCategory == SearchMltCategory.Text &&
                x.Author == SearchMltAuthor.Text
                && x.Genre == SearchMltGenre.Text && x.TotalStock <= totalStk
                && x.NumberLoaned <= loanQty).ToList();
                toolStripStatusLabel1.Text = "Total Number of Records : " +
                        Convert.ToString(dataGridView1.RowCount);
            }


            else if (SearchMltCategory.Text != "" && SearchMltGenre.Text != ""
                 && SearchMltTotalStock.Text != ""
             && SearchMltLoanedQty.Text != "")
            {
                dataGridView1.DataSource = model.Books.Where
                (x => x.BookCategory == SearchMltCategory.Text &&
                x.Genre == SearchMltGenre.Text && x.TotalStock <= totalStk
                && x.NumberLoaned <= loanQty).ToList();
                toolStripStatusLabel1.Text = "Total Number of Records : " +
                        Convert.ToString(dataGridView1.RowCount);
            }

            else if (SearchMltAuthor.Text != "" && SearchMltGenre.Text != ""
           && SearchMltTotalStock.Text != ""
       && SearchMltLoanedQty.Text != "")
            {
                dataGridView1.DataSource = model.Books.Where
                (x => x.Author == SearchMltAuthor.Text &&
                x.Genre == SearchMltGenre.Text && x.TotalStock <= totalStk
                && x.NumberLoaned <= loanQty).ToList();
                toolStripStatusLabel1.Text = "Total Number of Records : " +
                        Convert.ToString(dataGridView1.RowCount);
            }

            else if (SearchMltCategory.Text != "" && SearchMltAuthor.Text != ""
             && SearchMltTotalStock.Text != ""
         && SearchMltLoanedQty.Text != "")
            {
                dataGridView1.DataSource = model.Books.Where
                (x => x.BookCategory == SearchMltCategory.Text &&
                x.Author == SearchMltAuthor.Text && x.TotalStock <= totalStk
                && x.NumberLoaned <= loanQty).ToList();
                toolStripStatusLabel1.Text = "Total Number of Records : " +
                        Convert.ToString(dataGridView1.RowCount);
            }
            else if (SearchMltCategory.Text != "" && SearchMltTotalStock.Text != ""
             && SearchMltLoanedQty.Text != "")
            {
                dataGridView1.DataSource = model.Books.Where
                (x => x.BookCategory == SearchMltCategory.SelectedItem.ToString() && x.TotalStock <= totalStk
                && x.NumberLoaned <= loanQty).ToList();
                toolStripStatusLabel1.Text = "Total Number of Records : " +
                        Convert.ToString(dataGridView1.RowCount);
            }

            else if (SearchMltGenre.Text != "" && SearchMltTotalStock.Text != ""
               && SearchMltLoanedQty.Text != "")
            {
                dataGridView1.DataSource = model.Books.Where
                (x => x.Genre == SearchMltGenre.SelectedItem.ToString() && x.TotalStock <= totalStk
                && x.NumberLoaned <= loanQty).ToList();
                toolStripStatusLabel1.Text = "Total Number of Records : " +
                        Convert.ToString(dataGridView1.RowCount);
            }

            else if (SearchMltAuthor.Text != "" && SearchMltTotalStock.Text != ""
              && SearchMltLoanedQty.Text != "")
            {
                dataGridView1.DataSource = model.Books.Where
                (x => x.Author == SearchMltAuthor.SelectedItem.ToString() && x.TotalStock <= totalStk
                && x.NumberLoaned <= loanQty).ToList();
                toolStripStatusLabel1.Text = "Total Number of Records : " +
                        Convert.ToString(dataGridView1.RowCount);
            }
        }

        private void SearchMltTotalStock_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true; MessageBox.Show("Please enter number!");
            }

        }

        private void SearchMltLoanedQty_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true; MessageBox.Show("Please enter number!");
            }
        }

        private void SearchTotalStock_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true; MessageBox.Show("Please enter number!");
            }
        }

        private void SearchLoanedQty_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true; MessageBox.Show("Please enter number!");
            }
        }

        private void SearchISDN_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true; MessageBox.Show("Please enter number!");
            }
        }

        private void SearchMltReset_Click(object sender, EventArgs e)
        {
            SearchMltAuthor.SelectedIndex = -1;
            SearchMltCategory.SelectedIndex = -1;
            SearchMltGenre.SelectedIndex = -1;
            SearchMltTotalStock.Text = "0";
            SearchMltLoanedQty.Text = "0";
        }

        private void SelectButton_Click(object sender, EventArgs e)
        {
            Data[0] = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            Data[1] = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
            Data[2] = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
            Data[3] = dataGridView1.SelectedRows[0].Cells[5].Value.ToString();
            Data[4] = dataGridView1.SelectedRows[0].Cells[6].Value.ToString();
            Data[5] = dataGridView1.SelectedRows[0].Cells[7].Value.ToString();
            Data[6] = dataGridView1.SelectedRows[0].Cells[8].Value.ToString();
            Data[7] = dataGridView1.SelectedRows[0].Cells[9].Value.ToString();
            Data[8] = dataGridView1.SelectedRows[0].Cells[10].Value.ToString();
            this.DialogResult = DialogResult.OK;
        }
    }
}