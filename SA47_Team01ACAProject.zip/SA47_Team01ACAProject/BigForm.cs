﻿using System;
using System.Windows.Forms;

namespace SA47_Team01ACAProject
{
    public partial class BigForm : Form
    {
        public BigForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SmallForm s = new SmallForm();
            s.ShowDialog();            
            s.Dispose();
            label1.Text = s.getData[0];
            label2.Text = s.getData[1];
            label3.Text = s.getData[2];
            label4.Text = s.getData[3];
        }
    }
}
