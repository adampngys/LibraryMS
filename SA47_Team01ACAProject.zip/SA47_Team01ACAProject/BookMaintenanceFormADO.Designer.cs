﻿namespace SA47_Team01ACAProject
{
    partial class BookMaintenanceFormADO
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BookMaintenanceFormADO));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.BooksPanel = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.LoanNumeric = new System.Windows.Forms.NumericUpDown();
            this.StockNumeric = new System.Windows.Forms.NumericUpDown();
            this.GenreBox = new System.Windows.Forms.ComboBox();
            this.CategoryBox = new System.Windows.Forms.ComboBox();
            this.PublisherBox = new System.Windows.Forms.ComboBox();
            this.AuthorBox = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.FindLabel = new System.Windows.Forms.Label();
            this.IDFindText = new System.Windows.Forms.TextBox();
            this.FindButton = new System.Windows.Forms.Button();
            this.SearchButton = new System.Windows.Forms.Button();
            this.LastButton = new System.Windows.Forms.Button();
            this.NextButton = new System.Windows.Forms.Button();
            this.FirstButton = new System.Windows.Forms.Button();
            this.PreviousButton = new System.Windows.Forms.Button();
            this.InsertButton = new System.Windows.Forms.Button();
            this.ResetButton = new System.Windows.Forms.Button();
            this.IDText = new System.Windows.Forms.TextBox();
            this.IDLabel = new System.Windows.Forms.Label();
            this.LoanLabel = new System.Windows.Forms.Label();
            this.DeleteButton = new System.Windows.Forms.Button();
            this.UpdateButton = new System.Windows.Forms.Button();
            this.ISBNText = new System.Windows.Forms.TextBox();
            this.StockLabel = new System.Windows.Forms.Label();
            this.ISBNLabel = new System.Windows.Forms.Label();
            this.GenreLabel = new System.Windows.Forms.Label();
            this.AuthorLabel = new System.Windows.Forms.Label();
            this.PublisherLabel = new System.Windows.Forms.Label();
            this.CategoryLabel = new System.Windows.Forms.Label();
            this.TitleText = new System.Windows.Forms.TextBox();
            this.TitleLabel = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.BooksPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LoanNumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.StockNumeric)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(15, 7);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(6);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(218, 221);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 93;
            this.pictureBox1.TabStop = false;
            // 
            // BooksPanel
            // 
            this.BooksPanel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.BooksPanel.Controls.Add(this.groupBox3);
            this.BooksPanel.Controls.Add(this.groupBox2);
            this.BooksPanel.Controls.Add(this.LoanNumeric);
            this.BooksPanel.Controls.Add(this.StockNumeric);
            this.BooksPanel.Controls.Add(this.button2);
            this.BooksPanel.Controls.Add(this.GenreBox);
            this.BooksPanel.Controls.Add(this.CategoryBox);
            this.BooksPanel.Controls.Add(this.PublisherBox);
            this.BooksPanel.Controls.Add(this.AuthorBox);
            this.BooksPanel.Controls.Add(this.groupBox1);
            this.BooksPanel.Controls.Add(this.IDText);
            this.BooksPanel.Controls.Add(this.IDLabel);
            this.BooksPanel.Controls.Add(this.LoanLabel);
            this.BooksPanel.Controls.Add(this.ISBNText);
            this.BooksPanel.Controls.Add(this.StockLabel);
            this.BooksPanel.Controls.Add(this.ISBNLabel);
            this.BooksPanel.Controls.Add(this.GenreLabel);
            this.BooksPanel.Controls.Add(this.AuthorLabel);
            this.BooksPanel.Controls.Add(this.PublisherLabel);
            this.BooksPanel.Controls.Add(this.CategoryLabel);
            this.BooksPanel.Controls.Add(this.TitleText);
            this.BooksPanel.Controls.Add(this.TitleLabel);
            this.BooksPanel.Location = new System.Drawing.Point(254, 16);
            this.BooksPanel.Margin = new System.Windows.Forms.Padding(6);
            this.BooksPanel.Name = "BooksPanel";
            this.BooksPanel.Size = new System.Drawing.Size(884, 752);
            this.BooksPanel.TabIndex = 92;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(25, 89);
            this.button1.Margin = new System.Windows.Forms.Padding(6);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(245, 44);
            this.button1.TabIndex = 91;
            this.button1.Text = "Insert by SQL";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // LoanNumeric
            // 
            this.LoanNumeric.Location = new System.Drawing.Point(263, 372);
            this.LoanNumeric.Margin = new System.Windows.Forms.Padding(6);
            this.LoanNumeric.Name = "LoanNumeric";
            this.LoanNumeric.Size = new System.Drawing.Size(108, 31);
            this.LoanNumeric.TabIndex = 8;
            // 
            // StockNumeric
            // 
            this.StockNumeric.Location = new System.Drawing.Point(263, 329);
            this.StockNumeric.Margin = new System.Windows.Forms.Padding(6);
            this.StockNumeric.Name = "StockNumeric";
            this.StockNumeric.Size = new System.Drawing.Size(108, 31);
            this.StockNumeric.TabIndex = 7;
            // 
            // GenreBox
            // 
            this.GenreBox.FormattingEnabled = true;
            this.GenreBox.Items.AddRange(new object[] {
            "Comedy",
            "Sci-Fi"});
            this.GenreBox.Location = new System.Drawing.Point(263, 241);
            this.GenreBox.Margin = new System.Windows.Forms.Padding(6);
            this.GenreBox.Name = "GenreBox";
            this.GenreBox.Size = new System.Drawing.Size(238, 33);
            this.GenreBox.TabIndex = 5;
            this.GenreBox.Text = " ";
            // 
            // CategoryBox
            // 
            this.CategoryBox.FormattingEnabled = true;
            this.CategoryBox.Items.AddRange(new object[] {
            "Fiction",
            "Non Fiction"});
            this.CategoryBox.Location = new System.Drawing.Point(263, 196);
            this.CategoryBox.Margin = new System.Windows.Forms.Padding(6);
            this.CategoryBox.Name = "CategoryBox";
            this.CategoryBox.Size = new System.Drawing.Size(238, 33);
            this.CategoryBox.TabIndex = 4;
            this.CategoryBox.Text = " ";
            // 
            // PublisherBox
            // 
            this.PublisherBox.FormattingEnabled = true;
            this.PublisherBox.Items.AddRange(new object[] {
            "Penguin"});
            this.PublisherBox.Location = new System.Drawing.Point(263, 151);
            this.PublisherBox.Margin = new System.Windows.Forms.Padding(6);
            this.PublisherBox.Name = "PublisherBox";
            this.PublisherBox.Size = new System.Drawing.Size(238, 33);
            this.PublisherBox.TabIndex = 3;
            this.PublisherBox.Text = " ";
            // 
            // AuthorBox
            // 
            this.AuthorBox.FormattingEnabled = true;
            this.AuthorBox.Items.AddRange(new object[] {
            "Roald Dahl"});
            this.AuthorBox.Location = new System.Drawing.Point(263, 106);
            this.AuthorBox.Margin = new System.Windows.Forms.Padding(6);
            this.AuthorBox.Name = "AuthorBox";
            this.AuthorBox.Size = new System.Drawing.Size(238, 33);
            this.AuthorBox.TabIndex = 2;
            this.AuthorBox.Text = " ";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.FindLabel);
            this.groupBox1.Controls.Add(this.IDFindText);
            this.groupBox1.Controls.Add(this.FindButton);
            this.groupBox1.Controls.Add(this.SearchButton);
            this.groupBox1.Location = new System.Drawing.Point(177, 587);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(6);
            this.groupBox1.Size = new System.Drawing.Size(591, 93);
            this.groupBox1.TabIndex = 41;
            this.groupBox1.TabStop = false;
            // 
            // FindLabel
            // 
            this.FindLabel.AutoSize = true;
            this.FindLabel.Location = new System.Drawing.Point(15, 30);
            this.FindLabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.FindLabel.Name = "FindLabel";
            this.FindLabel.Size = new System.Drawing.Size(164, 25);
            this.FindLabel.TabIndex = 43;
            this.FindLabel.Text = "Find by Book ID";
            // 
            // IDFindText
            // 
            this.IDFindText.Location = new System.Drawing.Point(197, 30);
            this.IDFindText.Margin = new System.Windows.Forms.Padding(6);
            this.IDFindText.Name = "IDFindText";
            this.IDFindText.Size = new System.Drawing.Size(146, 31);
            this.IDFindText.TabIndex = 19;
            this.IDFindText.TextChanged += new System.EventHandler(this.IDFindText_TextChanged);
            // 
            // FindButton
            // 
            this.FindButton.Location = new System.Drawing.Point(355, 23);
            this.FindButton.Margin = new System.Windows.Forms.Padding(6);
            this.FindButton.Name = "FindButton";
            this.FindButton.Size = new System.Drawing.Size(150, 44);
            this.FindButton.TabIndex = 20;
            this.FindButton.Text = "Find";
            this.FindButton.UseVisualStyleBackColor = true;
            this.FindButton.Click += new System.EventHandler(this.FindButton_Click);
            // 
            // SearchButton
            // 
            this.SearchButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.SearchButton.Location = new System.Drawing.Point(517, 23);
            this.SearchButton.Margin = new System.Windows.Forms.Padding(6);
            this.SearchButton.Name = "SearchButton";
            this.SearchButton.Size = new System.Drawing.Size(54, 44);
            this.SearchButton.TabIndex = 21;
            this.SearchButton.Text = "...";
            this.SearchButton.UseVisualStyleBackColor = true;
            // 
            // LastButton
            // 
            this.LastButton.Location = new System.Drawing.Point(325, 33);
            this.LastButton.Margin = new System.Windows.Forms.Padding(6);
            this.LastButton.Name = "LastButton";
            this.LastButton.Size = new System.Drawing.Size(58, 44);
            this.LastButton.TabIndex = 18;
            this.LastButton.Text = ">>";
            this.LastButton.UseVisualStyleBackColor = true;
            this.LastButton.Click += new System.EventHandler(this.LastButton_Click);
            // 
            // NextButton
            // 
            this.NextButton.Location = new System.Drawing.Point(271, 33);
            this.NextButton.Margin = new System.Windows.Forms.Padding(6);
            this.NextButton.Name = "NextButton";
            this.NextButton.Size = new System.Drawing.Size(42, 44);
            this.NextButton.TabIndex = 14;
            this.NextButton.Text = ">";
            this.NextButton.UseVisualStyleBackColor = true;
            this.NextButton.Click += new System.EventHandler(this.NextButton_Click);
            // 
            // FirstButton
            // 
            this.FirstButton.Location = new System.Drawing.Point(26, 33);
            this.FirstButton.Margin = new System.Windows.Forms.Padding(6);
            this.FirstButton.Name = "FirstButton";
            this.FirstButton.Size = new System.Drawing.Size(60, 44);
            this.FirstButton.TabIndex = 15;
            this.FirstButton.Text = "<<";
            this.FirstButton.UseVisualStyleBackColor = true;
            this.FirstButton.Click += new System.EventHandler(this.FirstButton_Click);
            // 
            // PreviousButton
            // 
            this.PreviousButton.Location = new System.Drawing.Point(98, 33);
            this.PreviousButton.Margin = new System.Windows.Forms.Padding(6);
            this.PreviousButton.Name = "PreviousButton";
            this.PreviousButton.Size = new System.Drawing.Size(42, 44);
            this.PreviousButton.TabIndex = 9;
            this.PreviousButton.Text = "<";
            this.PreviousButton.UseVisualStyleBackColor = true;
            this.PreviousButton.Click += new System.EventHandler(this.PreviousButton_Click);
            // 
            // InsertButton
            // 
            this.InsertButton.Location = new System.Drawing.Point(25, 33);
            this.InsertButton.Margin = new System.Windows.Forms.Padding(6);
            this.InsertButton.Name = "InsertButton";
            this.InsertButton.Size = new System.Drawing.Size(245, 44);
            this.InsertButton.TabIndex = 11;
            this.InsertButton.Text = "Insert by DataRow";
            this.InsertButton.UseVisualStyleBackColor = true;
            this.InsertButton.Click += new System.EventHandler(this.InsertButton_Click);
            // 
            // ResetButton
            // 
            this.ResetButton.Location = new System.Drawing.Point(152, 33);
            this.ResetButton.Margin = new System.Windows.Forms.Padding(6);
            this.ResetButton.Name = "ResetButton";
            this.ResetButton.Size = new System.Drawing.Size(107, 44);
            this.ResetButton.TabIndex = 10;
            this.ResetButton.Text = "&Reset";
            this.ResetButton.UseVisualStyleBackColor = true;
            this.ResetButton.Click += new System.EventHandler(this.ResetButton_Click);
            // 
            // IDText
            // 
            this.IDText.Enabled = false;
            this.IDText.Location = new System.Drawing.Point(263, 20);
            this.IDText.Margin = new System.Windows.Forms.Padding(6);
            this.IDText.Name = "IDText";
            this.IDText.Size = new System.Drawing.Size(104, 31);
            this.IDText.TabIndex = 0;
            // 
            // IDLabel
            // 
            this.IDLabel.AutoSize = true;
            this.IDLabel.Location = new System.Drawing.Point(113, 20);
            this.IDLabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.IDLabel.Name = "IDLabel";
            this.IDLabel.Size = new System.Drawing.Size(87, 25);
            this.IDLabel.TabIndex = 33;
            this.IDLabel.Text = "Book ID";
            // 
            // LoanLabel
            // 
            this.LoanLabel.AutoSize = true;
            this.LoanLabel.Location = new System.Drawing.Point(39, 372);
            this.LoanLabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.LoanLabel.Name = "LoanLabel";
            this.LoanLabel.Size = new System.Drawing.Size(165, 25);
            this.LoanLabel.TabIndex = 31;
            this.LoanLabel.Text = "Number Loaned";
            // 
            // DeleteButton
            // 
            this.DeleteButton.Location = new System.Drawing.Point(282, 33);
            this.DeleteButton.Margin = new System.Windows.Forms.Padding(6);
            this.DeleteButton.Name = "DeleteButton";
            this.DeleteButton.Size = new System.Drawing.Size(241, 44);
            this.DeleteButton.TabIndex = 13;
            this.DeleteButton.Text = "Delete by DataRow";
            this.DeleteButton.UseVisualStyleBackColor = true;
            this.DeleteButton.Click += new System.EventHandler(this.DeleteButton_Click);
            // 
            // UpdateButton
            // 
            this.UpdateButton.Location = new System.Drawing.Point(534, 33);
            this.UpdateButton.Margin = new System.Windows.Forms.Padding(6);
            this.UpdateButton.Name = "UpdateButton";
            this.UpdateButton.Size = new System.Drawing.Size(264, 44);
            this.UpdateButton.TabIndex = 12;
            this.UpdateButton.Text = "Update by DataRow";
            this.UpdateButton.UseVisualStyleBackColor = true;
            this.UpdateButton.Click += new System.EventHandler(this.UpdateButton_Click);
            // 
            // ISBNText
            // 
            this.ISBNText.Location = new System.Drawing.Point(263, 286);
            this.ISBNText.Margin = new System.Windows.Forms.Padding(6);
            this.ISBNText.MaxLength = 13;
            this.ISBNText.Name = "ISBNText";
            this.ISBNText.Size = new System.Drawing.Size(196, 31);
            this.ISBNText.TabIndex = 6;
            // 
            // StockLabel
            // 
            this.StockLabel.AutoSize = true;
            this.StockLabel.Location = new System.Drawing.Point(81, 329);
            this.StockLabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.StockLabel.Name = "StockLabel";
            this.StockLabel.Size = new System.Drawing.Size(120, 25);
            this.StockLabel.TabIndex = 44;
            this.StockLabel.Text = "Total Stock";
            // 
            // ISBNLabel
            // 
            this.ISBNLabel.AutoSize = true;
            this.ISBNLabel.Location = new System.Drawing.Point(141, 286);
            this.ISBNLabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.ISBNLabel.Name = "ISBNLabel";
            this.ISBNLabel.Size = new System.Drawing.Size(60, 25);
            this.ISBNLabel.TabIndex = 55;
            this.ISBNLabel.Text = "ISBN";
            // 
            // GenreLabel
            // 
            this.GenreLabel.AutoSize = true;
            this.GenreLabel.Location = new System.Drawing.Point(133, 241);
            this.GenreLabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.GenreLabel.Name = "GenreLabel";
            this.GenreLabel.Size = new System.Drawing.Size(71, 25);
            this.GenreLabel.TabIndex = 66;
            this.GenreLabel.Text = "Genre";
            // 
            // AuthorLabel
            // 
            this.AuthorLabel.AutoSize = true;
            this.AuthorLabel.Location = new System.Drawing.Point(129, 106);
            this.AuthorLabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.AuthorLabel.Name = "AuthorLabel";
            this.AuthorLabel.Size = new System.Drawing.Size(75, 25);
            this.AuthorLabel.TabIndex = 54;
            this.AuthorLabel.Text = "Author";
            // 
            // PublisherLabel
            // 
            this.PublisherLabel.AutoSize = true;
            this.PublisherLabel.Location = new System.Drawing.Point(105, 151);
            this.PublisherLabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.PublisherLabel.Name = "PublisherLabel";
            this.PublisherLabel.Size = new System.Drawing.Size(102, 25);
            this.PublisherLabel.TabIndex = 77;
            this.PublisherLabel.Text = "Publisher";
            // 
            // CategoryLabel
            // 
            this.CategoryLabel.AutoSize = true;
            this.CategoryLabel.Location = new System.Drawing.Point(51, 196);
            this.CategoryLabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.CategoryLabel.Name = "CategoryLabel";
            this.CategoryLabel.Size = new System.Drawing.Size(154, 25);
            this.CategoryLabel.TabIndex = 88;
            this.CategoryLabel.Text = "Book Category";
            // 
            // TitleText
            // 
            this.TitleText.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TitleText.Location = new System.Drawing.Point(263, 63);
            this.TitleText.Margin = new System.Windows.Forms.Padding(6);
            this.TitleText.Name = "TitleText";
            this.TitleText.Size = new System.Drawing.Size(602, 31);
            this.TitleText.TabIndex = 1;
            // 
            // TitleLabel
            // 
            this.TitleLabel.AutoSize = true;
            this.TitleLabel.Location = new System.Drawing.Point(101, 63);
            this.TitleLabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.TitleLabel.Name = "TitleLabel";
            this.TitleLabel.Size = new System.Drawing.Size(102, 25);
            this.TitleLabel.TabIndex = 55;
            this.TitleLabel.Text = "BookTitle";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(50, 692);
            this.button2.Margin = new System.Windows.Forms.Padding(6);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(150, 44);
            this.button2.TabIndex = 90;
            this.button2.Text = "Back";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(146, 257);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 25);
            this.label1.TabIndex = 94;
            this.label1.Text = "label1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(146, 282);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 25);
            this.label2.TabIndex = 95;
            this.label2.Text = "label2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 282);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(134, 25);
            this.label3.TabIndex = 97;
            this.label3.Text = "Last BookID:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 257);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(117, 25);
            this.label4.TabIndex = 96;
            this.label4.Text = "BookID #1:";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(282, 89);
            this.button3.Margin = new System.Windows.Forms.Padding(6);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(241, 44);
            this.button3.TabIndex = 92;
            this.button3.Text = "Delete by SQL";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(535, 89);
            this.button4.Margin = new System.Windows.Forms.Padding(6);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(264, 44);
            this.button4.TabIndex = 93;
            this.button4.Text = "Update by SQL";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button4);
            this.groupBox2.Controls.Add(this.UpdateButton);
            this.groupBox2.Controls.Add(this.button3);
            this.groupBox2.Controls.Add(this.DeleteButton);
            this.groupBox2.Controls.Add(this.button1);
            this.groupBox2.Controls.Add(this.InsertButton);
            this.groupBox2.Location = new System.Drawing.Point(25, 428);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(840, 150);
            this.groupBox2.TabIndex = 94;
            this.groupBox2.TabStop = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.LastButton);
            this.groupBox3.Controls.Add(this.ResetButton);
            this.groupBox3.Controls.Add(this.PreviousButton);
            this.groupBox3.Controls.Add(this.FirstButton);
            this.groupBox3.Controls.Add(this.NextButton);
            this.groupBox3.Location = new System.Drawing.Point(472, 315);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(393, 95);
            this.groupBox3.TabIndex = 95;
            this.groupBox3.TabStop = false;
            // 
            // BookMaintenanceFormADO
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1197, 783);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.BooksPanel);
            this.Name = "BookMaintenanceFormADO";
            this.Text = "BookMaintenanceFormADO";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.BookMaintenanceFormADO_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.BooksPanel.ResumeLayout(false);
            this.BooksPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LoanNumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.StockNumeric)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel BooksPanel;
        protected System.Windows.Forms.NumericUpDown LoanNumeric;
        private System.Windows.Forms.Button button2;
        protected System.Windows.Forms.NumericUpDown StockNumeric;
        protected System.Windows.Forms.ComboBox GenreBox;
        protected System.Windows.Forms.ComboBox CategoryBox;
        protected System.Windows.Forms.ComboBox PublisherBox;
        protected System.Windows.Forms.ComboBox AuthorBox;
        private System.Windows.Forms.GroupBox groupBox1;
        protected System.Windows.Forms.Label FindLabel;
        protected System.Windows.Forms.TextBox IDFindText;
        protected System.Windows.Forms.Button FindButton;
        protected System.Windows.Forms.Button SearchButton;
        protected System.Windows.Forms.Button LastButton;
        protected System.Windows.Forms.Button NextButton;
        protected System.Windows.Forms.Button FirstButton;
        protected System.Windows.Forms.Button PreviousButton;
        protected System.Windows.Forms.Button InsertButton;
        protected System.Windows.Forms.Button ResetButton;
        protected System.Windows.Forms.TextBox IDText;
        private System.Windows.Forms.Label IDLabel;
        private System.Windows.Forms.Label LoanLabel;
        protected System.Windows.Forms.Button DeleteButton;
        protected System.Windows.Forms.Button UpdateButton;
        protected System.Windows.Forms.TextBox ISBNText;
        private System.Windows.Forms.Label StockLabel;
        private System.Windows.Forms.Label ISBNLabel;
        private System.Windows.Forms.Label GenreLabel;
        private System.Windows.Forms.Label AuthorLabel;
        private System.Windows.Forms.Label PublisherLabel;
        private System.Windows.Forms.Label CategoryLabel;
        private System.Windows.Forms.Label TitleLabel;
        protected System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox TitleText;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        protected System.Windows.Forms.Button button3;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox2;
        protected System.Windows.Forms.Button button4;
    }
}