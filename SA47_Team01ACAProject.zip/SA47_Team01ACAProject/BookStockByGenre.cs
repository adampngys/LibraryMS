﻿using SA47_Team01ACAProject;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SA47_Team01ACAProject_CrystalReports
{
    public partial class BookStockByGenre : Form
    {
        public BookStockByGenre()
        {
            InitializeComponent();
        }

        private void crystalReportViewer1_Load(object sender, EventArgs e)
        {
            SA47_Team01aCADatabaseEntities ctx = new SA47_Team01aCADatabaseEntities();
            BookStockByGenreCR cr = new BookStockByGenreCR();

            cr.SetDataSource(ctx.Books);
            crystalReportViewer1.ReportSource = cr;
        }
    }
}
