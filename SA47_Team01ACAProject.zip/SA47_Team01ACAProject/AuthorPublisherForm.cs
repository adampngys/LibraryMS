﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SA47_Team01ACAProject
{
    public partial class AuthorPublisherForm : Form
    {
        SA47_Team01aCADatabaseEntities context;
        bool checkauthor;
        bool checkpublisher;

        public AuthorPublisherForm()
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;      
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            context = new SA47_Team01aCADatabaseEntities();
            dataGridView1.DataSource = context.Authors.ToList();
            dataGridView2.DataSource = context.Publishers.ToList();
            comboBox1.DataSource = context.Authors.Select(x => x.Country).Distinct().ToList();
            comboBox2.DataSource = context.Publishers.Select(x => x.Country).Distinct().ToList();
        }

        //Add Author
        private void button1_Click(object sender, EventArgs e)
        {
            Author a = new Author();
            a.AuthorName = textBox2.Text;
            a.Country = comboBox1.Text;
            a.AuthorWebsite = textBox4.Text;
            find(a);

            if (NoNull() == DialogResult.OK)
            {
                if(checkauthor != false)
                {
                    context.Authors.Add(a);
                    context.SaveChanges();
                    MessageBox.Show("New Author added!\nAuthor Name: " + a.AuthorName + "\nCountry: " + a.Country + "\nWebsite: " + a.AuthorWebsite);
                }    
                else
                {
                    MessageBox.Show("Author already in list.");
                }
            }
            else
            {
                MessageBox.Show("Some information is missing.");
            }
        }

        //Add Publisher
        private void button2_Click(object sender, EventArgs e)
        {
            Publisher p = new Publisher();
            p.PublisherName = textBox6.Text;
            p.Country = comboBox2.Text;
            p.PublisherWebsite = textBox1.Text;
            find1(p);

            if (NoNull1() == DialogResult.OK)
            {
                if (checkpublisher != false)
                {
                    context.Publishers.Add(p);
                    context.SaveChanges();
                    MessageBox.Show("New Publisher added!\nPublisher Name: " + p.PublisherName + "\nCountry: " + p.Country + "\nWebsite: " + p.PublisherWebsite);
                }
                else
                {
                    MessageBox.Show("Publisher already in list.");
                }
            }
            else
            {
                MessageBox.Show("Some information is missing.");
            }
        }
               

        //find Author
        private void button3_Click(object sender, EventArgs e)
        {
            string findauthor = textBox2.Text.ToString();
            try
            {
                foreach (DataGridViewRow d in dataGridView1.Rows)
                {
                    if (String.Equals(d.Cells[0].Value.ToString(), findauthor, StringComparison.OrdinalIgnoreCase))
                    {
                        d.Selected = true;
                        MessageBox.Show("This author is already in the records.");
                        break;
                    }
                }                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //find author 1
        private void find(Author a)
        {
            string s = a.AuthorName;
            try
            {
                foreach (DataGridViewRow d in dataGridView1.Rows)
                {
                    if (String.Equals(d.Cells[0].Value.ToString(), s, StringComparison.OrdinalIgnoreCase))
                    {
                        d.Selected = true;
                        MessageBox.Show("This author is already in the records.");
                        checkauthor = false;
                        break;
                    }
                    else
                    {
                        checkauthor = true;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //find Publisher
        private void button4_Click(object sender, EventArgs e)
        {
            string findpublisher = textBox6.Text.ToString();
            try
            {
                foreach (DataGridViewRow d in dataGridView2.Rows)
                {
                    if (String.Equals(d.Cells[0].Value.ToString(), findpublisher, StringComparison.OrdinalIgnoreCase))
                    {
                        d.Selected = true;
                        MessageBox.Show("This publisher is already in the records.");
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //find publisher 1
        private void find1(Publisher p)
        {
            string s = p.PublisherName;
            try
            {
                foreach (DataGridViewRow d in dataGridView2.Rows)
                {
                    if (String.Equals(d.Cells[0].Value.ToString(), s, StringComparison.OrdinalIgnoreCase))
                    {
                        d.Selected = true;
                        MessageBox.Show("This publisher is already in the records.");
                        checkpublisher = false;
                        break;
                    }
                    else
                    {
                        checkpublisher = true;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //check author name in textbox
        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            string findauthor = textBox2.Text.ToString();
            try
            {
                foreach (DataGridViewRow d in dataGridView1.Rows)
                {
                    if (String.Equals(d.Cells[0].Value.ToString(), findauthor, StringComparison.OrdinalIgnoreCase))
                    {
                        d.Selected = true;
                        MessageBox.Show("This author is already in the records.");
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //check publisher name in textbox
        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            string findpublisher = textBox6.Text.ToString();
            try
            {
                foreach (DataGridViewRow d in dataGridView2.Rows)
                {
                    if (String.Equals(d.Cells[0].Value.ToString(), findpublisher, StringComparison.OrdinalIgnoreCase))
                    {
                        d.Selected = true;
                        MessageBox.Show("This publisher is already in the records.");
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private DialogResult NoNull()
        {
            if (string.IsNullOrWhiteSpace(textBox2.Text) && string.IsNullOrWhiteSpace(comboBox1.Text))// ||
                                                                                                     //string.IsNullOrWhiteSpace(textBox5.Text) && string.IsNullOrWhiteSpace(textBox6.Text))
            {
                return DialogResult.Cancel;
            }
            else
            {
                return DialogResult.OK;
            }
        }

        private DialogResult NoNull1()
        {
            if (string.IsNullOrWhiteSpace(comboBox2.Text) && string.IsNullOrWhiteSpace(textBox6.Text))
            {
                return DialogResult.Cancel;
            }
            else
            {
                return DialogResult.OK;
            }
        }

        //refresh author list
        private void button5_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = context.Authors.ToList();
        }

        //refresh publisher list
        private void button6_Click(object sender, EventArgs e)
        {
            dataGridView2.DataSource = context.Publishers.ToList();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
