﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Transactions;

namespace SA47_Team01ACAProject
{
    public partial class Return_Book : Form
    {

        SA47_Team01aCADatabaseEntities context;
        int iMemid = 0;
        public Return_Book()
        {
            InitializeComponent();
        }

        private void Return_Book_Load(object sender, EventArgs e)
        {

            context = new SA47_Team01aCADatabaseEntities();
            ReturnDate.Text = DateTime.Now.Date.ToShortDateString();




        }

        private void DisplayResult1()
        {


            MemName.Text = context.Members.Where(x => x.MemberID == iMemid).First().MemberName.ToString();
            Transid.DataSource = context.IssueTransactions.Where(x => x.MemberID.ToString() == MemId.Text && x.LoanStatus == "Out").Select(y => y.TransactionID).ToList();


            toolStripStatusLabel1.Text = "Member Found!";
        }

        private void MemId_TextChanged(object sender, EventArgs e)
        {

            try
            {
                iMemid = Convert.ToInt16(MemId.Text);

                if (context.Members.Where(x => x.MemberID == iMemid).FirstOrDefault() != null)
                {
                    DisplayResult1();
                }

                else
                {
                    toolStripStatusLabel1.Text = "Member Not Found!";

                    MemName.ResetText();
                    MemName.Text = "";

                }
            }

            catch (Exception)
            {
                MessageBox.Show("Please enter a valid Member ID");
            }
        }


        private void Transid_TextChanged(object sender, EventArgs e)
        {
            SA47_Team01aCADatabaseEntities context = new SA47_Team01aCADatabaseEntities();
            IssueTransaction it = context.IssueTransactions.Where(x => x.TransactionID.ToString() == Transid.Text).FirstOrDefault();
            BookId.Text = it.BookID.ToString();

            Book b = context.Books.Where(x => x.BookID.ToString() == BookId.Text).FirstOrDefault();
            BookTitle.Text = b.BookTitle.ToString();



            IssueDate.Text = it.DateIssue.ToShortDateString();
            DueDate.Text = it.DateDue.ToShortDateString();

            ReturnDate.Text = DateTime.Now.Date.ToShortDateString();
            //ReturnDate.MinDate = IssueDate.Value;
            //ReturnDate.MaxDate = DueDate.Value;

            Remarks.DataSource = context.IssueTransactions.Where(x => x.TransactionID.ToString() == Transid.Text).Select(y => y.Remarks).ToList();


        }

        bool cont;
        private void CheckMember()
        {
            var CM = context.Members.Where(x => x.MemberID == iMemid).FirstOrDefault();
            if (CM == null)
            {
                MessageBox.Show("Member Not Found");
                cont = false;
            }
            else
            {
                cont = true;
            }
        }


        private void Submit_Click(object sender, EventArgs e)
        {

            SA47_Team01aCADatabaseEntities context = new SA47_Team01aCADatabaseEntities();

           
            CheckMember();


            if (cont == true)
            {
                using (TransactionScope ts = new TransactionScope())
                {


                    Book b = context.Books.Where(x => x.BookID.ToString() == BookId.Text).First();
                    b.NumberLoaned = Convert.ToInt16(b.NumberLoaned - 1);

                    // MessageBox.Show("Test");

                    IssueTransaction it = context.IssueTransactions.Where(x => x.TransactionID.ToString() == Transid.Text).First();
                    if (it.LoanStatus != "in")
                    {
                        it.LoanStatus = "in";
                    }

                    it.DateActualReturn = ReturnDate.Value;

                    context.SaveChanges();
                    MessageBox.Show("Return Book Successful!");
                    ts.Complete();
                    this.Close();
                }

            }

            else
            {
                MessageBox.Show("Sorry! Cannot Process Return");
            }

        }

        private void SearchMember_Click(object sender, EventArgs e)
        {
            SA47_Team01aCADatabaseEntities context = new SA47_Team01aCADatabaseEntities();
            PopupMember pum = new PopupMember();
            pum.WindowState = FormWindowState.Maximized;
            pum.StartPosition = FormStartPosition.CenterScreen;
            //pum.MdiParent = this;
            pum.dataGridView1.DataSource = context.Members.Select(y => new { y.MemberID, y.MemberName, y.DateofBirth, y.Gender, }).ToList();
            pum.ShowDialog();

            MemName.Text = pum.MemName;

            MemId.Text = pum.MemID;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
