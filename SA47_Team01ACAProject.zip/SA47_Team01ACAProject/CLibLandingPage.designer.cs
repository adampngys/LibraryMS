﻿namespace SA47_Team01ACAProject
{
    partial class CLibLandingPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CLibLandingPage));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.mainMenuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.memberMaintenanceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bookMaintenanceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.authorPublisherMaintenanceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.issueBookToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.returnBookToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.authorByBookCategoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bookStockByGenreToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bottom5MembersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.membersBorrowReceiptListToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.singleBorrowReceiptToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.transactionByGenreToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logoutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column10,
            this.Column9,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6,
            this.Column7,
            this.Column8});
            this.dataGridView1.Location = new System.Drawing.Point(24, 63);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowTemplate.Height = 33;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(930, 371);
            this.dataGridView1.TabIndex = 0;
            // 
            // Column1
            // 
            this.Column1.DataPropertyName = "TransactionID";
            this.Column1.HeaderText = "TransactionID";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // Column10
            // 
            this.Column10.DataPropertyName = "Member";
            this.Column10.HeaderText = "Member";
            this.Column10.Name = "Column10";
            this.Column10.ReadOnly = true;
            this.Column10.Visible = false;
            // 
            // Column9
            // 
            this.Column9.DataPropertyName = "Book";
            this.Column9.HeaderText = "Book";
            this.Column9.Name = "Column9";
            this.Column9.ReadOnly = true;
            this.Column9.Visible = false;
            // 
            // Column2
            // 
            this.Column2.DataPropertyName = "MemberID";
            this.Column2.HeaderText = "MemberID";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            // 
            // Column3
            // 
            this.Column3.DataPropertyName = "BookID";
            this.Column3.HeaderText = "BookID";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            // 
            // Column4
            // 
            this.Column4.DataPropertyName = "DateIssue";
            this.Column4.HeaderText = "DateIssue";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            // 
            // Column5
            // 
            this.Column5.DataPropertyName = "DateDue";
            this.Column5.HeaderText = "DateDue";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            // 
            // Column6
            // 
            this.Column6.DataPropertyName = "DateActualReturn";
            this.Column6.HeaderText = "DateActualReturn";
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            // 
            // Column7
            // 
            this.Column7.DataPropertyName = "LoanStatus";
            this.Column7.HeaderText = "LoanStatus";
            this.Column7.Name = "Column7";
            this.Column7.ReadOnly = true;
            // 
            // Column8
            // 
            this.Column8.DataPropertyName = "Remarks";
            this.Column8.HeaderText = "Remarks";
            this.Column8.Name = "Column8";
            this.Column8.ReadOnly = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(262, 460);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(216, 63);
            this.button1.TabIndex = 9;
            this.button1.Text = "Approve Extension";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(502, 460);
            this.button2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(216, 63);
            this.button2.TabIndex = 10;
            this.button2.Text = "Reject Extension";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 25);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(281, 25);
            this.label1.TabIndex = 11;
            this.label1.Text = "Current Extension Requests";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(738, 460);
            this.button3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(216, 63);
            this.button3.TabIndex = 12;
            this.button3.Text = "Refresh List";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(24, 460);
            this.button4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(216, 63);
            this.button4.TabIndex = 13;
            this.button4.Text = "Books on Loan";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mainMenuToolStripMenuItem,
            this.reportsToolStripMenuItem,
            this.logoutToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(12, 4, 0, 4);
            this.menuStrip1.Size = new System.Drawing.Size(1352, 46);
            this.menuStrip1.TabIndex = 14;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // mainMenuToolStripMenuItem
            // 
            this.mainMenuToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.memberMaintenanceToolStripMenuItem,
            this.bookMaintenanceToolStripMenuItem,
            this.authorPublisherMaintenanceToolStripMenuItem,
            this.issueBookToolStripMenuItem,
            this.returnBookToolStripMenuItem});
            this.mainMenuToolStripMenuItem.Name = "mainMenuToolStripMenuItem";
            this.mainMenuToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.M)));
            this.mainMenuToolStripMenuItem.Size = new System.Drawing.Size(151, 36);
            this.mainMenuToolStripMenuItem.Text = "&Main Menu";
            // 
            // memberMaintenanceToolStripMenuItem
            // 
            this.memberMaintenanceToolStripMenuItem.Name = "memberMaintenanceToolStripMenuItem";
            this.memberMaintenanceToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.M)));
            this.memberMaintenanceToolStripMenuItem.Size = new System.Drawing.Size(536, 38);
            this.memberMaintenanceToolStripMenuItem.Text = "&Member Maintenance";
            this.memberMaintenanceToolStripMenuItem.Click += new System.EventHandler(this.memberMaintenanceToolStripMenuItem_Click);
            // 
            // bookMaintenanceToolStripMenuItem
            // 
            this.bookMaintenanceToolStripMenuItem.Name = "bookMaintenanceToolStripMenuItem";
            this.bookMaintenanceToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.B)));
            this.bookMaintenanceToolStripMenuItem.Size = new System.Drawing.Size(536, 38);
            this.bookMaintenanceToolStripMenuItem.Text = "&Book Maintenance";
            this.bookMaintenanceToolStripMenuItem.Click += new System.EventHandler(this.bookMaintenanceToolStripMenuItem_Click);
            // 
            // authorPublisherMaintenanceToolStripMenuItem
            // 
            this.authorPublisherMaintenanceToolStripMenuItem.Name = "authorPublisherMaintenanceToolStripMenuItem";
            this.authorPublisherMaintenanceToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.A)));
            this.authorPublisherMaintenanceToolStripMenuItem.Size = new System.Drawing.Size(536, 38);
            this.authorPublisherMaintenanceToolStripMenuItem.Text = "&Author / Publisher  Maintenance";
            this.authorPublisherMaintenanceToolStripMenuItem.Click += new System.EventHandler(this.authorPublisherMaintenanceToolStripMenuItem_Click);
            // 
            // issueBookToolStripMenuItem
            // 
            this.issueBookToolStripMenuItem.Name = "issueBookToolStripMenuItem";
            this.issueBookToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.I)));
            this.issueBookToolStripMenuItem.Size = new System.Drawing.Size(536, 38);
            this.issueBookToolStripMenuItem.Text = "&Issue Book";
            this.issueBookToolStripMenuItem.Click += new System.EventHandler(this.issueBookToolStripMenuItem_Click);
            // 
            // returnBookToolStripMenuItem
            // 
            this.returnBookToolStripMenuItem.Name = "returnBookToolStripMenuItem";
            this.returnBookToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.R)));
            this.returnBookToolStripMenuItem.Size = new System.Drawing.Size(536, 38);
            this.returnBookToolStripMenuItem.Text = "&Return Book";
            this.returnBookToolStripMenuItem.Click += new System.EventHandler(this.returnBookToolStripMenuItem_Click);
            // 
            // reportsToolStripMenuItem
            // 
            this.reportsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.authorByBookCategoryToolStripMenuItem,
            this.bookStockByGenreToolStripMenuItem,
            this.bottom5MembersToolStripMenuItem,
            this.membersBorrowReceiptListToolStripMenuItem,
            this.singleBorrowReceiptToolStripMenuItem,
            this.transactionByGenreToolStripMenuItem});
            this.reportsToolStripMenuItem.Name = "reportsToolStripMenuItem";
            this.reportsToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.R)));
            this.reportsToolStripMenuItem.Size = new System.Drawing.Size(107, 38);
            this.reportsToolStripMenuItem.Text = "&Reports";
            // 
            // authorByBookCategoryToolStripMenuItem
            // 
            this.authorByBookCategoryToolStripMenuItem.Name = "authorByBookCategoryToolStripMenuItem";
            this.authorByBookCategoryToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.A)));
            this.authorByBookCategoryToolStripMenuItem.Size = new System.Drawing.Size(506, 38);
            this.authorByBookCategoryToolStripMenuItem.Text = "&Author by Book Category";
            this.authorByBookCategoryToolStripMenuItem.Click += new System.EventHandler(this.authorByBookCategoryToolStripMenuItem_Click);
            // 
            // bookStockByGenreToolStripMenuItem
            // 
            this.bookStockByGenreToolStripMenuItem.Name = "bookStockByGenreToolStripMenuItem";
            this.bookStockByGenreToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.B)));
            this.bookStockByGenreToolStripMenuItem.Size = new System.Drawing.Size(506, 38);
            this.bookStockByGenreToolStripMenuItem.Text = "&Book Stock by Genre";
            this.bookStockByGenreToolStripMenuItem.Click += new System.EventHandler(this.bookStockByGenreToolStripMenuItem_Click);
            // 
            // bottom5MembersToolStripMenuItem
            // 
            this.bottom5MembersToolStripMenuItem.Name = "bottom5MembersToolStripMenuItem";
            this.bottom5MembersToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.D5)));
            this.bottom5MembersToolStripMenuItem.Size = new System.Drawing.Size(506, 38);
            this.bottom5MembersToolStripMenuItem.Text = "Bottom &5 Members";
            this.bottom5MembersToolStripMenuItem.Click += new System.EventHandler(this.bottom5MembersToolStripMenuItem_Click);
            // 
            // membersBorrowReceiptListToolStripMenuItem
            // 
            this.membersBorrowReceiptListToolStripMenuItem.Name = "membersBorrowReceiptListToolStripMenuItem";
            this.membersBorrowReceiptListToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.M)));
            this.membersBorrowReceiptListToolStripMenuItem.Size = new System.Drawing.Size(506, 38);
            this.membersBorrowReceiptListToolStripMenuItem.Text = "&Members Borrow Receipt List";
            this.membersBorrowReceiptListToolStripMenuItem.Click += new System.EventHandler(this.membersBorrowReceiptListToolStripMenuItem_Click);
            // 
            // singleBorrowReceiptToolStripMenuItem
            // 
            this.singleBorrowReceiptToolStripMenuItem.Name = "singleBorrowReceiptToolStripMenuItem";
            this.singleBorrowReceiptToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.S)));
            this.singleBorrowReceiptToolStripMenuItem.Size = new System.Drawing.Size(506, 38);
            this.singleBorrowReceiptToolStripMenuItem.Text = "&Single Borrow Receipt";
            this.singleBorrowReceiptToolStripMenuItem.Click += new System.EventHandler(this.singleBorrowReceiptToolStripMenuItem_Click);
            // 
            // transactionByGenreToolStripMenuItem
            // 
            this.transactionByGenreToolStripMenuItem.Name = "transactionByGenreToolStripMenuItem";
            this.transactionByGenreToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.T)));
            this.transactionByGenreToolStripMenuItem.Size = new System.Drawing.Size(506, 38);
            this.transactionByGenreToolStripMenuItem.Text = "&Transaction by Genre";
            this.transactionByGenreToolStripMenuItem.Click += new System.EventHandler(this.transactionByGenreToolStripMenuItem_Click);
            // 
            // logoutToolStripMenuItem
            // 
            this.logoutToolStripMenuItem.Name = "logoutToolStripMenuItem";
            this.logoutToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.L)));
            this.logoutToolStripMenuItem.Size = new System.Drawing.Size(102, 36);
            this.logoutToolStripMenuItem.Text = "&Logout";
            this.logoutToolStripMenuItem.Click += new System.EventHandler(this.logoutToolStripMenuItem_Click_1);
            // 
            // panel1
            // 
            this.panel1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Location = new System.Drawing.Point(288, 71);
            this.panel1.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1002, 552);
            this.panel1.TabIndex = 15;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(24, 71);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(218, 221);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 16;
            this.pictureBox1.TabStop = false;
            // 
            // CLibLandingPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1352, 719);
            this.ControlBox = false;
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "CLibLandingPage";
            this.Text = "CLibLandingPage";
            this.Load += new System.EventHandler(this.Form3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem mainMenuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem memberMaintenanceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bookMaintenanceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem authorPublisherMaintenanceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem issueBookToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem returnBookToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logoutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reportsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem authorByBookCategoryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bookStockByGenreToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bottom5MembersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem membersBorrowReceiptListToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem singleBorrowReceiptToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem transactionByGenreToolStripMenuItem;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}