﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Transactions;

namespace SA47_Team01ACAProject
{
    public partial class IssueBook : Form
    {

        SA47_Team01aCADatabaseEntities context;
        int iMemid = 0;
        int iBookid = 0;
        public IssueBook()
        {
            InitializeComponent();
        }


        private void DisplayResult1()
        {


            MemName.Text = context.Members.Where(x => x.MemberID == iMemid).First().MemberName.ToString();
            BooksBorrowed.Text = context.IssueTransactions.Where(x => x.LoanStatus == "Out").Count().ToString();
            toolStripStatusLabel1.Text = "Member Found!";
        }


        public void DisplayResult2()
        {
            BookTitle.Text = context.Books.Where(x => x.BookID == iBookid).First().BookTitle.ToString();
            toolStripStatusLabel1.Text = "Book Found!";
        }


        private void Issue_Book_Load(object sender, EventArgs e)
        {

            context = new SA47_Team01aCADatabaseEntities();

            IssueDate.Text = DateTime.Now.Date.ToShortDateString();
            DueDate.Text = IssueDate.Value.AddDays(30).ToShortDateString();
            ReturnDate.Text = DueDate.Value.ToString();




            int month = Convert.ToInt32(DateTime.Now.Month);
            if ((month == 6) || (month == 12))
            {
                // MessageBox.Show("Works");
                SpecialPeriod.Checked = true;
            }

            else
            {
                NormalPeriod.Checked = true;
            }



        }

        private void MemId_TextChanged(object sender, EventArgs e)
        {

            try
            {
                iMemid = Convert.ToInt16(MemId.Text);

                if (context.Members.Where(x => x.MemberID == iMemid).FirstOrDefault() != null)
                {
                    DisplayResult1();
                }

                else
                {
                    toolStripStatusLabel1.Text = "Member Not Found!";

                    MemName.ResetText();
                    MemName.Text = "";
                    BooksBorrowed.Text = "";
                }
            }

            catch (Exception)
            {
                MessageBox.Show("Please enter a valid Member ID");
            }

        }


        private void SearchMember_Click(object sender, EventArgs e)
        {
            SA47_Team01aCADatabaseEntities context = new SA47_Team01aCADatabaseEntities();
            PopupMember pum = new PopupMember();
            pum.WindowState = FormWindowState.Maximized;
            pum.StartPosition = FormStartPosition.CenterScreen;
            //pum.MdiParent = this;
            pum.dataGridView1.DataSource = context.Members.Select(y => new { y.MemberID, y.MemberName, y.DateofBirth, y.Gender, }).ToList();
            pum.ShowDialog();

            MemName.Text = pum.MemName;

            MemId.Text = pum.MemID;


        }

        private void BookId_TextChanged(object sender, EventArgs e)
        {
            try
            {
                iBookid = Convert.ToInt16(BookId.Text);

                if (context.Books.Where(x => x.BookID == iBookid).FirstOrDefault() != null)
                {
                    DisplayResult2();
                }

                else
                {
                    toolStripStatusLabel1.Text = "Book Not Found!";
                    BookTitle.Text = "";

                }
            }

            catch (Exception)
            {
                MessageBox.Show("Please enter a valid Book ID");
            }
        }


        bool cont;
        private void CheckMember()
        {
            var CM = context.Members.Where(x => x.MemberID == iMemid).FirstOrDefault();
            if (CM == null)
            {
                MessageBox.Show("Member Not Found");
                cont = false;
            }
            else
            {
                cont = true;
            }
        }

        bool cont1;
        private void CheckBook()
        {
            var CB = context.Books.Where(x => x.BookID == iBookid).FirstOrDefault();
            if (CB == null)
            {
                MessageBox.Show("Book Not Found");
                cont1 = false;
            }
            else
            {
                cont1 = true;
            }
        }

        private void IssueBookBtn_Click(object sender, EventArgs e)
        {
            SA47_Team01aCADatabaseEntities context = new SA47_Team01aCADatabaseEntities();

            CheckMember();
            CheckBook();

            if (cont == true && cont1 == true)
            {
                using (TransactionScope ts = new TransactionScope())
                {                   

                    IssueTransaction it = new IssueTransaction();
                    //var nTransid = Convert.ToInt16(Transid.Text);
                    //it.TransactionID = nTransid;






                    var nMemid = Convert.ToInt16(MemId.Text);
                    it.MemberID = nMemid;

                    Member m = context.Members.Where(x => x.MemberID.ToString() == MemId.Text).First();
                    BooksBorrowed.Text = m.IssueTransactions.Where(x => x.LoanStatus == "Out").Count().ToString();






                    var nBookId = Convert.ToInt16(BookId.Text);
                    it.BookID = nBookId;

                    Book b = context.Books.Where(x => x.BookID.ToString() == BookId.Text).First();

                    if (b.NumberLoaned >= b.TotalStock)
                    {
                        MessageBox.Show("Book Out of Stock...Please Select another book");
                    }

                    else
                    {
                        it.DateIssue = IssueDate.Value.Date;
                        it.DateDue = DueDate.Value.Date;
                        it.DateActualReturn = ReturnDate.Value.Date;
                        it.LoanStatus = LoanStatus.Text;
                        it.Remarks = Remarks.Text;

                        if (NormalPeriod.Checked)
                        {
                            int value;
                            if (Int32.TryParse(BooksBorrowed.Text, out value))
                            {
                                if (value >= 5)
                                {
                                    MessageBox.Show("Member has already reached the maximum borrow limit. Cannot Issue Book!");
                                }

                                else
                                {
                                    //Book b = context.Books.Where(x => x.BookID.ToString() == BookId.Text).First();
                                    b.NumberLoaned = Convert.ToInt16(b.NumberLoaned + 1);
                                    context.IssueTransactions.Add(it);
                                    context.SaveChanges();
                                    Transid.Text = it.TransactionID.ToString();

                                    MessageBox.Show("Book Issued Successfully");
                                    //MessageBox.Show("Test");
                                    ts.Complete();
                                    this.Close();
                                }
                            }
                        }

                        if (SpecialPeriod.Checked)
                        {
                            int value;
                            if (Int32.TryParse(BooksBorrowed.Text, out value))
                            {
                                if (value >= 10)
                                {
                                    MessageBox.Show("Member has already reached the maximum borrow limit. Cannot Issue Book!");
                                }

                                else
                                {

                                    //Book b = context.Books.Where(x => x.BookID.ToString() == BookId.Text).First();
                                    b.NumberLoaned = Convert.ToInt16(b.NumberLoaned + 1);
                                    context.IssueTransactions.Add(it);
                                    context.SaveChanges();
                                    Transid.Text = it.TransactionID.ToString();

                                    MessageBox.Show("Book Issued Successfully!");
                                    //MessageBox.Show("Test");
                                    ts.Complete();
                                    this.Close();
                                }
                            }
                        }


                    }
                }
            }
            else
            {
                MessageBox.Show("Sorry! Cannot Issue Book");
            }


        }

        private void Back_Click(object sender, EventArgs e)
        {

        }




        private void SearchBook_Click(object sender, EventArgs e)
        {
            SA47_Team01aCADatabaseEntities context = new SA47_Team01aCADatabaseEntities();
            PopUpBook pub = new PopUpBook();
            pub.WindowState = FormWindowState.Maximized;
            pub.StartPosition = FormStartPosition.CenterScreen;
            //pum.MdiParent = this;
            pub.dataGridView1.DataSource = context.Books.Select(y => new { y.BookID, y.BookTitle, y.Author, y.Publisher, y.BookCategory, y.Genre }).ToList();
            pub.ShowDialog();

            BookId.Text = pub.BookId;

            BookTitle.Text = pub.BookTitle;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
