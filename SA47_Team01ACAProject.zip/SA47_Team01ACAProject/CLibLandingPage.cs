﻿using SA47_Team01ACAProject_CrystalReports;
using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;

namespace SA47_Team01ACAProject
{
    public partial class CLibLandingPage : Form
    {
        SA47_Team01aCADatabaseEntities context;
        public CLibLandingPage()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            context = new SA47_Team01aCADatabaseEntities();
            var filtered = context.IssueTransactions.Where(x => x.Remarks == "Extension Requested").ToList();
            dataGridView1.DataSource = filtered;
        }

        //approve extension
        private void button1_Click(object sender, EventArgs e)
        {
            int selected = Convert.ToInt16(dataGridView1.CurrentRow.Cells[0].Value);
            IssueTransaction t = context.IssueTransactions.Where(x => x.TransactionID == selected).First();
            DateTime newdate = t.DateDue.AddDays(7);
            t.DateDue = newdate;
            t.Remarks = "Extension Approved";
            context.SaveChanges();
        }

        //deny extension
        private void button2_Click(object sender, EventArgs e)
        {
            int selected = Convert.ToInt16(dataGridView1.CurrentRow.Cells[0].Value);
            IssueTransaction t = context.IssueTransactions.Where(x => x.TransactionID == selected).First();
            t.Remarks = "Extension Rejected";
            context.SaveChanges();
        }

        //refresh list
        private void button3_Click(object sender, EventArgs e)
        {
            var filteragain = context.IssueTransactions.Where(x => x.Remarks == "Extension Requested").ToList();
            dataGridView1.DataSource = filteragain;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            BooksOnLoan f = new BooksOnLoan();
            f.MdiParent = this.ParentForm;
            f.WindowState = FormWindowState.Maximized;
            f.Show();
        }

        private void memberMaintenanceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MemberForm f = new MemberForm();
            f.MdiParent = this.ParentForm;
            f.WindowState = FormWindowState.Maximized;
            f.Show();
        }

        private void bookMaintenanceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BookMaintenanceForm f = new BookMaintenanceForm();
            f.MdiParent = this.ParentForm;
            f.WindowState = FormWindowState.Maximized;
            f.Show();
        }

        private void authorPublisherMaintenanceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AuthorPublisherForm f = new AuthorPublisherForm();
            f.MdiParent = this.ParentForm;
            f.WindowState = FormWindowState.Maximized;
            f.Show();
        }

        private void logoutToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void issueBookToolStripMenuItem_Click(object sender, EventArgs e)
        {
            IssueBook f = new IssueBook();
            f.MdiParent = this.ParentForm;
            f.WindowState = FormWindowState.Maximized;
            f.Show();
        }

        private void returnBookToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Return_Book f = new Return_Book();
            f.MdiParent = this.ParentForm;
            f.WindowState = FormWindowState.Maximized;
            f.Show();
        }

        private void authorByBookCategoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AuthorByBookCategory f = new AuthorByBookCategory();
            f.Show();
        }

        private void bookStockByGenreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BookStockByGenre f = new BookStockByGenre();
            f.Show();
        }

        private void bottom5MembersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Bottom5Members_Overdue f = new Bottom5Members_Overdue();
            f.Show();
        }

        private void membersBorrowReceiptListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MembersBorrowReceiptList f = new MembersBorrowReceiptList();
            f.Show();
        }

        private void singleBorrowReceiptToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SingleBorrowReceipt f = new SingleBorrowReceipt();
            f.Show();
        }

        private void transactionByGenreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TransactionByGenre f = new TransactionByGenre();
            f.Show();
        }
    }
}
